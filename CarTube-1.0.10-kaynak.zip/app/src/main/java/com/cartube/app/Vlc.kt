package com.cartube.app

import android.net.Uri
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/** VLC motoru: Medya motoru ayarlarından "VLC" seçilince TV/Medya/Radyo bunun üstünden çalar. */
object Vlc {
    private var lib: LibVLC? = null
    private var mp: MediaPlayer? = null
    var title: String? = null
    var layout: VLCVideoLayout? = null     // açık olan video ekranı

    private fun ensure(): MediaPlayer {
        mp?.let { return it }
        val l = LibVLC(App.ctx, arrayListOf("--network-caching=1500", "--audio-time-stretch"))
        lib = l
        return MediaPlayer(l).also { p -> p.setEventListener { App.onState?.invoke() }; mp = p }
    }

    val isPlaying: Boolean get() = mp?.isPlaying == true

    fun play(name: String, url: String, video: Boolean) {
        val p = ensure()
        p.stop()
        p.detachViews()
        val hw = App.int("hw", 0) == 0
        val lay = layout
        if (video && lay != null) {
            p.attachViews(lay, null, false, false)
            applyScale()
        }
        val m = Media(lib!!, Uri.parse(url))
        m.setHWDecoderEnabled(hw, false)
        p.media = m
        m.release()
        title = name
        applyEq()
        p.play()
        App.onState?.invoke()
    }

    fun pause() { mp?.pause(); App.onState?.invoke() }
    fun resume() { mp?.play(); App.onState?.invoke() }
    fun stop() { mp?.stop(); title = null; App.onState?.invoke() }
    fun seekBy(ms: Long) { mp?.let { p -> p.time = (p.time + ms).coerceAtLeast(0) } }
    /** Ekran boyutu: 0 = Sığdır, 1 = Doldur (uzat), 2 = Tam ekran (kırp). Çalarken de uygulanabilir. */
    fun applyScale() {
        val p = mp ?: return
        try {
            p.setVideoScale(when (App.int("video_resize", 0)) {
                1 -> MediaPlayer.ScaleType.SURFACE_FILL
                2 -> MediaPlayer.ScaleType.SURFACE_FIT_SCREEN
                else -> MediaPlayer.ScaleType.SURFACE_BEST_FIT })
        } catch (e: Exception) { }
    }
    fun applyEq() {
        val p = mp ?: return
        try {
            if (!Eq.enabled()) { p.setEqualizer(null); return }
            val e = MediaPlayer.Equalizer.create()
            val b = Eq.bands()
            for (i in 0 until MediaPlayer.Equalizer.getBandCount())
                e.setAmp(i, b[Eq.nearest(MediaPlayer.Equalizer.getBandFrequency(i).toInt())].toFloat())
            p.setEqualizer(e)
        } catch (e: Exception) { }
    }
    fun detach() { try { mp?.detachViews() } catch (e: Exception) { }; layout = null }
}
