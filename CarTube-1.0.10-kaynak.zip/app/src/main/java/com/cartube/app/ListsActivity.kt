package com.cartube.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Liste yönetimi (Eklentiler > TV / Radyo > Listeler).
 * kind = "tv" | "radio".
 * list yok  : tüm listeler alt alta gösterilir; her biri düzenlenebilir, yeniden adlandırılabilir, yenilenebilir, silinebilir.
 * list = n  : n. listenin içindeki kanallar / istasyonlar gösterilir; düzenlenir, eklenir, silinir.
 */
class ListsActivity : AppCompatActivity() {
    private class Row(val title: String, val sub: String?, val onClick: (() -> Unit)?, val onMenu: (() -> Unit)?)

    private val isTv get() = (intent.getStringExtra("kind") ?: "tv") == "tv"
    private val st get() = if (isTv) Stores.tv else Stores.radio
    private val idx get() = intent.getIntExtra("list", -1)
    private val blue get() = Theme.set()
    private val tr = Locale("tr", "TR")
    private var query = ""
    private var rows: List<Row> = emptyList()
    private lateinit var head: TextView
    private lateinit var subTv: TextView
    private lateinit var lv: ListView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        head = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 24f; setTypeface(null, Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(20), dp(40), dp(20), dp(4)) }
        subTv = TextView(this).apply {
            setTextColor(Color.parseColor("#B8C4D0")); textSize = 14f; setPadding(dp(20), 0, dp(20), dp(8)) }
        root.addView(head); root.addView(subTv)
        if (idx >= 0) {
            val search = EditText(this).apply {
                hint = L.t("Ara"); setHintTextColor(Color.parseColor("#6B7A8A"))
                setTextColor(Color.WHITE); textSize = 16f; setSingleLine()
                background = GradientDrawable().apply {
                    cornerRadius = dp(24).toFloat(); setColor(Theme.setCard()); setStroke(dp(1), Theme.dim(blue)) }
                setPadding(dp(18), dp(10), dp(18), dp(10))
                addTextChangedListener { e -> query = e?.toString()?.trim() ?: ""; render(false) }
            }
            root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { leftMargin = dp(14); rightMargin = dp(14); bottomMargin = dp(6) })
        }
        lv = ListView(this).apply {
            divider = null; setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(14), dp(4), dp(14), dp(12)); clipToPadding = false }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Ui.navBar(this, null, R.drawable.ic_add) { if (idx >= 0) addItem() else addMenu() })
        setContentView(root)
    }

    override fun onResume() { super.onResume(); render(true) }

    // ---------- Görünüm ----------

    private fun render(keepPos: Boolean) {
        val unit = L.t(if (isTv) "kanal" else "istasyon")
        if (idx < 0) {
            head.text = L.t(if (isTv) "TV listeleri" else "Radyo listeleri")
            subTv.text = L.t("Düzenlemek için listeye dokun, işlemler için ⋮ düğmesini kullan")
            val act = st.lists.indexOf(st.cur())
            rows = if (st.lists.isEmpty()) listOf(Row(L.t("Henüz liste yok. Alttaki + düğmesiyle ekleyin."), null, null, null))
            else st.lists.mapIndexed { i, l ->
                val src = when {
                    l.src.isBlank() -> L.t("Elle oluşturuldu")
                    l.src.startsWith("radio-browser:") -> L.t("İnternet radyoları") + " (" + l.src.substringAfter(":") + ")"
                    else -> l.src
                }
                val sub = l.items.size.toString() + " " + unit + " · " + src + (if (i == act) " · " + L.t("Etkin") else "")
                Row(l.name, sub, { openList(i) }, { listMenu(i) })
            }
        } else {
            val l = st.lists.getOrNull(idx)
            if (l == null) { finish(); return }
            head.text = l.name
            subTv.text = l.items.size.toString() + " " + unit
            val q = query.lowercase(tr)
            val shown = l.items.filter { q.isBlank() || it.n.lowercase(tr).contains(q) || it.g.lowercase(tr).contains(q) }
            rows = if (shown.isEmpty()) listOf(Row(L.t(if (l.items.isEmpty()) "Bu listede öğe yok. Alttaki + düğmesiyle ekleyin." else "Eşleşen öğe yok"), null, null, null))
            else shown.map { item ->
                val sub = if (isTv) (if (item.g.isNotBlank()) "[" + item.g + "] " else "") + item.u
                else (if (item.s.isNotBlank()) item.s + " · " else "") + item.u
                Row(item.n, sub, { itemMenu(l, item) }, { itemMenu(l, item) })
            }
        }
        val pos = lv.firstVisiblePosition
        lv.adapter = Rows()
        if (keepPos && pos in 1 until rows.size) lv.setSelection(pos)
    }

    private inner class Rows : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(p: Int) = rows[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, g: ViewGroup): View = card(rows[p])
    }

    private fun card(r: Row): View {
        val c = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(Theme.setCard()) }
            setPadding(dp(16), dp(12), dp(8), dp(12))
            r.onClick?.let { cb -> setOnClickListener { cb() } }
        }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(TextView(this).apply {
            text = r.title; setTextColor(Color.WHITE); textSize = 17f; setTypeface(null, Typeface.BOLD)
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        r.sub?.let { s -> if (s.isNotBlank()) tx.addView(TextView(this).apply {
            text = s; setTextColor(Color.parseColor("#B8C4D0")); textSize = 13f; maxLines = 2; ellipsize = TextUtils.TruncateAt.END }) }
        c.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        r.onMenu?.let { cb ->
            c.addView(ImageButton(this).apply {
                setBackgroundColor(Color.TRANSPARENT); setImageResource(R.drawable.ic_more); setColorFilter(blue)
                setOnClickListener { cb() } }, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        val wrap = FrameLayout(this).apply { setPadding(0, dp(5), 0, dp(5)) }
        wrap.addView(c, FrameLayout.LayoutParams(-1, -2))
        return wrap
    }

    private fun kindExtra() = if (isTv) "tv" else "radio"

    private fun openList(i: Int) {
        startActivity(Intent(this, ListsActivity::class.java).putExtra("kind", kindExtra()).putExtra("list", i))
    }

    // ---------- Liste işlemleri ----------

    private fun listMenu(i: Int) {
        val l = st.lists.getOrNull(i) ?: return
        val acts = mutableListOf<Pair<String, () -> Unit>>()
        acts.add("İçeriği düzenle" to { openList(i) })
        acts.add("Listeyi yeniden adlandır" to { rename(l) })
        if (l.src.isNotBlank()) acts.add("Listeyi yenile" to { refreshList(l) })
        if (l !== st.cur()) acts.add("Etkin liste yap" to { st.active = i; st.save(); Ui.toast(this, "Etkin liste yapıldı"); render(true) })
        acts.add("Listeyi sil" to { deleteList(l) })
        Ui.menu(this, l.name, acts.map { it.first }) { acts[it].second() }
    }

    private fun rename(l: ListStore.Lst) {
        Ui.ask(this, "Listeyi yeniden adlandır", listOf("Liste adı"), listOf(l.name)) { v ->
            if (v[0].isNotBlank()) { l.name = v[0]; st.save(); render(true) }
        }
    }

    private fun deleteList(l: ListStore.Lst) {
        Ui.confirm(this, "\"${l.name}\" " + L.t("silinsin mi?")) {
            st.lists.remove(l); st.active = 0; st.save(); render(false)
        }
    }

    private fun refreshList(l: ListStore.Lst) {
        if (l.src.isBlank()) { Ui.toast(this, "Bu liste elle oluşturulmuş"); return }
        Ui.toast(this, "Yükleniyor…")
        thread {
            val items = try {
                if (l.src.startsWith("radio-browser:")) ListStore.radios(l.src.substringAfter(":")) else ListStore.parse(ListStore.http(l.src))
            } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (items.isEmpty()) Ui.toast(this, "Liste yüklenemedi")
                else {
                    // elle atanan grupları koru
                    val old = l.items.associate { it.u to it.g }
                    items.forEach { if (it.g.isBlank()) it.g = old[it.u] ?: "" }
                    l.items = items.toMutableList(); st.save(); render(true); Ui.toast(this, "Liste yenilendi")
                }
            }
        }
    }

    /** Yeni liste ekler; etkin liste değişmez (ilk liste ise etkin olur). */
    private fun addList(l: ListStore.Lst) {
        val had = st.lists.isNotEmpty()
        val prev = st.active
        st.lists.add(l)
        st.active = if (had) prev else 0
        st.save(); render(false)
    }

    private fun addMenu() {
        val acts = mutableListOf<Pair<String, () -> Unit>>()
        acts.add((if (isTv) "Liste ekle (M3U adresi)" else "Liste ekle (adres / M3U)") to { addFromUrl() })
        acts.add("Yeni boş liste" to { newEmpty() })
        if (!isTv) acts.add("İnternet radyolarını ekle" to { addInternet() })
        Ui.menu(this, if (isTv) "TV listeleri" else "Radyo listeleri", acts.map { it.first }) { acts[it].second() }
    }

    private fun addFromUrl() {
        val hints = listOf("Liste adı", if (isTv) "M3U / IPTV liste adresi" else "M3U / liste adresi (URL)")
        Ui.ask(this, if (isTv) "Liste ekle (M3U adresi)" else "Liste ekle (adres / M3U)", hints) { v ->
            val name = v[0]; val url = v[1]
            if (url.isNotBlank()) {
                Ui.toast(this, "Yükleniyor…")
                thread {
                    val items = try { ListStore.parse(ListStore.http(url)) } catch (e: Exception) { emptyList() }
                    runOnUiThread {
                        if (items.isEmpty()) Ui.toast(this, "Liste yüklenemedi")
                        else addList(ListStore.Lst(name.ifBlank { url.substringAfterLast('/') }, url, items.toMutableList()))
                    }
                }
            }
        }
    }

    private fun newEmpty() {
        Ui.ask(this, "Yeni boş liste", listOf("Liste adı")) { v ->
            if (v[0].isNotBlank()) addList(ListStore.Lst(v[0]))
        }
    }

    private fun addInternet() {
        Ui.ask(this, "Ülke kodu (TR, DE, US…)", listOf("Ülke kodu"), listOf("TR")) { v ->
            val cc = v[0].ifBlank { "TR" }.uppercase()
            Ui.toast(this, "İnternet radyoları yükleniyor…")
            thread {
                val items = ListStore.radios(cc)
                runOnUiThread {
                    if (items.isEmpty()) Ui.toast(this, "Liste yüklenemedi")
                    else addList(ListStore.Lst(L.t("İnternet radyoları") + " ($cc)", "radio-browser:$cc", items.toMutableList()))
                }
            }
        }
    }

    // ---------- Kanal / istasyon işlemleri ----------

    private fun itemHints() =
        if (isTv) listOf("Ad", "Yayın adresi (URL)", "Grup (isteğe bağlı)") else listOf("Ad", "Yayın adresi (URL)")

    private fun itemMenu(l: ListStore.Lst, item: ListStore.Item) {
        Ui.menu(this, item.n, listOf("Düzenle", "Favorilere ekle", "Sil")) { i ->
            when (i) {
                0 -> editItem(item)
                1 -> { App.addFav(item.n, item.u); Ui.toast(this, "Favorilere eklendi") }
                2 -> Ui.confirm(this, "\"${item.n}\" " + L.t("silinsin mi?")) { l.items.remove(item); st.save(); render(true) }
            }
        }
    }

    private fun editItem(item: ListStore.Item) {
        val defs = if (isTv) listOf(item.n, item.u, item.g) else listOf(item.n, item.u)
        Ui.ask(this, "Öğeyi düzenle", itemHints(), defs) { v ->
            if (v[1].isNotBlank()) {
                item.n = v[0].ifBlank { v[1] }; item.u = v[1]
                if (isTv) item.g = v[2]
                st.save(); render(true)
            }
        }
    }

    private fun addItem() {
        val l = st.lists.getOrNull(idx) ?: return
        Ui.ask(this, if (isTv) "Kanal ekle" else "Radyo ekle", itemHints()) { v ->
            if (v[1].isNotBlank()) {
                l.items.add(ListStore.Item(v[0].ifBlank { v[1] }, v[1], if (isTv) v[2] else ""))
                st.save(); render(true)
            }
        }
    }
}
