package com.cartube.app.car

import android.content.Intent
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.NavigationManager
import androidx.car.app.navigation.NavigationManagerCallback
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import com.cartube.app.*

/** Android Auto başlatıcısında "CarTube Tam Ekran" girişi (Navigation kategorisi). Ekran yansıtma buradan gösterilir. */
class CarTubeNavService : CarAppService() {
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = object : Session() {
        override fun onCreateScreen(intent: Intent): Screen {
            App.greet(carContext, true)
            try {
                val nm = carContext.getCarService(NavigationManager::class.java)
                nm.setNavigationManagerCallback(object : NavigationManagerCallback {
                    override fun onStopNavigation() {}
                    override fun onAutoDriveEnabled() {}
                })
                nm.navigationStarted()
            } catch (e: Exception) { }
            return NavHomeScreen(carContext)
        }
    }
}

private fun icon(c: CarContext, res: Int) = CarIcon.Builder(IconCompat.createWithResource(c, res)).build()

class NavHomeScreen(c: CarContext) : Screen(c) {
    private fun act(res: Int, cls: Class<*>) = Action.Builder().setIcon(icon(carContext, res))
        .setOnClickListener {
            carContext.startActivity(Intent(carContext, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            CarToast.makeText(carContext, L.t("Telefonda açıldı"), CarToast.LENGTH_SHORT).show()
        }.build()

    private fun mirrorAct() = Action.Builder().setIcon(icon(carContext, R.drawable.ic_cast))
        .setOnClickListener {
            if (Mirror.active) screenManager.push(MirrorScreen(carContext))
            else {
                carContext.startActivity(Intent(carContext, MirrorActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                CarToast.makeText(carContext, L.t("Önce telefonda yansıtmayı başlat"), CarToast.LENGTH_LONG).show()
            }
        }.build()

    override fun onGetTemplate(): Template {
        val strip = ActionStrip.Builder()
            .addAction(act(R.drawable.ic_tv, TvActivity::class.java))
            .addAction(act(R.drawable.ic_play, YouTubeActivity::class.java))
            .addAction(mirrorAct())
            .addAction(act(R.drawable.ic_radio, RadioActivity::class.java))
            .build()
        return NavigationTemplate.Builder()
            .setActionStrip(strip)
            .setBackgroundColor(CarColor.createCustom(0xFF101418.toInt(), 0xFF101418.toInt()))
            .build()
    }
}

/** Araç ekranındaki yüzeye telefonun ekranını çizer. */
class MirrorScreen(c: CarContext) : Screen(c) {
    init {
        try {
            carContext.getCarService(AppManager::class.java).setSurfaceCallback(object : SurfaceCallback {
                override fun onSurfaceAvailable(sc: SurfaceContainer) {
                    val s = sc.surface ?: return
                    Mirror.attach(s, sc.width, sc.height, sc.dpi)
                }
                override fun onSurfaceDestroyed(sc: SurfaceContainer) { Mirror.detachDisplay() }
            })
        } catch (e: Exception) { }
    }

    override fun onGetTemplate(): Template {
        val stop = Action.Builder().setIcon(icon(carContext, R.drawable.ic_pause)).setOnClickListener {
            Mirror.stop(); screenManager.pop()
        }.build()
        return NavigationTemplate.Builder()
            .setActionStrip(ActionStrip.Builder().addAction(Action.BACK).addAction(stop).build())
            .build()
    }
}
