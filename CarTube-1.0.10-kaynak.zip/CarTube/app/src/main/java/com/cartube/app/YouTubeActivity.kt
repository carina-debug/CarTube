package com.cartube.app

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class YouTubeActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var frame: FrameLayout
    private var custom: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val h = Handler(Looper.getMainLooper())
    private var docStart = false
    private var sbVideo = ""
    private var segs: List<Triple<Double, Double, String>> = emptyList()
    private val tick = object : Runnable { override fun run() { tickOnce(); h.postDelayed(this, 600) } }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        frame = FrameLayout(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            val mode = App.int("yt_dark", 0)
            val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            if (Build.VERSION.SDK_INT >= 33) settings.isAlgorithmicDarkeningAllowed = mode == 1 || (mode == 0 && night)
            else if (Build.VERSION.SDK_INT >= 29) settings.forceDark = when (mode) {
                1 -> WebSettings.FORCE_DARK_ON; 2 -> WebSettings.FORCE_DARK_OFF; else -> WebSettings.FORCE_DARK_AUTO }
            val block = App.bool("yt_block", true)
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                    if (block && isAdUrl(r.url)) return WebResourceResponse("text/plain", "UTF-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                    return super.shouldInterceptRequest(v, r)
                }
                override fun onPageStarted(v: WebView, url: String?, f: android.graphics.Bitmap?) {
                    super.onPageStarted(v, url, f)
                    if (block && !docStart && (url ?: "").contains("youtube.com")) v.evaluateJavascript(AD_JS, null)
                }
            }
            if (block && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(this, AD_JS, setOf("https://m.youtube.com", "https://www.youtube.com", "https://music.youtube.com"))
                docStart = true
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                    custom = v; customCb = cb
                    frame.addView(v, ViewGroup.LayoutParams(-1, -1)); web.visibility = View.GONE
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; bars(true)
                }
                override fun onHideCustomView() {
                    custom?.let { frame.removeView(it) }; custom = null; customCb?.onCustomViewHidden()
                    web.visibility = View.VISIBLE; requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; bars(false)
                }
            }
            loadUrl(intent.getStringExtra("url") ?: "https://m.youtube.com")
        }
        frame.addView(web, ViewGroup.LayoutParams(-1, -1))
        setContentView(frame)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (custom != null) web.webChromeClient?.onHideCustomView()
                else if (web.canGoBack()) web.goBack() else finish()
            }
        })
    }

    private fun bars(hide: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (hide) { c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE; c.hide(WindowInsetsCompat.Type.systemBars()) }
        else c.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun tickOnce() {
        val u = web.url ?: return
        if (!u.contains("youtube.com")) return
        val js = """(function(){var v=document.querySelector('video');if(!v)return -1;
if(${App.bool("yt_q", true)}){var p=document.getElementById('movie_player');if(p&&p.getAvailableQualityLevels&&window.__ctq!==location.href){var l=p.getAvailableQualityLevels();if(l&&l.length&&l[0]!=='auto'){p.setPlaybackQualityRange(l[0],l[0]);window.__ctq=location.href;}}}
var pl0=document.getElementById('movie_player');var adOn=!!(pl0&&pl0.classList.contains('ad-showing'));
if(window.__ctmuted&&!adOn){v.muted=false;window.__ctmuted=false;}
if(${App.bool("yt_skip", true)}&&adOn){v.muted=true;window.__ctmuted=true;if(isFinite(v.duration)&&v.duration>0&&v.currentTime<v.duration-0.3){v.currentTime=v.duration-0.1;}}
if(${App.bool("yt_skip", true)}){var b=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button');if(b)b.click();}
if(${App.bool("yt_fs", true)}&&location.pathname.indexOf('/watch')==0&&!document.fullscreenElement&&window.__ctf!==location.href){var f=document.querySelector('.fullscreen-icon,.ytp-fullscreen-button');if(f){f.click();window.__ctf=location.href;}}
return v.currentTime;})()"""
        web.evaluateJavascript(js) { r ->
            val t = r?.toDoubleOrNull() ?: return@evaluateJavascript
            if (t >= 0) sponsorBlock(u, t)
        }
    }

    private fun sponsorBlock(url: String, t: Double) {
        if (!App.bool("sb_on", false)) return
        val vid = Uri.parse(url).getQueryParameter("v") ?: return
        if (vid != sbVideo) {
            sbVideo = vid; segs = emptyList()
            val cats = JSONArray(listOf("sponsor", "selfpromo", "interaction", "intro", "outro", "music_offtopic")
                .filter { App.bool("sb_$it", it in listOf("sponsor", "selfpromo", "interaction")) }).toString()
            thread {
                try {
                    val c = URL("https://sponsor.ajay.app/api/skipSegments?videoID=$vid&categories=" + URLEncoder.encode(cats, "UTF-8"))
                        .openConnection() as HttpURLConnection
                    c.connectTimeout = 5000; c.readTimeout = 5000
                    if (c.responseCode == 200) {
                        val a = JSONArray(c.inputStream.bufferedReader().readText())
                        val l = (0 until a.length()).map { a.getJSONObject(it) }.map {
                            val sg = it.getJSONArray("segment"); Triple(sg.getDouble(0), sg.getDouble(1), it.optString("category")) }
                        h.post { if (sbVideo == vid) segs = l }
                    }
                } catch (e: Exception) { }
            }
            return
        }
        segs.firstOrNull { t >= it.first && t < it.second - 0.4 }?.let {
            web.evaluateJavascript("var v=document.querySelector('video');if(v)v.currentTime=${it.second};", null)
            Toast.makeText(this, "SponsorBlock: " + it.third, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() { super.onResume(); h.postDelayed(tick, 1500) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
    override fun onDestroy() { web.destroy(); super.onDestroy() }

    private fun isAdUrl(u: Uri): Boolean {
        val h = u.host ?: return false
        val p = u.path ?: ""
        if (h.endsWith("doubleclick.net") || h.endsWith("googlesyndication.com") || h.endsWith("googleadservices.com") || h.endsWith("adservice.google.com")) return true
        if (h.endsWith("youtube.com") && (p.startsWith("/pagead/") || p.startsWith("/api/stats/ads") || p.contains("/ptracking") || p.startsWith("/get_midroll_info"))) return true
        return false
    }

    companion object {
        /** Oynatıcı yanıtından reklam alanlarını ayıklar, reklam öğelerini gizler. Sayfa başlamadan önce çalışır. */
        private const val AD_JS = """(function(){
if(window.__ctab)return;window.__ctab=1;
var K=['adPlacements','playerAds','adSlots','adBreakHeartbeatParams'];
function strip(o){try{if(!o||typeof o!=='object')return o;
for(var i=0;i<K.length;i++){if(K[i] in o){try{o[K[i]]=(K[i]==='adBreakHeartbeatParams')?undefined:[];}catch(e){}}}
if(o.playerResponse)strip(o.playerResponse);
if(o.response&&o.response.playerResponse)strip(o.response.playerResponse);}catch(e){}return o;}
var oj=JSON.parse;JSON.parse=function(){return strip(oj.apply(this,arguments));};
var rj=Response.prototype.json;Response.prototype.json=function(){return rj.apply(this,arguments).then(strip);};
var _ipr;try{Object.defineProperty(window,'ytInitialPlayerResponse',{configurable:true,get:function(){return _ipr;},set:function(v){_ipr=strip(v);}});}catch(e){}
var css='ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-slot,ytm-ad-slot-renderer,ytm-statement-banner-renderer,ytm-brand-video-singleton-renderer,ytm-in-feed-ad-layout-renderer,.ytp-ad-overlay-container,.ytp-ad-text-overlay{display:none!important}';
function addCss(){var s=document.createElement('style');s.textContent=css;(document.head||document.documentElement).appendChild(s);}
if(document.documentElement)addCss();else document.addEventListener('DOMContentLoaded',addCss);
})();"""
    }
}
