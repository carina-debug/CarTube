package com.cartube.app

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import kotlin.math.abs
import kotlin.math.ln

/** 5 bantlı ekolayzır: hazır ayarlar (düz, pop, rock, dans, klasik) + özel. */
object Eq {
    val names = listOf("Düz", "Pop", "Rock", "Dans", "Klasik")
    val freqs = listOf(60, 230, 910, 3600, 14000)
    private val presets = listOf(
        intArrayOf(0, 0, 0, 0, 0),
        intArrayOf(-1, 3, 5, 2, -1),
        intArrayOf(5, 3, -1, 3, 5),
        intArrayOf(6, 4, 0, 2, 4),
        intArrayOf(4, 3, -2, 4, 4))
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null

    fun enabled() = App.bool("eq_on", false)
    fun preset() = App.int("eq_preset", 0)          // 0..4 hazır, 5 = özel
    fun bass() = App.int("eq_bass", 0)
    fun bands(): IntArray = if (preset() < 5) presets[preset()].copyOf() else IntArray(5) { App.int("eq_b$it", 0) }
    fun choose(i: Int) { App.setInt("eq_preset", i); App.setBool("eq_on", true); apply() }
    fun setBand(i: Int, db: Int) {
        val b = bands(); b[i] = db
        for (k in 0 until 5) App.setInt("eq_b$k", b[k])
        App.setInt("eq_preset", 5); App.setBool("eq_on", true); apply()
    }
    fun nearest(hz: Int): Int = freqs.indices.minByOrNull { abs(ln(freqs[it].toDouble() / maxOf(hz, 1))) } ?: 0

    fun attach(session: Int) {
        try { eq?.release() } catch (e: Exception) { }
        try { bass?.release() } catch (e: Exception) { }
        eq = null; bass = null
        if (session <= 0) return
        try { eq = Equalizer(0, session) } catch (e: Exception) { }
        try { bass = BassBoost(0, session) } catch (e: Exception) { }
        apply()
    }

    fun apply() {
        val on = enabled()
        try {
            eq?.let { e ->
                e.enabled = on
                if (on) {
                    val b = bands(); val r = e.bandLevelRange
                    for (i in 0 until e.numberOfBands.toInt()) {
                        val hz = e.getCenterFreq(i.toShort()) / 1000
                        val lvl = (b[nearest(hz)] * 100).coerceIn(r[0].toInt(), r[1].toInt())
                        e.setBandLevel(i.toShort(), lvl.toShort())
                    }
                }
            }
        } catch (e: Exception) { }
        try { bass?.let { it.enabled = on && bass() > 0; if (on) it.setStrength(bass().toShort()) } } catch (e: Exception) { }
        Vlc.applyEq()
    }
}
