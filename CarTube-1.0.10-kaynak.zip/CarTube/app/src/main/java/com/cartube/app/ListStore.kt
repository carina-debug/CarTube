package com.cartube.app

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Birden fazla adlı liste, gruplu öğeler. Radyo ve TV için ortak. */
class ListStore(private val key: String) {
    class Item(var n: String, var u: String, var g: String = "", var i: String = "", var s: String = "")
    class Lst(var name: String, var src: String = "", var items: MutableList<Item> = mutableListOf())

    var lists = mutableListOf<Lst>()
    var active = 0

    init { load() }

    fun load() {
        lists = mutableListOf()
        try {
            val o = JSONObject(App.str(key).ifBlank { "{}" })
            active = o.optInt("active", 0)
            val arr = o.optJSONArray("lists") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val lo = arr.getJSONObject(i)
                val ia = lo.optJSONArray("items") ?: JSONArray()
                val items = (0 until ia.length()).map { j -> ia.getJSONObject(j).let { Item(it.optString("n"), it.optString("u"), it.optString("g"), it.optString("i"), it.optString("s")) } }
                lists.add(Lst(lo.optString("name"), lo.optString("src"), items.toMutableList()))
            }
        } catch (e: Exception) { }
    }

    fun save() {
        val arr = JSONArray()
        lists.forEach { l ->
            val ia = JSONArray()
            l.items.forEach { ia.put(JSONObject().put("n", it.n).put("u", it.u).put("g", it.g).put("i", it.i).put("s", it.s)) }
            arr.put(JSONObject().put("name", l.name).put("src", l.src).put("items", ia))
        }
        App.setStr(key, JSONObject().put("active", active).put("lists", arr).toString())
    }

    fun cur(): Lst? = lists.getOrNull(active.coerceIn(0, maxOf(0, lists.size - 1)))
    fun add(l: Lst) { lists.add(l); active = lists.lastIndex; save() }
    fun removeActive() { if (lists.isNotEmpty()) { lists.removeAt(active.coerceIn(0, lists.lastIndex)); active = 0; save() } }

    companion object {
        fun http(url: String): String {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 20000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "CarTube/1.0")
            return c.inputStream.bufferedReader().use { it.readText() }
        }

        /** M3U/M3U8 (group-title dahil), "Ad|URL" satırları ya da düz adresler. */
        fun parse(text: String): List<Item> {
            val out = mutableListOf<Item>()
            var name = ""; var group = ""
            val gt = Regex("group-title=\"([^\"]*)\"")
            for (raw in text.lines()) {
                val l = raw.trim()
                when {
                    l.isEmpty() -> {}
                    l.startsWith("#EXTINF") -> { name = l.substringAfterLast(",").trim(); group = gt.find(l)?.groupValues?.get(1) ?: group }
                    l.startsWith("#EXTGRP:") -> group = l.substringAfter(":").trim()
                    l.startsWith("#") -> {}
                    l.contains("|") && !l.startsWith("http") -> { val p = l.split("|", limit = 2); if (p[1].isNotBlank()) out.add(Item(p[0].trim(), p[1].trim(), group)) }
                    else -> { out.add(Item(name.ifBlank { l }, l, group)); name = ""; group = "" }
                }
            }
            return out
        }

        /** radio-browser.info: ülkeye göre en çok oy alan internet radyoları. */
        fun radios(cc: String): List<Item> {
            for (s in listOf("https://de1.api.radio-browser.info", "https://nl1.api.radio-browser.info", "https://at1.api.radio-browser.info")) {
                try {
                    val a = JSONArray(http("$s/json/stations/search?countrycode=${Uri.encode(cc)}&order=votes&reverse=true&limit=150&hidebroken=true"))
                    val items = (0 until a.length()).mapNotNull { i ->
                        val o = a.getJSONObject(i)
                        val n = o.optString("name").trim()
                        val u = o.optString("url_resolved").ifBlank { o.optString("url") }
                        val br = o.optInt("bitrate", 0)
                        val info = listOf(o.optString("country").trim(), (o.optString("codec").trim() + if (br > 0) " $br kbps" else "").trim())
                            .filter { it.isNotBlank() }.joinToString(" · ")
                        if (n.isNotBlank() && u.startsWith("http")) Item(n, u, "", o.optString("favicon").trim(), info) else null
                    }.distinctBy { it.n.lowercase() }
                    if (items.isNotEmpty()) return items
                } catch (e: Exception) { }
            }
            return emptyList()
        }
    }
}

object Stores {
    val radio: ListStore by lazy {
        ListStore("radio_store").also { s ->
            if (s.lists.isEmpty() && App.radios.isNotBlank()) s.add(ListStore.Lst("Listem", "", ListStore.parse(App.radios).toMutableList()))
        }
    }
    val tv: ListStore by lazy {
        ListStore("tv_store").also { s ->
            if (s.lists.isEmpty() && App.m3uUrl.isNotBlank()) s.add(ListStore.Lst("IPTV", App.m3uUrl))
        }
    }
}
