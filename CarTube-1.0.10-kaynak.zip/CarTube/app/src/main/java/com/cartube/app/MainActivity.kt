package com.cartube.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player

class MainActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val ts get() = App.float("ui_text", 1f)
    private val hk get() = Theme.home()
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var playBtn: ImageButton
    private val grey = Color.parseColor("#B0B5B8")

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(p: Boolean) = refresh()
        override fun onMediaItemTransition(m: MediaItem?, r: Int) = refresh()
    }

    private fun go(c: Class<*>) = startActivity(Intent(this, c))
    private fun webOpen(url: String) = startActivity(Intent(this, YouTubeActivity::class.java).putExtra("url", url))
    private fun settingsPage(p: String?) = startActivity(Intent(this, SettingsActivity::class.java).apply { if (p != null) putExtra("page", p) })

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.bg()) }
        root.addView(miniPlayer())
        root.addView(TextView(this).apply {
            text = "CarTube"; setTextColor(Color.WHITE); textSize = 24f; setTypeface(null, Typeface.BOLD)
            letterSpacing = 0.05f; setPadding(dp(20), dp(8), dp(20), dp(8)) })
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(16)) }
        if (App.bool("home_tv", true)) list.addView(card("TV", "Canlı TV ve IPTV", R.drawable.ic_tv, 170) { go(TvActivity::class.java) })
        if (App.bool("home_yt", true)) list.addView(card("Youtube", "Video izle", R.drawable.ic_play, 120) { go(YouTubeActivity::class.java) })
        if (App.bool("home_cast", true)) list.addView(card("Ekran Yansıtma", "Telefon ekranını göster", R.drawable.ic_cast, 170) { go(MirrorActivity::class.java) })
        if (App.bool("home_radio", true)) list.addView(rowCard("Radyo", "İnternet Radyoları", R.drawable.ic_radio, { go(RadioActivity::class.java) }))
        if (App.bool("home_media", true)) list.addView(rowCard("Medya", "Telefondaki video ve müzikler", R.drawable.ic_media, { go(MediaActivity::class.java) }))
        if (App.bool("home_phone", true)) list.addView(rowCard("Telefonu Kullan", "Kilitliyken de arabadan kullan", R.drawable.ic_phone, {
            startActivity(Intent(this, InfoActivity::class.java).putExtra("title", "Telefonu Kullan")
                .putExtra("text", "Bu özellik bu sürümde henüz yok.")) }))
        if (App.bool("home_web", true)) list.addView(rowCard("Web", "Tarayıcı ve Medya", R.drawable.ic_globe, {
            webOpen(App.str("web_home").ifBlank { "https://www.google.com" }) }))
        list.addView(rowCard("Kısayol ekle", "Kendi web siteniz", R.drawable.ic_add, { addShortcut() }))
        App.shortcuts().forEach { (n, u) ->
            list.addView(rowCard(n, u, R.drawable.ic_globe, { webOpen(u) }, {
                AlertDialog.Builder(this).setMessage("\"$n\" kısayolu silinsin mi?")
                    .setPositiveButton("Sil") { _, _ -> App.removeShortcut(u); recreate() }.setNegativeButton("İptal", null).show() }))
        }
        list.addView(rowCard("Ayarlar", "Uygulama ayarları", R.drawable.ic_settings, { settingsPage(null) }))
        list.addView(rowCard("Ekolayzır", "Ses ve bas ayarları", R.drawable.ic_eq, { App.openEq(this) }))
        if (App.bool("home_favs", true)) {
            list.addView(sectionHeader("Favori Kanallar") { go(TvActivity::class.java) })
            val f = App.favs()
            list.addView(if (f.isEmpty()) hint("Bir kanala uzun basıp Favorilere ekleyin; burada görünür.") else hlist(f, "Favori"))
        }
        if (App.bool("home_recent", true)) {
            list.addView(sectionHeader("Son İçerikler") { })
            val r = App.recents()
            list.addView(if (r.isEmpty()) hint("Oynattığın içerikler burada görünür.") else hlist(r, "Son"))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar())
        setContentView(root)
        if (App.bool("welcome", false)) Toast.makeText(this, "CarTube'a hoş geldin", Toast.LENGTH_SHORT).show()
    }

    private fun miniPlayer(): View {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(36), dp(12), dp(10)) }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD); maxLines = 1 }
        sub = TextView(this).apply { setTextColor(grey); textSize = 13f; maxLines = 1 }
        tx.addView(title); tx.addView(sub)
        row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        playBtn = ImageButton(this).apply {
            background = Theme.circle(Theme.mix(Theme.bg(), hk, 0.45f), Theme.dim(hk)); setImageResource(R.drawable.ic_play); setColorFilter(Color.WHITE)
            setOnClickListener { val p = App.player; if (p.isPlaying) p.pause() else p.play() }
        }
        row.addView(playBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        row.addView(Switch(this).apply {
            text = "Araçta aç"; setTextColor(grey); isChecked = App.carMode
            setOnCheckedChangeListener { _, c -> App.carMode = c }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
        return row
    }

    private fun circleBtn(icon: Int, onClick: () -> Unit) = ImageButton(this).apply {
        background = Theme.circle(Theme.mix(Theme.bg(), hk, 0.35f), hk); setImageResource(icon); setColorFilter(Color.WHITE)
        setOnClickListener { onClick() }
    }

    private fun bottomBar(): View {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(16), dp(20)); setBackgroundColor(Color.parseColor("#12171A")) }
        row.addView(TextView(this).apply { text = "Ana ekran"; setTextColor(Color.WHITE); textSize = 20f; setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, -2, 1f))
        fun lp() = LinearLayout.LayoutParams(dp(52), dp(52)).apply { leftMargin = dp(6) }
        row.addView(circleBtn(R.drawable.ic_mic) { App.voice(this) }, lp())
        row.addView(circleBtn(R.drawable.ic_edit) { settingsPage("home") }, lp())
        row.addView(circleBtn(R.drawable.ic_settings) { settingsPage(null) }, lp())
        return row
    }

    private fun card(t: String, s: String, icon: Int, h: Int, onClick: () -> Unit): View {
        val f = FrameLayout(this).apply { background = Theme.homeCard(); setOnClickListener { onClick() } }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(22), dp(14), dp(22), dp(14)) }
        col.addView(ImageView(this).apply { setImageResource(icon); setColorFilter(hk) }, LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 30f * ts; setTypeface(null, Typeface.BOLD) })
        col.addView(TextView(this).apply { text = s; setTextColor(grey); textSize = 16f * ts })
        f.addView(col, FrameLayout.LayoutParams(-1, -1))
        f.addView(ImageView(this).apply { background = Theme.circle(Color.parseColor("#CC0E1214"), Theme.dim(hk)); setImageResource(R.drawable.ic_chevron); setColorFilter(Color.WHITE); setPadding(dp(14), dp(14), dp(14), dp(14)) },
            FrameLayout.LayoutParams(dp(52), dp(52), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(16) })
        return f.also { it.layoutParams = LinearLayout.LayoutParams(-1, dp((h * App.float("ui_card_h", 1f)).toInt())).apply { topMargin = dp(8); bottomMargin = dp(4) } }
    }

    private fun rowCard(t: String, s: String, icon: Int, onClick: () -> Unit, onLong: (() -> Unit)? = null): View {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = Theme.homeCard(); setPadding(dp(18), dp(14), dp(18), dp(14))
            setOnClickListener { onClick() }
            onLong?.let { cb -> setOnLongClickListener { cb(); true } }
        }
        val box = FrameLayout(this).apply { background = Theme.roundRect(Color.parseColor("#12171A"), 18, Theme.dim(hk)) }
        box.addView(ImageView(this).apply { setImageResource(icon); setColorFilter(hk); setPadding(dp(18), dp(18), dp(18), dp(18)) }, FrameLayout.LayoutParams(dp(68), dp(68)))
        row.addView(box, LinearLayout.LayoutParams(dp(68), dp(68)))
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 24f * ts; setTypeface(null, Typeface.BOLD); maxLines = 1 })
        tx.addView(TextView(this).apply { text = s; setTextColor(grey); textSize = 16f * ts; maxLines = 1 })
        row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(18) })
        row.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(4) }
        return row
    }

    private fun sectionHeader(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = "$t  ›"; setTextColor(Color.WHITE); textSize = 22f * ts; setTypeface(null, Typeface.BOLD)
        setPadding(dp(8), dp(22), dp(8), dp(8)); setOnClickListener { onClick() }
    }

    private fun hint(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.parseColor("#B8C4D0")); textSize = 16f * ts
        background = Theme.roundRect(Theme.mix(Color.parseColor("#101821"), Theme.set(), 0.18f), 18)
        setPadding(dp(18), dp(18), dp(18), dp(18))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { leftMargin = dp(4); rightMargin = dp(4) }
    }

    private fun hlist(items: List<Pair<String, String>>, subText: String): View = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        addView(LinearLayout(this@MainActivity).apply { items.forEach { (n, u) -> addView(tile(n, subText) { App.play(n, u) }) } })
    }

    private fun tile(n: String, s: String, onClick: () -> Unit): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
            background = Theme.roundRect(Theme.mix(Color.parseColor("#101821"), Theme.set(), 0.18f), 22)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(160), -2).apply { rightMargin = dp(10) }
        }
        c.addView(FrameLayout(this).apply { background = Theme.roundRect(Color.parseColor("#0E1214"), 14)
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_play); setColorFilter(hk) }, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER)) },
            LinearLayout.LayoutParams(-1, dp(80)))
        c.addView(TextView(this).apply { text = n; setTextColor(Color.WHITE); textSize = 15f * ts; setTypeface(null, Typeface.BOLD); maxLines = 2; setPadding(0, dp(8), 0, 0) })
        c.addView(TextView(this).apply { text = s; setTextColor(grey); textSize = 13f * ts })
        return c
    }

    private fun addShortcut() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Ad"; setSingleLine() }
        val url = EditText(this).apply { hint = "Adres (örn. example.com)"; setSingleLine() }
        l.addView(name); l.addView(url)
        AlertDialog.Builder(this).setTitle("Kısayol ekle").setView(l)
            .setPositiveButton("Ekle") { _, _ ->
                var u = url.text.toString().trim()
                if (u.isNotBlank()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    App.addShortcut(name.text.toString().ifBlank { u }, u); recreate()
                }
            }.setNegativeButton("İptal", null).show()
    }

    private fun refresh() {
        val p = App.player
        val t = p.mediaMetadata.title?.toString()
        title.text = t ?: "Oynatılan içerik yok"
        sub.text = if (t == null) "Kontrol etmek için bir içerik başlat" else if (p.isPlaying) "Oynatılıyor" else "Duraklatıldı"
        playBtn.setImageResource(if (p.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
    }
    override fun onStart() { super.onStart(); App.player.addListener(listener); refresh() }
    override fun onStop() { super.onStop(); App.player.removeListener(listener) }
    override fun onRestart() { super.onRestart(); recreate() }
}
