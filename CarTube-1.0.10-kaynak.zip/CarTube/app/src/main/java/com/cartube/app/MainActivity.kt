package com.cartube.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player

class MainActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var playBtn: ImageButton

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(p: Boolean) = refresh()
        override fun onMediaItemTransition(m: MediaItem?, r: Int) = refresh()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0E1214")) }
        root.addView(miniPlayer())
        root.addView(headerRow())
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(12)) }
        list.addView(card("TV", "Canlı TV ve IPTV", R.drawable.ic_tv, 170) { startActivity(Intent(this, TvActivity::class.java)) })
        list.addView(card("Youtube", "Video izle", R.drawable.ic_play, 120) { startActivity(Intent(this, YouTubeActivity::class.java)) })
        list.addView(card("Ekran Yansıtma", "Telefon ekranını göster", R.drawable.ic_cast, 170) { startActivity(Intent(this, MirrorActivity::class.java)) })
        list.addView(card("Radyo", "İnternet Radyoları", R.drawable.ic_radio, 100) { startActivity(Intent(this, RadioActivity::class.java)) })
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar())
        setContentView(root)
    }

    private fun miniPlayer(): View {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(36), dp(12), dp(10)) }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD); maxLines = 1 }
        sub = TextView(this).apply { setTextColor(Color.parseColor("#B0B5B8")); textSize = 13f; maxLines = 1 }
        tx.addView(title); tx.addView(sub)
        row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        playBtn = ImageButton(this).apply {
            background = round("#2F7D6B"); setImageResource(R.drawable.ic_play); setColorFilter(Color.parseColor("#0E1214"))
            setOnClickListener { val p = App.player; if (p.isPlaying) p.pause() else p.play() }
        }
        row.addView(playBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        val sw = Switch(this).apply {
            text = "Araçta aç"; setTextColor(Color.parseColor("#B0B5B8")); isChecked = App.carMode
            setOnCheckedChangeListener { _, c -> App.carMode = c }
        }
        row.addView(sw, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
        return row
    }

    private fun headerRow(): View = TextView(this).apply {
        text = "CarTube"; setTextColor(Color.WHITE); textSize = 24f; setTypeface(null, Typeface.BOLD)
        letterSpacing = 0.05f; setPadding(dp(20), dp(8), dp(20), dp(8))
    }

    private fun bottomBar(): View {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(16), dp(20)); setBackgroundColor(Color.parseColor("#12171A")) }
        row.addView(TextView(this).apply { text = "Ana ekran"; setTextColor(Color.WHITE); textSize = 20f; setTypeface(null, Typeface.BOLD) },
            LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(ImageButton(this).apply {
            background = round("#5C4A24"); setImageResource(R.drawable.ic_tune); setOnClickListener { settings() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        return row
    }

    private fun round(c: String) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(Color.parseColor(c)); setStroke(dp(1), Color.parseColor("#B8955A"))
    }

    private fun card(t: String, s: String, icon: Int, h: Int, onClick: () -> Unit): View {
        val f = FrameLayout(this).apply { setBackgroundResource(R.drawable.card_bg); setOnClickListener { onClick() } }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(22), dp(14), dp(22), dp(14)) }
        col.addView(ImageView(this).apply { setImageResource(icon) }, LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 30f; setTypeface(null, Typeface.BOLD) })
        col.addView(TextView(this).apply { text = s; setTextColor(Color.parseColor("#B0B5B8")); textSize = 16f })
        f.addView(col, FrameLayout.LayoutParams(-1, -1))
        f.addView(ImageView(this).apply { setBackgroundResource(R.drawable.chev_bg); setImageResource(R.drawable.ic_chevron); setPadding(dp(14), dp(14), dp(14), dp(14)) },
            FrameLayout.LayoutParams(dp(52), dp(52), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(16) })
        return f.also { it.layoutParams = LinearLayout.LayoutParams(-1, dp(h)).apply { topMargin = dp(8); bottomMargin = dp(4) } }
    }

    private fun settings() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val m3u = EditText(this).apply { hint = "M3U / IPTV liste adresi (URL)"; setText(App.m3uUrl); setSingleLine() }
        val rad = EditText(this).apply { hint = "Radyolar: her satıra  Ad|Yayın URL"; setText(App.radios); minLines = 4; gravity = Gravity.TOP }
        l.addView(m3u); l.addView(rad)
        AlertDialog.Builder(this).setTitle("Ayarlar • CarTube 1.0.10").setView(l)
            .setPositiveButton("Kaydet") { _, _ -> App.m3uUrl = m3u.text.toString().trim(); App.radios = rad.text.toString() }
            .setNegativeButton("İptal", null).show()
    }

    private fun refresh() {
        val p = App.player
        val t = p.mediaMetadata.title?.toString()
        title.text = t ?: "Oynatılan içerik yok"
        sub.text = if (t == null) "Kontrol etmek için bir içerik başlat" else if (p.isPlaying) "Oynatılıyor" else "Duraklatıldı"
        playBtn.setImageResource(if (p.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
    }
    override fun onStart() { super.onStart(); App.player.addListener(listener); refresh() }
    override fun onStop() { super.onStop(); App.player.removeListener(listener) }
}
