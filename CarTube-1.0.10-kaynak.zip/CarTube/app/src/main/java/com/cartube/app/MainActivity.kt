package com.cartube.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player

class MainActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val ts get() = App.float("ui_text", App.D_TEXT)
    private val screenDp get() = resources.displayMetrics.widthPixels / resources.displayMetrics.density
    private fun clamp(v: Float, lo: Float, hi: Float) = maxOf(lo, minOf(hi, v))

    // Üst oynatıcı çubuğundaki görünümler ve renkler
    private lateinit var tvTitle: TextView
    private lateinit var tvSub: TextView
    private lateinit var playBtn: ImageButton
    private val grey = Color.parseColor("#B8C4D0")
    private val hk get() = Theme.home()

    // Oynatma durumu değişince üst çubuğu günceller
    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = refresh()
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = refresh()
    }

    private fun go(c: Class<*>) = startActivity(Intent(this, c))
    private fun webOpen(url: String) = startActivity(Intent(this, YouTubeActivity::class.java).putExtra("url", url))
    private fun settingsPage(page: String?) {
        val i = Intent(this, SettingsActivity::class.java)
        if (page != null) i.putExtra("page", page)
        startActivity(i)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.bg()) }
        root.addView(miniPlayer())
        root.addView(TextView(this).apply {
            text = "CarTube"; setTextColor(Color.WHITE); textSize = 24f; setTypeface(null, Typeface.BOLD)
            letterSpacing = 0.05f; setPadding(dp(20), dp(8), dp(20), dp(8)) })
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(16)) }
        val builders = mapOf<String, () -> View?>(
            "tv" to { if (App.bool("home_tv", true)) card("TV", "Canlı TV ve IPTV", R.drawable.ic_tv, 170) { go(TvActivity::class.java) } else null },
            "yt" to { if (App.bool("home_yt", true)) card("Youtube", "Video izle", R.drawable.ic_play, 120) { go(YouTubeActivity::class.java) } else null },
            "cast" to { if (App.bool("home_cast", true)) card("Ekran Yansıtma", "Telefon ekranını göster", R.drawable.ic_cast, 170) { go(MirrorActivity::class.java) } else null },
            "radio" to { if (App.bool("home_radio", true)) rowCard("Radyo", "İnternet Radyoları", R.drawable.ic_radio, { go(RadioActivity::class.java) }) else null },
            "media" to { if (App.bool("home_media", true)) rowCard("Medya", "Telefondaki video ve müzikler", R.drawable.ic_media, { go(MediaActivity::class.java) }) else null },
            "phone" to { if (App.bool("home_phone", true)) rowCard("Telefonu Kullan", "Araç için seçtiğin telefon uygulamaları", R.drawable.ic_phone, {
                startActivity(Intent(this, PhoneAppsActivity::class.java)) }) else null },
            "web" to { if (App.bool("home_web", true)) rowCard("Web", "Tarayıcı ve Medya", R.drawable.ic_globe, {
                webOpen(App.str("web_home").ifBlank { "https://www.google.com" }) }) else null })
        App.homeOrder().forEach { k -> builders[k]?.invoke()?.let { list.addView(it) } }
        list.addView(rowCard("Kısayol ekle", "Kendi web siteniz", R.drawable.ic_add, { addShortcut() }))
        App.shortcuts().forEach { (n, u) ->
            list.addView(rowCard(n, u, R.drawable.ic_globe, { webOpen(u) }, {
                AlertDialog.Builder(this).setMessage("\"$n\" kısayolu silinsin mi?")
                    .setPositiveButton(L.t("Sil")) { _, _ -> App.removeShortcut(u); recreate() }.setNegativeButton(L.t("İptal"), null).show() }))
        }
        list.addView(rowCard("Ayarlar", "Uygulama ayarları", R.drawable.ic_settings, { settingsPage(null) }))
        list.addView(rowCard("Ekolayzır", "Ses ve bas ayarları", R.drawable.ic_eq, { App.openEq(this) }))
        if (App.bool("home_favs", true)) {
            list.addView(sectionHeader("Favori Kanallar") { go(TvActivity::class.java) })
            val f = App.favs()
            list.addView(if (f.isEmpty()) hint("Bir kanala uzun basıp Favorilere ekleyin; burada görünür.") else hlist(f, "Favori"))
        }
        if (App.bool("home_recent", true)) {
            list.addView(sectionHeader("Son İçerikler") { })
            val r = App.recents()
            list.addView(if (r.isEmpty()) hint("Oynattığın içerikler burada görünür.") else hlist(r, "Son"))
        }
        scroll.addView(list)
        if (App.int("nav_pos", 0) == 1) root.addView(bottomBar())
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (App.int("nav_pos", 0) == 0) root.addView(bottomBar())
        setContentView(root)
        App.greet(this, false)
    }

    private fun skipBtn(icon: Int, dir: Int, w: Float, h: Float) = ImageButton(this).apply {
        setBackgroundColor(Color.TRANSPARENT); setImageResource(icon); setColorFilter(grey)
        setOnClickListener { App.skip(dir, false) }
        setOnLongClickListener { App.skip(dir, true); true }
        layoutParams = LinearLayout.LayoutParams(dp(w.toInt()), dp(h.toInt()))
    }

    private fun miniPlayer(): View {
        val bs = App.float("bar_size", App.D_BAR)
        val fs = clamp(bs, 0.5f, 1.3f)
        // Düğme boyutu ekrana sığacak şekilde sınırlanır; metin kalan boşluğa sıkışır ve "…" ile kısalır
        val unit = minOf(48f * bs, (screenDp - 24f - 110f - 90f) / 2.85f)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(36), dp(12), dp(10)) }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvTitle = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f * fs; setTypeface(null, Typeface.BOLD); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        tvSub = TextView(this).apply { setTextColor(grey); textSize = 13f * fs; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        tx.addView(tvTitle); tx.addView(tvSub)
        row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(skipBtn(R.drawable.ic_prev, -1, unit * 0.83f, unit))
        playBtn = ImageButton(this).apply {
            background = Theme.circle(Theme.mix(Theme.bg(), hk, 0.45f), Theme.dim(hk)); setImageResource(R.drawable.ic_play); setColorFilter(Color.WHITE)
            setOnClickListener { App.togglePlay() }
            setOnLongClickListener { if (App.bool("pp_stop", true)) { App.stopAll(); true } else false }
        }
        row.addView(playBtn, LinearLayout.LayoutParams(dp(unit.toInt()), dp(unit.toInt())))
        row.addView(skipBtn(R.drawable.ic_next, 1, unit * 0.83f, unit))
        row.addView(Switch(this).apply {
            text = L.t("Araçta aç"); setTextColor(grey); textSize = 11f * clamp(bs, 0.7f, 1.2f); maxLines = 1; isChecked = App.carMode
            setOnCheckedChangeListener { _, c -> App.carMode = c }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        return row
    }

    private fun circleBtn(icon: Int, onClick: () -> Unit) = ImageButton(this).apply {
        background = Theme.circle(Theme.mix(Theme.bg(), hk, 0.35f), hk); setImageResource(icon); setColorFilter(Color.WHITE)
        setOnClickListener { onClick() }
    }

    private fun bottomBar(): View {
        val ns = App.float("nav_size", App.D_NAV)
        val btn = minOf(52f * ns, (screenDp - 36f - 18f - 110f) / 3f)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(16), dp(20)); setBackgroundColor(Color.parseColor("#12171A")) }
        row.addView(TextView(this).apply { text = L.t("Ana ekran"); setTextColor(Color.WHITE); textSize = 20f * clamp(ns, 0.5f, 1.3f); setTypeface(null, Typeface.BOLD); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(0, -2, 1f))
        fun lp() = LinearLayout.LayoutParams(dp(btn.toInt()), dp(btn.toInt())).apply { leftMargin = dp(6) }
        row.addView(circleBtn(R.drawable.ic_mic) { go(VoiceActivity::class.java) }, lp())
        row.addView(circleBtn(R.drawable.ic_edit) { settingsPage("home") }, lp())
        row.addView(circleBtn(R.drawable.ic_settings) { settingsPage(null) }, lp())
        return row
    }

    private fun card(t: String, s: String, icon: Int, h: Int, onClick: () -> Unit): View {
        val f = FrameLayout(this).apply { background = Theme.homeCard(); setOnClickListener { onClick() } }
        f.minimumHeight = dp((h * App.float("ui_card_h", App.D_PANEL)).toInt())
        val k = clamp(ts, 0.6f, 1.4f)
        val chev = (52 * clamp(ts, 0.7f, 1.1f)).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(22), dp(14), dp(chev + 28), dp(14)) }
        col.addView(ImageView(this).apply { setImageResource(icon); setColorFilter(hk) }, LinearLayout.LayoutParams(dp((44 * k).toInt()), dp((44 * k).toInt())))
        col.addView(TextView(this).apply { text = L.t(t); setTextColor(Color.WHITE); textSize = 30f * ts; setTypeface(null, Typeface.BOLD); maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        col.addView(TextView(this).apply { text = L.t(s); setTextColor(grey); textSize = 16f * ts; maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        f.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL))
        f.addView(ImageView(this).apply { background = Theme.circle(Color.parseColor("#CC0E1214"), Theme.dim(hk)); setImageResource(R.drawable.ic_chevron); setColorFilter(Color.WHITE); setPadding(dp(chev / 4), dp(chev / 4), dp(chev / 4), dp(chev / 4)) },
            FrameLayout.LayoutParams(dp(chev), dp(chev), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(16) })
        return f.also { it.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(4) } }
    }

    private fun rowCard(t: String, s: String, icon: Int, onClick: () -> Unit, onLong: (() -> Unit)? = null): View {
        val k = clamp(ts, 0.7f, 1.2f)
        val bx = (68 * k).toInt()
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = Theme.homeCard(); setPadding(dp(18), dp(14), dp(18), dp(14))
            setOnClickListener { onClick() }
            onLong?.let { cb -> setOnLongClickListener { cb(); true } }
        }
        val box = FrameLayout(this).apply { background = Theme.roundRect(Color.parseColor("#12171A"), 18, Theme.dim(hk)) }
        box.addView(ImageView(this).apply { setImageResource(icon); setColorFilter(hk); setPadding(dp(bx / 4), dp(bx / 4), dp(bx / 4), dp(bx / 4)) }, FrameLayout.LayoutParams(dp(bx), dp(bx)))
        row.addView(box, LinearLayout.LayoutParams(dp(bx), dp(bx)))
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(TextView(this).apply { text = L.t(t); setTextColor(Color.WHITE); textSize = 24f * ts; setTypeface(null, Typeface.BOLD); maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        tx.addView(TextView(this).apply { text = L.t(s); setTextColor(grey); textSize = 16f * ts; maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(18) })
        row.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(4) }
        return row
    }

    private fun sectionHeader(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = L.t(t) + "  ›"; setTextColor(Color.WHITE); textSize = 22f * ts; setTypeface(null, Typeface.BOLD)
        setPadding(dp(8), dp(22), dp(8), dp(8)); setOnClickListener { onClick() }
    }

    private fun hint(t: String) = TextView(this).apply {
        text = L.t(t); setTextColor(Color.parseColor("#B8C4D0")); textSize = 16f * ts
        background = Theme.roundRect(Theme.mix(Color.parseColor("#101821"), Theme.set(), 0.18f), 18)
        setPadding(dp(18), dp(18), dp(18), dp(18))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { leftMargin = dp(4); rightMargin = dp(4) }
    }

    private fun hlist(items: List<Pair<String, String>>, subText: String): View = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        addView(LinearLayout(this@MainActivity).apply { items.forEach { (n, u) -> addView(tile(n, subText) { App.play(n, u) }) } })
    }

    private fun tile(n: String, s: String, onClick: () -> Unit): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
            background = Theme.roundRect(Theme.mix(Color.parseColor("#101821"), Theme.set(), 0.18f), 22)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(160), -2).apply { rightMargin = dp(10) }
        }
        c.addView(FrameLayout(this).apply { background = Theme.roundRect(Color.parseColor("#0E1214"), 14)
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_play); setColorFilter(hk) }, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER)) },
            LinearLayout.LayoutParams(-1, dp(80)))
        c.addView(TextView(this).apply { text = n; setTextColor(Color.WHITE); textSize = 15f * ts; setTypeface(null, Typeface.BOLD); maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(8), 0, 0) })
        c.addView(TextView(this).apply { text = L.t(s); setTextColor(grey); textSize = 13f * ts })
        return c
    }

    private fun addShortcut() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = L.t("Ad"); setSingleLine() }
        val url = EditText(this).apply { hint = L.t("Adres (örn. example.com)"); setSingleLine() }
        l.addView(name); l.addView(url)
        AlertDialog.Builder(this).setTitle(L.t("Kısayol ekle")).setView(l)
            .setPositiveButton(L.t("Ekle")) { _, _ ->
                var u = url.text.toString().trim()
                if (u.isNotBlank()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    App.addShortcut(name.text.toString().ifBlank { u }, u); recreate()
                }
            }.setNegativeButton(L.t("İptal"), null).show()
    }

    private fun refresh() {
        val t = App.nowTitle()
        tvTitle.text = t ?: L.t("Oynatılan içerik yok")
        tvSub.text = if (t == null) L.t("Kontrol etmek için bir içerik başlat") else if (App.nowPlaying()) L.t("Oynatılıyor") else L.t("Duraklatıldı")
        playBtn.setImageResource(if (App.nowPlaying()) R.drawable.ic_pause else R.drawable.ic_play)
    }
    override fun onStart() { super.onStart(); App.player.addListener(listener); App.onState = { runOnUiThread { refresh() } }; refresh() }
    override fun onStop() { super.onStop(); App.player.removeListener(listener); App.onState = null }
    override fun onRestart() { super.onRestart(); recreate() }
}
