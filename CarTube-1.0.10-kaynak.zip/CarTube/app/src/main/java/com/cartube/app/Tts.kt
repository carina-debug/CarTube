package com.cartube.app

import android.speech.tts.TextToSpeech
import java.util.Locale

object Tts {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    fun speak(text: String) {
        if (tts == null) {
            pending = text
            tts = TextToSpeech(App.ctx) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    ready = true
                    tts?.language = if (L.isEn) Locale.US else Locale("tr", "TR")
                    pending?.let { say(it); pending = null }
                }
            }
        } else if (ready) say(text) else pending = text
    }

    /** "Şimdi dene": karşılamayı seslendirir; olmazsa nedenini söyler. */
    fun test(c: android.content.Context, text: String, report: (String) -> Unit) {
        val am = c.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
        if (am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) == 0) { report("Medya sesi kapalı"); return }
        var engine: TextToSpeech? = null
        engine = TextToSpeech(c.applicationContext) { st ->
            val e = engine
            if (st != TextToSpeech.SUCCESS || e == null) { report("Konuşma motoru başlatılamadı"); return@TextToSpeech }
            val loc = if (L.isEn) Locale.US else Locale("tr", "TR")
            val r = e.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) { report("Bu dil için ses verisi yok"); return@TextToSpeech }
            e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "cartube-test")
            report("Seslendiriliyor…")
        }
    }

    private fun say(t: String) { tts?.language = if (L.isEn) Locale.US else Locale("tr", "TR"); tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "cartube") }
}
