package com.cartube.app

import android.content.Context
import android.content.Intent
import android.net.Uri

/** Sesle verilen komutları çalıştırır ve kullanıcıya gösterilecek kısa bir sonuç metni döndürür. */
object VoiceCmd {
    private fun open(c: Context, cls: Class<*>) = c.startActivity(Intent(c, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    private fun web(c: Context, url: String) = c.startActivity(Intent(c, YouTubeActivity::class.java).putExtra("url", url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    /** "açık: oynat" gibi satırlarla tanımlanan kelime değiştirmeleri uygular. */
    fun replaceWords(text: String): String {
        var t = text
        App.str("voice_repl").lines().forEach { line ->
            val p = line.split(":", limit = 2)
            if (p.size == 2 && p[0].isNotBlank()) t = t.replace(Regex("\\b" + Regex.escape(p[0].trim()) + "\\b", RegexOption.IGNORE_CASE), p[1].trim())
        }
        return t
    }

    fun run(c: Context, raw: String): String {
        val text = replaceWords(raw)
        val l = text.lowercase().trim()
        fun after(vararg k: String): String { var s = l; k.forEach { s = s.replace(it, " ") }; return s.replace(Regex("\\s+"), " ").trim() }
        return when {
            Regex("youtube|yutup|you tube").containsMatchIn(l) -> {
                val q = after("youtube'da", "youtube da", "youtube", "you tube", "yutup", "aç", "ara", "search", "open", "play")
                web(c, if (q.isBlank()) "https://m.youtube.com" else "https://m.youtube.com/results?search_query=" + Uri.encode(q))
                if (q.isBlank()) L.t("Youtube") else "Youtube: $q"
            }
            l.startsWith("radyo") || l.contains("radio") -> {
                val q = after("radyo", "radio", "aç", "çal", "open", "play")
                val m = Stores.radio.lists.flatMap { it.items }.firstOrNull { q.isNotBlank() && it.n.lowercase().contains(q) }
                if (m != null) { App.play(m.n, m.u); L.t("Çalıyor: ") + m.n } else { open(c, RadioActivity::class.java); L.t("Radyo") }
            }
            l.contains("televizyon") || Regex("\\btv\\b").containsMatchIn(l) -> { open(c, TvActivity::class.java); "TV" }
            l.contains("ayar") || l.contains("settings") -> { open(c, SettingsActivity::class.java); L.t("Ayarlar") }
            l.contains("ekolayzır") || l.contains("equalizer") || l.contains("ekolayzer") -> { open(c, EqualizerActivity::class.java); L.t("Ekolayzır") }
            l.contains("yansıt") || l.contains("mirror") -> { open(c, MirrorActivity::class.java); L.t("Ekran Yansıtma") }
            l.contains("medya") || l.contains("müzik") || l.contains("music") || l.contains("media") -> { open(c, MediaActivity::class.java); L.t("Medya") }
            l.contains("durdur") || l == "dur" || l.contains("stop") -> { App.stopAll(); L.t("Durdur") }
            l.contains("duraklat") || l.contains("pause") -> { App.pauseAll(); L.t("Duraklat") }
            l.contains("devam") || l.contains("oynat") || l == "play" || l.contains("resume") -> { App.resume(); L.t("Oynat") }
            l.contains("sonraki") || l.contains("next") -> { App.skip(1, true); L.t("Sonraki") }
            l.contains("önceki") || l.contains("previous") -> { App.skip(-1, true); L.t("Önceki") }
            else -> { web(c, "https://www.google.com/search?q=" + Uri.encode(text)); "Google: $text" }
        }
    }
}

object VoiceLangs {
    val names = listOf("Türkçe (Türkiye)", "English (US)", "English (UK)", "Deutsch", "Français", "Русский", "العربية", "Español")
    val tags = listOf("tr-TR", "en-US", "en-GB", "de-DE", "fr-FR", "ru-RU", "ar-SA", "es-ES")
}
