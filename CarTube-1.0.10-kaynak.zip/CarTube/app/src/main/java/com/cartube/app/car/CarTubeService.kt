package com.cartube.app.car

import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.model.*
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import com.cartube.app.*

class CarTubeService : CarAppService() {
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = object : Session() {
        override fun onCreateScreen(intent: Intent): Screen = HomeScreen(carContext)
    }
}

private fun icon(c: CarContext, res: Int) =
    CarIcon.Builder(IconCompat.createWithResource(c, res)).build()

class HomeScreen(c: CarContext) : Screen(c) {
    private fun open(cls: Class<*>) {
        carContext.startActivity(Intent(carContext, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        CarToast.makeText(carContext, "Telefonda açıldı", CarToast.LENGTH_SHORT).show()
    }
    private fun item(t: String, s: String, res: Int, onClick: () -> Unit) =
        GridItem.Builder().setTitle(t).setText(s).setImage(icon(carContext, res), GridItem.IMAGE_TYPE_ICON)
            .setOnClickListener(onClick).build()

    override fun onGetTemplate(): Template {
        val list = ItemList.Builder()
            .addItem(item("TV", "Canlı TV ve IPTV", R.drawable.ic_tv) { open(TvActivity::class.java) })
            .addItem(item("Youtube", "Video izle", R.drawable.ic_play) { open(YouTubeActivity::class.java) })
            .addItem(item("Ekran Yansıtma", "Telefon ekranını göster", R.drawable.ic_cast) { open(MirrorActivity::class.java) })
            .addItem(item("Radyo", "İnternet Radyoları", R.drawable.ic_radio) { screenManager.push(RadioCarScreen(carContext)) })
            .build()
        return GridTemplate.Builder().setTitle("CarTube").setHeaderAction(Action.APP_ICON).setSingleList(list).build()
    }
}

class RadioCarScreen(c: CarContext) : Screen(c) {
    override fun onGetTemplate(): Template {
        val radios = App.radioList()
        val b = ItemList.Builder()
        if (radios.isEmpty()) b.setNoItemsMessage("Radyo yok. Telefondan Ayarlar'a ekleyin.")
        radios.take(6).forEach { (n, u) ->
            b.addItem(Row.Builder().setTitle(n).setOnClickListener {
                App.play(n, u); CarToast.makeText(carContext, "Çalıyor: $n", CarToast.LENGTH_SHORT).show()
            }.build())
        }
        return ListTemplate.Builder().setTitle("Radyo").setHeaderAction(Action.BACK).setSingleList(b.build()).build()
    }
}
