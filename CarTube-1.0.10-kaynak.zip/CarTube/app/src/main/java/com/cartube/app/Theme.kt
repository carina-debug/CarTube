package com.cartube.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable

object Theme {
    val names = listOf("Altın + Mavi", "Altın", "Mavi", "Yeşil", "Kırmızı", "Mor")
    private val gold = Color.parseColor("#D9B26B")
    private val blue = Color.parseColor("#4DA3FF")
    private val green = Color.parseColor("#4CC38A")
    private val red = Color.parseColor("#FF6B6B")
    private val purple = Color.parseColor("#B58CFF")
    private fun pair(): Pair<Int, Int> = when (App.int("theme", 0)) {
        0 -> gold to blue; 1 -> gold to gold; 2 -> blue to blue
        3 -> green to green; 4 -> red to red; else -> purple to purple
    }
    fun home() = pair().first
    fun set() = pair().second
    fun bg() = Color.parseColor("#0E1214")
    fun setBg() = mix(Color.parseColor("#0A101A"), set(), 0.04f)
    fun setCard() = mix(Color.parseColor("#101821"), set(), 0.18f)
    fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())
    fun dim(c: Int) = Color.argb(0x99, Color.red(c), Color.green(c), Color.blue(c))
    private fun dp(v: Float) = (v * App.ctx.resources.displayMetrics.density).toInt()
    fun circle(fill: Int, stroke: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(fill); setStroke(dp(1.5f), stroke) }
    fun roundRect(fill: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp.toFloat()).toFloat(); setColor(fill); if (stroke != null) setStroke(dp(1.5f), stroke) }
    fun homeCard() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#23272A"), Color.parseColor("#0F1316"))).apply {
        cornerRadius = dp(32f).toFloat(); setStroke(dp(1.5f), dim(home())) }
}
