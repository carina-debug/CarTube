package com.cartube.app

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/**
 * pick=true : telefondaki tüm uygulamalar listelenir, dokununca araç listesine eklenir/çıkarılır.
 * pick=false: araç için seçilen uygulamalar listelenir, dokununca telefonda açılır.
 */
class PhoneAppsActivity : AppCompatActivity() {
    private val pick get() = intent.getBooleanExtra("pick", false)
    private val blue get() = Theme.set()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private lateinit var col: LinearLayout

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        root.addView(TextView(this).apply {
            text = L.t(if (pick) "Araç uygulamaları" else "Telefonu Kullan")
            setTextColor(Color.WHITE); textSize = 24f; setTypeface(null, Typeface.BOLD)
            setPadding(dp(20), dp(40), dp(20), dp(4)) })
        root.addView(TextView(this).apply {
            text = L.t(if (pick) "Araç ekranında görünmesini istediğin uygulamalara dokun" else "Dokununca uygulama telefonda açılır")
            setTextColor(Color.parseColor("#B8C4D0")); textSize = 14f; setPadding(dp(20), 0, dp(20), dp(8)) })
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(24)) }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        Thread {
            val list = if (pick) PhoneApps.installed(this) else PhoneApps.selectedInfos(this)
            runOnUiThread { render(list) }
        }.start()
    }

    private fun card() = LinearLayout(this).apply {
        background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(Theme.setCard()) }
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5); bottomMargin = dp(5) }
    }

    private fun label(t: String, sub: String? = null) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(this@PhoneAppsActivity).apply { text = t; setTextColor(Color.WHITE); textSize = 18f; setTypeface(null, Typeface.BOLD); maxLines = 1 })
        if (sub != null) addView(TextView(this@PhoneAppsActivity).apply { text = sub; setTextColor(Color.parseColor("#B8C4D0")); textSize = 13f })
    }

    private fun render(list: List<PhoneApps.Info>) {
        col.removeAllViews()
        if (!pick) {
            val add = card().apply {
                addView(ImageView(this@PhoneAppsActivity).apply { setImageResource(R.drawable.ic_add); setColorFilter(blue) }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(14) })
                addView(label(L.t("Uygulama ekle / çıkar"), L.t("Telefondaki uygulamalardan seç")), LinearLayout.LayoutParams(0, -2, 1f))
                setOnClickListener { startActivity(Intent(this@PhoneAppsActivity, PhoneAppsActivity::class.java).putExtra("pick", true)) }
            }
            col.addView(add)
            if (list.isEmpty()) col.addView(TextView(this).apply {
                text = L.t("Henüz uygulama seçilmedi."); setTextColor(Color.parseColor("#B8C4D0")); textSize = 16f; setPadding(dp(8), dp(16), dp(8), dp(8)) })
        }
        list.forEach { a ->
            val c = card()
            c.addView(ImageView(this).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(14) })
            c.addView(label(a.label), LinearLayout.LayoutParams(0, -2, 1f))
            if (pick) {
                val cb = CheckBox(this).apply { isChecked = PhoneApps.isSelected(a.pkg)
                    buttonTintList = android.content.res.ColorStateList.valueOf(blue)
                    setOnCheckedChangeListener { _, v -> PhoneApps.toggle(a.pkg, v) } }
                c.addView(cb)
                c.setOnClickListener { cb.toggle() }
            } else {
                c.setOnClickListener { PhoneApps.launch(this, a.pkg) }
            }
            col.addView(c)
        }
    }
}
