package com.cartube.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** Ekran yansıtma: telefon ekranı Android Auto'da "CarTube Tam Ekran" içinde gösterilir (yalnızca görüntü). */
class MirrorActivity : AppCompatActivity() {
    private lateinit var info: TextView
    private lateinit var btn: Button
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val ask = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data != null) {
            val i = Intent(this, MirrorService::class.java).putExtra("code", r.resultCode).putExtra("data", r.data)
            startForegroundService(i)
            btn.postDelayed({ refresh() }, 600)
        } else info.text = L.t("İzin verilmedi")
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), dp(56), dp(24), dp(16)) }
        body.addView(TextView(this).apply { text = L.t("Ekran Yansıtma"); setTextColor(Color.WHITE); textSize = 24f; setTypeface(null, Typeface.BOLD) })
        info = TextView(this).apply { setTextColor(Color.parseColor("#B8C4D0")); textSize = 16f; setPadding(0, dp(16), 0, dp(16)) }
        btn = Button(this).apply { setOnClickListener { toggle() } }
        body.addView(info); body.addView(btn)
        body.addView(TextView(this).apply {
            setTextColor(Color.parseColor("#8896A5")); textSize = 14f; setPadding(0, dp(24), 0, 0)
            text = L.t("Android Auto'da CarTube Tam Ekran'ı açıp Ekran Yansıtma düğmesine dokun. Yalnızca görüntü yansıtılır; araç ekranından dokunarak kontrol desteklenmez.")
        })
        root.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Ui.navBar(this, L.t("Ekran Yansıtma")))
        setContentView(root)
        refresh()
    }

    private fun toggle() {
        if (Mirror.active) { startService(Intent(this, MirrorService::class.java).setAction("stop")); btn.postDelayed({ refresh() }, 400) }
        else ask.launch(getSystemService(Context.MEDIA_PROJECTION_SERVICE).let { (it as MediaProjectionManager).createScreenCaptureIntent() })
    }

    private fun refresh() {
        info.text = L.t(if (Mirror.active) "Yansıtma açık." else "Yansıtma kapalı.")
        btn.text = L.t(if (Mirror.active) "Yansıtmayı durdur" else "Yansıtmayı başlat")
    }
    override fun onResume() { super.onResume(); refresh() }
}
