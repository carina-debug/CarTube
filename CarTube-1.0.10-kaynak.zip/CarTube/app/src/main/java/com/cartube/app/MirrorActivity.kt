package com.cartube.app

import android.os.Bundle
import android.view.Gravity
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MirrorActivity : AppCompatActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(TextView(this).apply {
            text = "Ekran Yansıtma\n\nBu sürümde yalnızca yer tutucu. Gerçek yansıtma için MediaProjection tabanlı modül (CarMirror) eklenecek."
            gravity = Gravity.CENTER; textSize = 18f; setPadding(48, 48, 48, 48)
        })
    }
}
