package com.cartube.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.view.KeyEvent
import android.view.Window

/** Tuş atamaları: her tuşa ayarlardan bir eylem seçilir. */
object KeyMap {
    val keys: List<Pair<String, Int>> = listOf(
        "MEDIA_STOP" to KeyEvent.KEYCODE_MEDIA_STOP,
        "MEDIA_PLAY" to KeyEvent.KEYCODE_MEDIA_PLAY,
        "MEDIA_PAUSE" to KeyEvent.KEYCODE_MEDIA_PAUSE,
        "MEDIA_PLAY_PAUSE" to KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
        "MEDIA_PREVIOUS" to KeyEvent.KEYCODE_MEDIA_PREVIOUS,
        "MEDIA_NEXT" to KeyEvent.KEYCODE_MEDIA_NEXT,
        "MEDIA_REWIND" to KeyEvent.KEYCODE_MEDIA_REWIND,
        "MEDIA_FAST_FORWARD" to KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
        "MEDIA_SKIP_BACKWARD" to KeyEvent.KEYCODE_MEDIA_SKIP_BACKWARD,
        "MEDIA_SKIP_FORWARD" to KeyEvent.KEYCODE_MEDIA_SKIP_FORWARD,
        "VOLUME_UP" to KeyEvent.KEYCODE_VOLUME_UP,
        "VOLUME_DOWN" to KeyEvent.KEYCODE_VOLUME_DOWN,
        "CHANNEL_UP" to KeyEvent.KEYCODE_CHANNEL_UP,
        "CHANNEL_DOWN" to KeyEvent.KEYCODE_CHANNEL_DOWN,
        "HEADSETHOOK" to KeyEvent.KEYCODE_HEADSETHOOK,
        "SEARCH" to KeyEvent.KEYCODE_SEARCH,
        "BACK" to KeyEvent.KEYCODE_BACK,
        "ESCAPE" to KeyEvent.KEYCODE_ESCAPE,
        "DEL" to KeyEvent.KEYCODE_DEL,
        "MENU" to KeyEvent.KEYCODE_MENU,
        "M" to KeyEvent.KEYCODE_M,
        "P" to KeyEvent.KEYCODE_P,
        "S" to KeyEvent.KEYCODE_S,
        "X" to KeyEvent.KEYCODE_X)

    // Sıra önemli: 0 = sistem varsayılanı (tuşa müdahale etme)
    val actions = listOf(
        "Varsayılan (sistem)", "Oynat / Duraklat", "Oynat", "Duraklat", "Durdur",
        "Sonraki", "Önceki", "10 sn ileri sar", "10 sn geri sar",
        "Sesi artır", "Sesi azalt", "Sesli komut", "CarTube ana ekranı", "Geri", "Hiçbir şey yapma")

    fun def(name: String): Int = when (name) {
        "MEDIA_STOP" -> 4
        "MEDIA_PLAY" -> 2
        "MEDIA_PAUSE" -> 3
        "MEDIA_PLAY_PAUSE", "HEADSETHOOK" -> 1
        "MEDIA_PREVIOUS", "CHANNEL_DOWN" -> 6
        "MEDIA_NEXT", "CHANNEL_UP" -> 5
        "MEDIA_REWIND", "MEDIA_SKIP_BACKWARD" -> 8
        "MEDIA_FAST_FORWARD", "MEDIA_SKIP_FORWARD" -> 7
        "SEARCH" -> 11
        else -> 0
    }

    /** Tuş olayını işler. true dönerse olay tüketildi. */
    fun handle(ctx: Context, act: Activity?, e: KeyEvent): Boolean {
        val vk = App.int("voice_key", 0)
        if (vk != 0 && e.keyCode == vk && App.bool("vc_on", true)) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0)
                ctx.startActivity(Intent(ctx, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return true
        }
        val name = keys.firstOrNull { it.second == e.keyCode }?.first ?: return false
        val a = App.int("key_$name", def(name))
        if (a == 0) return false
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) run(ctx, act, a)
        return true
    }

    private fun step(d: Int) {
        val list = App.radioList().ifEmpty { App.favs() }
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.second == App.nowUrl }
        val n = list[(((if (i < 0) 0 else i + d) % list.size) + list.size) % list.size]
        App.play(n.first, n.second)
    }

    private fun vol(ctx: Context, dir: Int) {
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    fun run(ctx: Context, act: Activity?, a: Int) {
        when (a) {
            1 -> App.togglePlay()
            2 -> App.resume()
            3 -> App.pauseAll()
            4 -> App.stopAll()
            5 -> step(1)
            6 -> step(-1)
            7 -> App.seekBy(10_000)
            8 -> App.seekBy(-10_000)
            9 -> vol(ctx, AudioManager.ADJUST_RAISE)
            10 -> vol(ctx, AudioManager.ADJUST_LOWER)
            11 -> ctx.startActivity(Intent(ctx, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            12 -> ctx.startActivity(Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            13 -> (act as? androidx.appcompat.app.AppCompatActivity)?.onBackPressedDispatcher?.onBackPressed()
        }
    }

    /** Uygulama içindeki tüm ekranlarda tuşları yakalar (App.kt'den takılır). */
    class KeyCb(private val base: Window.Callback, private val act: Activity) : Window.Callback by base {
        override fun dispatchKeyEvent(event: KeyEvent): Boolean =
            handle(act.applicationContext, act, event) || base.dispatchKeyEvent(event)
    }
}
