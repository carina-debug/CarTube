package com.cartube.app

import android.app.Activity
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.IBinder
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView

/** Kayan düğme: diğer uygulamaların üstünde durur, uzun dokununca sesli kontrolü açar, sürükleyerek taşınır. */
class FloatService : Service() {
    private var wm: WindowManager? = null
    private var view: View? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (view == null && Settings.canDrawOverlays(this)) add()
        return START_NOT_STICKY
    }

    private fun add() {
        val d = resources.displayMetrics.density
        val size = (52 * d).toInt()
        val lp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = (12 * d).toInt(); lp.y = (200 * d).toInt()
        val v = ImageView(this).apply {
            setImageResource(R.drawable.ic_mic); setColorFilter(Color.WHITE); setPadding((13 * d).toInt(), (13 * d).toInt(), (13 * d).toInt(), (13 * d).toInt())
            background = Theme.circle(Theme.mix(Color.parseColor("#0E1214"), Theme.set(), 0.5f), Theme.set()); alpha = 0.85f
        }
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) {
                startActivity(Intent(this@FloatService, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        })
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        v.setOnTouchListener { _, e ->
            gd.onTouchEvent(e)
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); try { wm?.updateViewLayout(v, lp) } catch (x: Exception) { } }
            }
            true
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try { wm?.addView(v, lp); view = v } catch (e: Exception) { }
    }

    override fun onDestroy() { try { view?.let { wm?.removeView(it) } } catch (e: Exception) { }; view = null; super.onDestroy() }

    companion object {
        /** Ayara göre düğmeyi açar/kapatır; izin yoksa izin ekranını açar. */
        fun sync(a: Activity) {
            if (App.bool("vc_float", false)) {
                if (!Settings.canDrawOverlays(a)) {
                    a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))); return
                }
                a.startService(Intent(a, FloatService::class.java))
            } else a.stopService(Intent(a, FloatService::class.java))
        }
    }
}
