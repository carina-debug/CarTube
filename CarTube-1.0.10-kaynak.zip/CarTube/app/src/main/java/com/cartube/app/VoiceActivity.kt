package com.cartube.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/** Sesli kontrol ekranı: büyük mikrofon düğmesi, anlık metin, sonuç ve örnek komutlar. */
class VoiceActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var result: TextView
    private lateinit var mic: ImageButton
    private var sr: SpeechRecognizer? = null
    private var listening = false
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), dp(48), dp(24), dp(16)) }
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 20f; setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER }
        mic = ImageButton(this).apply {
            background = Theme.circle(Theme.mix(Color.parseColor("#0E1214"), Theme.set(), 0.45f), Theme.set())
            setImageResource(R.drawable.ic_mic); setColorFilter(Color.WHITE); setPadding(dp(28), dp(28), dp(28), dp(28))
            setOnClickListener { if (listening) stopListening() else start() }
        }
        heard = TextView(this).apply { setTextColor(Color.parseColor("#DDE6F0")); textSize = 18f; gravity = Gravity.CENTER }
        result = TextView(this).apply { setTextColor(Theme.set()); textSize = 16f; gravity = Gravity.CENTER }
        val help = TextView(this).apply {
            setTextColor(Color.parseColor("#B8C4D0")); textSize = 14f
            text = if (L.isEn) "Try: \"youtube cats\", \"radio <name>\", \"tv\", \"media\", \"equalizer\", \"settings\", \"pause\", \"play\", \"next\", \"previous\", \"stop\". Anything else is searched on Google."
            else "Dene: \"youtube kediler\", \"radyo <ad>\", \"tv\", \"medya\", \"ekolayzır\", \"ayarlar\", \"duraklat\", \"oynat\", \"sonraki\", \"önceki\", \"durdur\". Başka bir şey söylersen Google'da aranır."
        }
        body.addView(status, LinearLayout.LayoutParams(-1, -2))
        body.addView(mic, LinearLayout.LayoutParams(dp(150), dp(150)).apply { topMargin = dp(28); bottomMargin = dp(28) })
        body.addView(heard, LinearLayout.LayoutParams(-1, -2))
        body.addView(result, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        body.addView(help, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(32) })
        root.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Ui.navBar(this, L.t("Sesli kontrol")))
        setContentView(root)
        status.text = L.t("Mikrofona dokun")
        if (App.bool("vc_on", true)) start() else status.text = L.t("Sesli kontrol kapalı")
    }

    private fun start() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            // Tanıma servisi yoksa sistemin konuşma penceresine düş
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang()), 8)
            } catch (e: Exception) { status.text = L.t("Ses tanıma bulunamadı") }
            return
        }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { listening = true; status.text = L.t("Dinleniyor…") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onError(e: Int) { listening = false; status.text = L.t("Anlaşılamadı, tekrar dokun") }
                override fun onResults(b: Bundle?) {
                    listening = false
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t != null) handle(t) else status.text = L.t("Anlaşılamadı, tekrar dokun")
                }
                override fun onPartialResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard.text = it }
                }
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang())
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .apply { if (App.bool("vc_autolang", false)) putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION", true) })
        }
        heard.text = ""; result.text = ""
    }

    private fun lang() = VoiceLangs.tags[App.int("voice_lang", 0).coerceIn(0, VoiceLangs.tags.size - 1)]
    private fun stopListening() { listening = false; try { sr?.stopListening() } catch (e: Exception) { } }

    private fun handle(text: String) {
        heard.text = "“$text”"
        val r = VoiceCmd.run(this, text)
        result.text = "→ $r"
        status.text = L.t("Mikrofona dokun")
        if (App.bool("voice_fb", false)) Tts.speak(r)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 8 && res == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { handle(it) }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 7 && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) start()
        else status.text = L.t("Mikrofon izni verilmedi")
    }

    override fun onDestroy() { sr?.destroy(); super.onDestroy() }
}
