package com.cartube.app

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/** Ekolayzır: düz, pop, rock, dans, klasik. Seçilen ayarın bant değerleri gösterilir. */
class EqualizerActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private lateinit var body: LinearLayout
    private val acc get() = Theme.set()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (App.player.audioSessionId > 0) Eq.attach(App.player.audioSessionId)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(44), dp(16), dp(12)) }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Ui.navBar(this, L.t("Ekolayzır")))
        setContentView(root)
        render()
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Theme.roundRect(Theme.setCard(), 24); setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(6) }
    }

    private fun render() {
        body.removeAllViews()
        // Açık / kapalı
        val top = card()
        val sw = Switch(this).apply {
            text = L.t("Ekolayzır etkin"); setTextColor(Color.WHITE); textSize = 18f; setTypeface(null, Typeface.BOLD)
            isChecked = Eq.enabled()
            setOnCheckedChangeListener { _, v -> App.setBool("eq_on", v); Eq.apply() }
        }
        top.addView(sw)
        body.addView(top)
        // Hazır ayarlar
        val pc = card()
        pc.addView(TextView(this).apply { text = L.t("Hazır ayarlar"); setTextColor(Color.parseColor("#B8C4D0")); textSize = 14f })
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        Eq.names.forEachIndexed { i, n ->
            val sel = Eq.enabled() && Eq.preset() == i
            chips.addView(TextView(this).apply {
                text = L.t(n); gravity = Gravity.CENTER; textSize = 14f; setTypeface(null, Typeface.BOLD)
                setTextColor(if (sel) Color.BLACK else Color.WHITE)
                background = Theme.roundRect(if (sel) acc else Theme.mix(Color.parseColor("#0E1214"), acc, 0.25f), 18)
                setPadding(dp(4), dp(12), dp(4), dp(12))
                setOnClickListener { Eq.choose(i); render() }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(3); rightMargin = dp(3) })
        }
        pc.addView(chips, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        body.addView(pc)
        // Seçilen ayarın bantları
        val bc = card()
        val name = if (Eq.preset() < 5) L.t(Eq.names[Eq.preset()]) else L.t("Özel")
        bc.addView(TextView(this).apply { text = L.t("Seçili ayar") + ": " + name; setTextColor(Color.WHITE); textSize = 18f; setTypeface(null, Typeface.BOLD) })
        val b = Eq.bands()
        Eq.freqs.forEachIndexed { i, hz ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val lbl = TextView(this).apply { text = if (hz >= 1000) "${hz / 1000.0} kHz".replace(".0", "") else "$hz Hz"; setTextColor(Color.parseColor("#B8C4D0")); textSize = 14f }
            val v = TextView(this).apply { text = fmt(b[i]); setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.END }
            val sb = SeekBar(this).apply {
                max = 24; progress = b[i] + 12
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { v.text = fmt(p - 12); if (u) Eq.setBand(i, p - 12) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { render() }
                })
            }
            row.addView(lbl, LinearLayout.LayoutParams(dp(70), -2))
            row.addView(sb, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(v, LinearLayout.LayoutParams(dp(56), -2))
            bc.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
        body.addView(bc)
        // Bas güçlendirme
        val bs = card()
        val bv = TextView(this).apply { text = (Eq.bass() / 10).toString() + "%"; setTextColor(Color.WHITE); textSize = 14f }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = L.t("Bas güçlendirme"); setTextColor(Color.WHITE); textSize = 18f; setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(bv)
        bs.addView(head)
        bs.addView(SeekBar(this).apply {
            max = 1000; progress = Eq.bass()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { bv.text = (p / 10).toString() + "%"; if (u) { App.setInt("eq_bass", p); App.setBool("eq_on", true); Eq.apply() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        body.addView(bs)
        val note = TextView(this).apply { text = L.t("Ekolayzır, çalan içeriğe (ExoPlayer, MediaPlayer, VLC) uygulanır."); setTextColor(Color.parseColor("#8896A5")); textSize = 12f; setPadding(dp(6), dp(8), dp(6), 0) }
        body.addView(note)
    }

    private fun fmt(db: Int) = (if (db > 0) "+$db" else "$db") + " dB"
}
