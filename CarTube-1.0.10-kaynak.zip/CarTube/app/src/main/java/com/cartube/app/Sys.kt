package com.cartube.app

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.view.SurfaceHolder

/** Android'in kendi MediaPlayer motoru. */
object Sys {
    private var mp: MediaPlayer? = null
    var title: String? = null
    private var holder: SurfaceHolder? = null
    var vw = 0
    var vh = 0
    var onSize: (() -> Unit)? = null

    val isPlaying: Boolean get() = try { mp?.isPlaying == true } catch (e: Exception) { false }

    fun setDisplay(h: SurfaceHolder?) { holder = h; try { mp?.setDisplay(h) } catch (e: Exception) { } }

    fun play(name: String, url: String, video: Boolean) {
        stop()
        title = name; vw = 0; vh = 0
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.setDataSource(App.ctx, Uri.parse(url))
            if (video) holder?.let { p.setDisplay(it) }
            p.setOnPreparedListener { it.start(); Eq.attach(it.audioSessionId); App.onState?.invoke() }
            p.setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; onSize?.invoke() }
            p.setOnErrorListener { _, _, _ -> App.onState?.invoke(); true }
            p.setOnCompletionListener { App.onState?.invoke() }
            p.prepareAsync()
        } catch (e: Exception) { App.onState?.invoke() }
        App.onState?.invoke()
    }

    fun pause() { try { mp?.pause() } catch (e: Exception) { }; App.onState?.invoke() }
    fun resume() { try { mp?.start() } catch (e: Exception) { }; App.onState?.invoke() }
    fun stop() {
        mp?.let { try { it.stop() } catch (e: Exception) { }; it.release() }
        mp = null; title = null
        App.onState?.invoke()
    }
    fun seekBy(ms: Long) { try { mp?.let { it.seekTo((it.currentPosition + ms).coerceAtLeast(0).toInt()) } } catch (e: Exception) { } }
}
