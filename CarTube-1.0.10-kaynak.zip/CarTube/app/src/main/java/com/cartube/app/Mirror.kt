package com.cartube.app

import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.view.Surface

/** Telefon ekranını araç ekranındaki yüzeye (Surface) yansıtır. */
object Mirror {
    var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    val active get() = projection != null

    fun attach(surface: Surface, w: Int, h: Int, dpi: Int) {
        val p = projection ?: return
        detachDisplay()
        try {
            vd = p.createVirtualDisplay("CarTube", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null)
        } catch (e: Exception) { }
    }

    fun detachDisplay() { try { vd?.release() } catch (e: Exception) { }; vd = null }

    fun stop() {
        detachDisplay()
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
    }
}
