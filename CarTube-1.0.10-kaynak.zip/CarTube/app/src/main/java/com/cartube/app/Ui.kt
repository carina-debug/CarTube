package com.cartube.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog

object Ui {
    fun dp(a: Activity, v: Float) = (v * a.resources.displayMetrics.density).toInt()

    fun back(a: Activity) {
        if (a is androidx.activity.ComponentActivity) a.onBackPressedDispatcher.onBackPressed() else a.finish()
    }

    /** Alt çubuk: solda geri, sağda ana sayfa, ortada başlık ya da (verilmişse) bir işlem düğmesi. */
    fun navBar(a: Activity, title: String?, centerIcon: Int? = null, onCenter: (() -> Unit)? = null): View {
        val dm = a.resources.displayMetrics
        val sw = dm.widthPixels / dm.density
        val ns = App.float("nav_size", App.D_NAV)
        val btn = minOf(52f * ns, (sw - 36f - 24f) / 3f)
        val fill = Theme.mix(Color.parseColor("#0E1214"), Theme.set(), 0.35f)
        fun circle(icon: Int, click: () -> Unit) = ImageButton(a).apply {
            background = Theme.circle(fill, Theme.set()); setImageResource(icon); setColorFilter(Color.WHITE); setOnClickListener { click() } }
        val row = LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(a, 20f), dp(a, 8f), dp(a, 20f), dp(a, 20f)); setBackgroundColor(Color.parseColor("#0E141C")) }
        row.addView(circle(R.drawable.ic_back) { back(a) }, LinearLayout.LayoutParams(dp(a, btn), dp(a, btn)))
        val mid = FrameLayout(a)
        if (centerIcon != null && onCenter != null)
            mid.addView(circle(centerIcon, onCenter), FrameLayout.LayoutParams(dp(a, btn), dp(a, btn), Gravity.CENTER))
        else if (title != null)
            mid.addView(TextView(a).apply {
                text = title; setTextColor(Color.WHITE); textSize = 18f * minOf(maxOf(ns, 0.7f), 1.3f); setTypeface(null, Typeface.BOLD)
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(circle(R.drawable.ic_home) {
            a.startActivity(Intent(a, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }, LinearLayout.LayoutParams(dp(a, btn), dp(a, btn)))
        return row
    }

    /** Bir veya birkaç metin kutulu basit diyalog. */
    fun ask(a: Activity, title: String, hints: List<String>, defaults: List<String> = emptyList(), ok: (List<String>) -> Unit) {
        val l = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(a, 20f), dp(a, 8f), dp(a, 20f), 0) }
        val fields = hints.mapIndexed { i, h -> EditText(a).apply { hint = L.t(h); setSingleLine(); setText(defaults.getOrNull(i) ?: "") }.also { l.addView(it) } }
        AlertDialog.Builder(a).setTitle(L.t(title)).setView(l)
            .setPositiveButton(L.t("Kaydet")) { _, _ -> ok(fields.map { it.text.toString().trim() }) }
            .setNegativeButton(L.t("İptal"), null).show()
    }

    fun menu(a: Activity, title: String?, items: List<String>, pick: (Int) -> Unit) {
        val b = AlertDialog.Builder(a)
        if (title != null) b.setTitle(L.t(title))
        b.setItems(items.map { L.t(it) }.toTypedArray()) { _, i -> pick(i) }.show()
    }

    fun confirm(a: Activity, msg: String, yes: () -> Unit) {
        AlertDialog.Builder(a).setMessage(msg).setPositiveButton(L.t("Sil")) { _, _ -> yes() }.setNegativeButton(L.t("İptal"), null).show()
    }

    fun toast(a: Activity, s: String) = Toast.makeText(a, L.t(s), Toast.LENGTH_SHORT).show()
}
