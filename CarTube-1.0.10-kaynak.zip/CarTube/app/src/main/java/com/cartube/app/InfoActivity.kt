package com.cartube.app

import android.os.Bundle
import android.view.Gravity
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InfoActivity : AppCompatActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        root.addView(TextView(this).apply {
            text = (intent.getStringExtra("title") ?: "") + "\n\n" + (intent.getStringExtra("text") ?: "")
            gravity = Gravity.CENTER; textSize = 18f; setPadding(48, 48, 48, 48)
        }, android.widget.LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Ui.navBar(this, intent.getStringExtra("title")))
        setContentView(root)
    }
}
