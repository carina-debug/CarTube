package com.cartube.app

import android.os.Bundle
import android.view.Gravity
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InfoActivity : AppCompatActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(TextView(this).apply {
            text = (intent.getStringExtra("title") ?: "") + "\n\n" + (intent.getStringExtra("text") ?: "")
            gravity = Gravity.CENTER; textSize = 18f; setPadding(48, 48, 48, 48)
        })
    }
}
