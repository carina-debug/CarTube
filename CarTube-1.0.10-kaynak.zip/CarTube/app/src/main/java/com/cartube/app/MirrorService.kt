package com.cartube.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class MirrorService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { Mirror.stop(); stopSelf(); return START_NOT_STICKY }
        val code = i?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION") val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mirror", "Ekran Yansıtma", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "mirror").setContentTitle("CarTube").setContentText(L.t("Ekran yansıtma açık"))
            .setSmallIcon(R.drawable.ic_cast).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(77, n)
        val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { Mirror.detachDisplay(); Mirror.projection = null; App.onState?.invoke(); stopSelf() }
        }, Handler(Looper.getMainLooper()))
        Mirror.projection = p
        return START_NOT_STICKY
    }
}
