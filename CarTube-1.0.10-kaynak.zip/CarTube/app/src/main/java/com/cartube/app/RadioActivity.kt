package com.cartube.app

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class RadioActivity : AppCompatActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val items = App.radioList()
        val lv = ListView(this)
        val names = if (items.isEmpty()) listOf("Radyo yok — Ana ekran > Ayarlar'dan ekleyin") else items.map { it.first }
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        lv.setOnItemClickListener { _, _, i, _ -> if (items.isNotEmpty()) { App.play(items[i].first, items[i].second); finish() } }
        lv.setOnItemLongClickListener { _, _, i, _ -> if (items.isNotEmpty()) { App.addFav(items[i].first, items[i].second); android.widget.Toast.makeText(this, "Favorilere eklendi", android.widget.Toast.LENGTH_SHORT).show() }; true }
        setContentView(lv)
    }
}
