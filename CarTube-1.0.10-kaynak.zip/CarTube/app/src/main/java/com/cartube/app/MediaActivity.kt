package com.cartube.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.ui.PlayerView
import kotlin.concurrent.thread

class MediaActivity : AppCompatActivity() {
    private val items = mutableListOf<Pair<String, String>>()
    private lateinit var lv: ListView
    private val perms get() = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(PlayerView(this).apply { player = App.player }, LinearLayout.LayoutParams(-1, 0, 1f))
        lv = ListView(this)
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) load() else requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) load()
        else Toast.makeText(this, "Medya izni verilmedi", Toast.LENGTH_LONG).show()
    }

    private fun load() = thread {
        fun scan(base: android.net.Uri, prefix: String) {
            contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.TITLE), null, null,
                MediaStore.MediaColumns.TITLE + " COLLATE NOCASE ASC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n++ < 500)
                    items += (prefix + (c.getString(1) ?: "?")) to ContentUris.withAppendedId(base, c.getLong(0)).toString()
            }
        }
        try {
            scan(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "♪ ")
            scan(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "▶ ")
        } catch (e: Exception) { }
        runOnUiThread {
            lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items.map { it.first })
            lv.setOnItemClickListener { _, _, i, _ -> App.play(items[i].first.drop(2), items[i].second) }
        }
    }
}
