package com.cartube.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MediaActivity : AppCompatActivity() {
    private class M(val title: String, val uri: String, val video: Boolean)
    private val items = mutableListOf<M>()
    private lateinit var lv: ListView
    private var cur: String? = null
    private val perms get() = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(VideoUi.create(this), LinearLayout.LayoutParams(-1, 0, 1f))
        lv = ListView(this)
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) load() else requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) load()
        else Toast.makeText(this, "Medya izni verilmedi", Toast.LENGTH_LONG).show()
    }

    private fun load() = thread {
        val mode = App.int("scanner", 0)   // 0 hepsi, 1 müzik, 2 video
        fun scan(base: android.net.Uri, video: Boolean) {
            contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.TITLE), null, null,
                MediaStore.MediaColumns.TITLE + " COLLATE NOCASE ASC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n++ < 500)
                    items += M(c.getString(1) ?: "?", ContentUris.withAppendedId(base, c.getLong(0)).toString(), video)
            }
        }
        try {
            if (mode != 2) scan(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, false)
            if (mode != 1) scan(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
        } catch (e: Exception) { }
        val watched = App.watched()
        val icons = App.bool("track_icons", true)
        runOnUiThread {
            lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items.map {
                (if (it.uri in watched) "✓ " else "") + (if (icons) (if (it.video) "▶ " else "♪ ") else "") + it.title })
            lv.setOnItemClickListener { _, _, i, _ -> cur = items[i].uri; App.play(items[i].title, items[i].uri) }
        }
    }

    override fun onStop() {
        super.onStop()
        val u = cur ?: return
        val p = App.player
        if (p.duration > 0 && p.currentPosition * 100.0 / p.duration >= App.float("watch_pct", 95f)) App.addWatched(u)
    }
}
