package com.cartube.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

/** Medya listesi. Tarayıcı: 0 Varsayılan (müzik+video), 1 Sistem (dosya seçici), 2 VLC (ek biçimler de). */
class MediaActivity : AppCompatActivity() {
    private class M(val title: String, val uri: String, val video: Boolean)
    private val items = mutableListOf<M>()
    private lateinit var lv: ListView
    private var cur: String? = null
    private val mode get() = App.int("scanner", 0)
    private val perms get() = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val saved = App.str("sys_media").lines().filter { it.isNotBlank() }.toMutableList()
        uris.forEach { u ->
            try { contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
            val name = u.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: u.toString()
            saved.add(name.replace("|", "/") + "|" + u)
        }
        App.setStr("sys_media", saved.distinct().joinToString("\n"))
        load()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        root.addView(VideoUi.create(this), LinearLayout.LayoutParams(-1, 0, 1f))
        lv = ListView(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        if (mode == 1) root.addView(Ui.navBar(this, null, R.drawable.ic_add) { picker.launch(arrayOf("audio/*", "video/*")) })
        else root.addView(Ui.navBar(this, L.t("Medya")))
        setContentView(root)
        if (mode == 1 || perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) load() else requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) load()
        else Toast.makeText(this, L.t("Medya izni verilmedi"), Toast.LENGTH_LONG).show()
    }

    private fun load() = thread {
        items.clear()
        fun scan(base: Uri, video: Boolean, extra: String? = null) {
            contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.TITLE), extra, null,
                MediaStore.MediaColumns.TITLE + " COLLATE NOCASE ASC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n++ < 800)
                    items += M(c.getString(1) ?: "?", ContentUris.withAppendedId(base, c.getLong(0)).toString(), video)
            }
        }
        try {
            when (mode) {
                1 -> App.str("sys_media").lines().filter { it.contains("|") }.forEach {
                    val p = it.split("|", limit = 2)
                    items += M(p[0], p[1], !(p[1].contains("audio") || p[0].lowercase().matches(Regex(".*\\.(mp3|flac|ogg|opus|m4a|wav|aac)"))))
                }
                2 -> {
                    // VLC modu: ses ve videoların yanında VLC'nin oynatabildiği ek biçimleri de tarar
                    scan(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, false)
                    scan(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
                    val ext = listOf("mkv", "avi", "wmv", "ts", "flv", "flac", "ogg", "opus", "wma", "ape")
                    val sel = ext.joinToString(" OR ") { "_display_name LIKE '%.$it'" }
                    val files = MediaStore.Files.getContentUri("external")
                    val have = items.map { it.uri.substringAfterLast('/') }.toSet()
                    contentResolver.query(files, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME), sel, null, null)?.use { c ->
                        var n = 0
                        while (c.moveToNext() && n++ < 800) {
                            val id = c.getLong(0)
                            if (id.toString() in have) continue
                            val name = c.getString(1) ?: "?"
                            val audio = name.substringAfterLast('.').lowercase() in listOf("flac", "ogg", "opus", "wma", "ape")
                            items += M(name.substringBeforeLast('.'), ContentUris.withAppendedId(files, id).toString(), !audio)
                        }
                    }
                }
                else -> {
                    scan(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, false)
                    scan(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
                }
            }
        } catch (e: Exception) { }
        val watched = App.watched()
        val icons = App.bool("track_icons", true)
        runOnUiThread {
            val names = if (items.isEmpty()) listOf(L.t(if (mode == 1) "Dosya eklemek için alttaki + düğmesine dokun" else "Medya bulunamadı"))
            else items.map { (if (it.uri in watched) "✓ " else "") + (if (icons) (if (it.video) "▶ " else "♪ ") else "") + it.title }
            lv.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
                override fun getView(p: Int, v: android.view.View?, g: android.view.ViewGroup): android.view.View =
                    super.getView(p, v, g).also { (it as TextView).setTextColor(Color.WHITE) }
            }
            lv.setOnItemClickListener { _, _, i, _ -> items.getOrNull(i)?.let { cur = it.uri; App.play(it.title, it.uri, it.video) } }
        }
    }

    override fun onStop() {
        super.onStop()
        val u = cur ?: return
        val p = App.player
        if (App.cur == 1 && p.duration > 0 && p.currentPosition * 100.0 / p.duration >= App.float("watch_pct", 95f)) App.addWatched(u)
    }

    override fun onDestroy() { Vlc.detach(); Sys.onSize = null; super.onDestroy() }
}
