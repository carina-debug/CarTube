package com.cartube.app

import android.content.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Player

sealed class Item
class Nav(val title: String, val sub: String?, val icon: Int, val page: String) : Item()
class Check(val key: String, val title: String, val sub: String?, val def: Boolean, val onChange: (() -> Unit)? = null) : Item()
class Slide(val key: String, val title: String, val min: Float, val max: Float, val def: Float) : Item()
class Choice(val key: String, val title: String, val options: List<String>, val def: Int, val sub: String? = null) : Item()
class Act(val title: String, val sub: String?, val icon: Int?, val run: (SettingsActivity) -> Unit) : Item()

class SettingsActivity : AppCompatActivity() {
    private val blue get() = Theme.set()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private lateinit var miniTitle: TextView
    private lateinit var miniSub: TextView
    private lateinit var miniBtn: ImageButton
    private val pl = object : Player.Listener {
        override fun onIsPlayingChanged(p: Boolean) = refreshMini()
        override fun onMediaItemTransition(m: androidx.media3.common.MediaItem?, r: Int) = refreshMini()
    }

    private fun page(id: String): Pair<String, List<Item>> = when (id) {
        "ui" -> "Arayüz" to listOf(
            Choice("theme", "Uygulama teması", Theme.names, 0, "Renk teması"),
            Slide("ui_text", "Metin ve simge boyutu", 0.6f, 1.4f, 1f),
            Slide("ui_card_h", "Ana ekran kart yüksekliği", 0.6f, 1.4f, 1f))
        "voice" -> "Ses ve asistan" to listOf(
            Check("welcome", "Karşılama mesajı", "Uygulama açılınca kısa bir mesaj göster", false),
            Act("Sesli komut", "Telefonun ses asistanını başlat", null) { a ->
                try { a.startActivity(Intent(Intent.ACTION_VOICE_COMMAND).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { a.toast("Ses asistanı bulunamadı") } })
        "play" -> "Oynatma ayarları" to listOf(
            Act("Ses ve ekolayzır", "Sistem ekolayzırını aç", null) { App.openEq(it) },
            Nav("Oynatma kontrolü", null, 0, "pctl"),
            Nav("Medya motoru", null, 0, "engine"),
            Nav("Video ayarları", null, 0, "video"))
        "pctl" -> "Oynatma kontrolü" to listOf(
            Check("p_noisy", "Kulaklık çıkınca duraklat", null, true) { App.applyAudio() },
            Check("p_focus", "Ses odağını yönet", "Arama/navigasyon sesinde otomatik duraklat", true) { App.applyAudio() })
        "engine" -> "Medya motoru" to listOf(
            Act("ExoPlayer (Media3 1.3.1)", "Aktif motor: HLS, DASH ve düz akışlar", null) { })
        "video" -> "Video ayarları" to listOf(
            Choice("video_resize", "Görüntü boyutu (TV)", listOf("Sığdır", "Doldur", "Yakınlaştır"), 0))
        "home" -> "Ana ekran" to listOf(
            Check("home_tv", "TV", "Telefon ana ekranında göster", true),
            Check("home_yt", "Youtube", null, true),
            Check("home_cast", "Ekran Yansıtma", null, true),
            Check("home_radio", "Radyo", null, true),
            Check("home_media", "Medya", null, true),
            Check("home_phone", "Telefonu Kullan", null, true),
            Check("home_web", "Web", null, true),
            Check("home_favs", "Favori Kanallar", null, true),
            Check("home_recent", "Son İçerikler", null, true))
        "car" -> "Araç Uygulamaları" to listOf(
            Check("car_tv", "TV", "Araç ekranında göster", true),
            Check("car_yt", "Youtube", null, true),
            Check("car_cast", "Ekran Yansıtma", null, true),
            Check("car_radio", "Radyo", null, true))
        "plug" -> "Eklentiler" to listOf(
            Nav("TV", null, R.drawable.ic_tv, "pl_tv"),
            Nav("Youtube", null, R.drawable.ic_play, "pl_yt"),
            Nav("Web tarayıcı", null, R.drawable.ic_globe, "pl_web"),
            Nav("Radyo", null, R.drawable.ic_radio, "pl_radio"),
            Nav("Podcastlar", null, R.drawable.ic_more, "pl_pod"))
        "pl_tv" -> "TV" to listOf(
            Check("home_tv", "Etkinleştir", null, true),
            Act("Kaynaklar", "M3U / IPTV liste adresi", null) { it.sources() })
        "pl_yt" -> "Youtube" to listOf(
            Check("home_yt", "Etkinleştir", null, true),
            Choice("yt_dark", "Desteklenirse karanlık modu zorla", listOf("Otomatik", "Açık", "Kapalı"), 0, "Cihaz temasını takip etmek için \"Otomatik\" seçeneğini seçin."),
            Check("yt_q", "En yüksek video kalitesini otomatik seç", null, true),
            Check("yt_fs", "Otomatik tam ekran", null, true),
            Check("yt_native", "YouTube'un kendi oynatıcısını kullan", "CarTube'da tam ekranda her zaman YouTube'un kendi tuşları kalır", true),
            Check("yt_skip", "Reklamları atlamayı deneyin", "Çıkan \"Reklamı atla\" düğmesine otomatik basar", true),
            Nav("SponsorBlock", "YouTube izlerken kitle kaynaklı bölümleri atlayın", 0, "sb"))
        "sb" -> "SponsorBlock" to listOf(
            Check("sb_on", "Etkinleştir", "Bölüm verisi sponsor.ajay.app'tan alınır", false),
            Check("sb_sponsor", "Sponsorluk", null, true),
            Check("sb_selfpromo", "Kendi reklamı / ücretsiz tanıtım", null, true),
            Check("sb_interaction", "Abone ol / beğen hatırlatması", null, true),
            Check("sb_intro", "Giriş animasyonu", null, false),
            Check("sb_outro", "Bitiş / kapanış", null, false),
            Check("sb_music_offtopic", "Müzik dışı bölüm", null, false))
        "pl_web" -> "Web tarayıcı" to listOf(
            Check("home_web", "Etkinleştir", null, true),
            Act("Başlangıç adresi", "Web kartının açacağı sayfa", null) { it.webHome() })
        "pl_radio" -> "Radyo" to listOf(
            Check("home_radio", "Etkinleştir", null, true),
            Act("Kaynaklar", "Radyo listesi (Ad|URL)", null) { it.sources() })
        "pl_pod" -> "Podcastlar" to listOf(
            Act("Bu sürümde henüz yok", "Sonraki sürümde eklenecek", null) { })
        "other" -> "Diğer" to listOf(
            Act("Kaynaklar", "M3U / IPTV adresi ve radyo listesi", null) { it.sources() },
            Act("Tuş atamaları", "Bu sürümde henüz yok", null) { it.toast("Tuş atamaları sonraki sürümde") },
            Act("İlk kurulumu aç", "Tüm ayarları varsayılana döndür", null) { it.confirmReset() },
            Nav("Tanılama", "Çökmeler için yerel rapor", 0, "diag"),
            Nav("Yedekleme ve geri yükleme", "Ayarları cihazlar arasında aktarın", 0, "backup"))
        "diag" -> "Tanılama" to listOf(
            Check("diag", "Çökme raporlarını kaydet", "Uygulamayı yeniden başlatınca etkinleşir", false),
            Act("Son hatayı göster", null, null) { a ->
                val t = App.str("last_crash").ifBlank { "Kayıtlı hata yok" }
                AlertDialog.Builder(a).setMessage(t.take(3000)).setPositiveButton("Tamam", null).show() },
            Act("Hata kaydını temizle", null, null) { App.setStr("last_crash", ""); it.toast("Temizlendi") })
        "backup" -> "Yedekleme ve geri yükleme" to listOf(
            Act("Ayarları panoya kopyala", "JSON olarak", null) { a ->
                (a.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("cartube", App.exportJson()))
                a.toast("Panoya kopyalandı") },
            Act("Panodan geri yükle", "Kopyaladığın yedeği uygular", null) { a ->
                try {
                    val t = (a.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.text.toString()
                    App.importJson(t); App.applyAudio(); a.toast("Geri yüklendi"); a.recreate()
                } catch (e: Exception) { a.toast("Panoda geçerli yedek yok") } })
        "conn" -> "Bağlantı ve izin denetimi" to listOf(
            Act("Android Auto'yu aç", "Bağlantı ve geliştirici ayarları için", null) { a ->
                val i = a.packageManager.getLaunchIntentForPackage("com.google.android.projection.gearhead")
                if (i != null) a.startActivity(i) else a.toast("Android Auto yüklü değil") },
            Act("CarTube uygulama izinleri", "Sistem ayarlarında aç", null) { a ->
                a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.packageName))) },
            Act("Pil kısıtlamaları", "Arka planda çalma için kısıtlamayı kaldır", null) { a ->
                a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        else -> "Ayarlar" to listOf(
            Nav("Arayüz", null, R.drawable.ic_tune, "ui"),
            Nav("Ses ve asistan", "Sesli komutlar, karşılama mesajı", R.drawable.ic_mic, "voice"),
            Nav("Oynatma ayarları", null, R.drawable.ic_play, "play"),
            Nav("Ana ekran", "Kartları göster/gizle", R.drawable.ic_home, "home"),
            Nav("Araç Uygulamaları", "Araç ekranında görünecek uygulamaları seçin", R.drawable.ic_grid, "car"),
            Nav("Eklentiler", null, R.drawable.ic_globe, "plug"),
            Nav("Diğer", null, R.drawable.ic_more, "other"),
            Nav("Bağlantı ve izin denetimi", "Android Auto bağlantısını ve isteğe bağlı sistem ayarlarını görüntüleyin.", R.drawable.ic_cast, "conn"))
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun sources() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val m3u = EditText(this).apply { hint = "M3U / IPTV liste adresi (URL)"; setText(App.m3uUrl); setSingleLine() }
        val rad = EditText(this).apply { hint = "Radyolar: her satıra  Ad|Yayın URL"; setText(App.radios); minLines = 4; gravity = Gravity.TOP }
        l.addView(m3u); l.addView(rad)
        AlertDialog.Builder(this).setTitle("Kaynaklar").setView(l)
            .setPositiveButton("Kaydet") { _, _ -> App.m3uUrl = m3u.text.toString().trim(); App.radios = rad.text.toString() }
            .setNegativeButton("İptal", null).show()
    }

    fun webHome() {
        val e = EditText(this).apply { hint = "https://www.google.com"; setText(App.str("web_home")); setSingleLine() }
        AlertDialog.Builder(this).setTitle("Başlangıç adresi").setView(e)
            .setPositiveButton("Kaydet") { _, _ -> var u = e.text.toString().trim(); if (u.isNotBlank() && !u.startsWith("http")) u = "https://$u"; App.setStr("web_home", u) }
            .setNegativeButton("İptal", null).show()
    }

    fun confirmReset() = AlertDialog.Builder(this).setMessage("Tüm ayarlar sıfırlansın mı?")
        .setPositiveButton("Sıfırla") { _, _ -> App.resetAll(); App.applyAudio(); toast("Sıfırlandı"); recreate() }
        .setNegativeButton("İptal", null).show()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val id = intent.getStringExtra("page") ?: "root"
        val (title, items) = page(id)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        root.addView(mini())
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(12)) }
        items.forEach { col.addView(row(it)) }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottom(title))
        setContentView(root)
    }

    private fun scale() = App.float("ui_text", 1f)

    private fun card(): LinearLayout = LinearLayout(this).apply {
        background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(Theme.setCard()) }; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(6) }
    }
    private fun texts(t: String, sub: String?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(this@SettingsActivity).apply { text = t; setTextColor(Color.WHITE); textSize = 19f * scale(); setTypeface(null, Typeface.BOLD) })
        if (sub != null) addView(TextView(this@SettingsActivity).apply { text = sub; setTextColor(Color.parseColor("#B8C4D0")); textSize = 14f * scale() })
    }
    private fun icon(res: Int?): View? = res?.takeIf { it != 0 }?.let {
        ImageView(this).apply { setImageResource(it); setColorFilter(blue); layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(16) } } }
    private fun chev() = ImageView(this).apply { setImageResource(R.drawable.ic_chevron); setColorFilter(blue) }

    private fun row(it: Item): View {
        val c = card()
        when (it) {
            is Nav -> { icon(it.icon)?.let(c::addView); c.addView(texts(it.title, it.sub), LinearLayout.LayoutParams(0, -2, 1f)); c.addView(chev())
                c.setOnClickListener { _ -> startActivity(Intent(this, SettingsActivity::class.java).putExtra("page", it.page)) } }
            is Act -> { icon(it.icon)?.let(c::addView); c.addView(texts(it.title, it.sub), LinearLayout.LayoutParams(0, -2, 1f)); c.addView(chev())
                c.setOnClickListener { _ -> it.run(this) } }
            is Check -> {
                val cb = CheckBox(this).apply { isChecked = App.bool(it.key, it.def); buttonTintList = android.content.res.ColorStateList.valueOf(blue)
                    setOnCheckedChangeListener { _, v -> App.setBool(it.key, v); it.onChange?.invoke() } }
                c.addView(texts(it.title, it.sub), LinearLayout.LayoutParams(0, -2, 1f)); c.addView(cb)
                c.setOnClickListener { _ -> cb.toggle() } }
            is Choice -> {
                c.addView(texts(it.title, it.options[App.int(it.key, it.def)].let { cur -> if (it.sub != null) cur + ". " + it.sub else "Mevcut: " + cur }), LinearLayout.LayoutParams(0, -2, 1f))
                c.setOnClickListener { _ -> AlertDialog.Builder(this).setTitle(it.title)
                    .setSingleChoiceItems(it.options.toTypedArray(), App.int(it.key, it.def)) { d, w -> App.setInt(it.key, w); d.dismiss(); recreate() }.show() } }
            is Slide -> {
                c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.START
                val v = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f }
                val cur = App.float(it.key, it.def); v.text = "%.2f".format(cur)
                val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                head.addView(texts(it.title, null), LinearLayout.LayoutParams(0, -2, 1f)); head.addView(v)
                val sb = SeekBar(this).apply { max = 100; progress = ((cur - it.min) / (it.max - it.min) * 100).toInt()
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { val x = it.min + (it.max - it.min) * p / 100f; v.text = "%.2f".format(x); if (u) App.setFloat(it.key, x) }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {}
                    }) }
                c.addView(head, LinearLayout.LayoutParams(-1, -2)); c.addView(sb, LinearLayout.LayoutParams(-1, -2)) }
        }
        return c
    }

    private fun mini(): View {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(36), dp(12), dp(10)) }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        miniTitle = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD); maxLines = 1 }
        miniSub = TextView(this).apply { setTextColor(Color.parseColor("#B0B5B8")); textSize = 13f; maxLines = 1 }
        tx.addView(miniTitle); tx.addView(miniSub)
        r.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        miniBtn = ImageButton(this).apply { background = Theme.circle(Theme.mix(Color.parseColor("#0E1214"), Theme.set(), 0.35f), Theme.set()); setImageResource(R.drawable.ic_play)
            setOnClickListener { val p = App.player; if (p.isPlaying) p.pause() else p.play() } }
        r.addView(miniBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        return r
    }
    private fun refreshMini() {
        val p = App.player; val t = p.mediaMetadata.title?.toString()
        miniTitle.text = t ?: "Oynatılan içerik yok"
        miniSub.text = if (t == null) "Kontrol etmek için bir içerik başlat" else if (p.isPlaying) "Oynatılıyor" else "Duraklatıldı"
        miniBtn.setImageResource(if (p.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
    }
    private fun bottom(t: String): View {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(16), dp(20)); setBackgroundColor(Color.parseColor("#0E141C")) }
        r.addView(TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 20f; setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(ImageButton(this).apply { background = Theme.circle(Theme.mix(Color.parseColor("#0E1214"), Theme.set(), 0.35f), Theme.set()); setImageResource(R.drawable.ic_home); setColorFilter(Color.WHITE)
            setOnClickListener { startActivity(Intent(this@SettingsActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } },
            LinearLayout.LayoutParams(dp(56), dp(56)))
        return r
    }
    override fun onStart() { super.onStart(); App.player.addListener(pl); refreshMini() }
    override fun onStop() { super.onStop(); App.player.removeListener(pl) }
}
