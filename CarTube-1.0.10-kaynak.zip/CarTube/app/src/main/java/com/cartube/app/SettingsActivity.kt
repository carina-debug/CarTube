package com.cartube.app

import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Player

sealed class Item
class Nav(val title: String, val sub: String?, val icon: Int, val page: String) : Item()
class Check(val key: String, val title: String, val sub: String?, val def: Boolean, val onChange: (() -> Unit)? = null) : Item()
class Slide(val key: String, val title: String, val min: Float, val max: Float, val def: Float, val sub: String? = null, val dec: Int = 2) : Item()
class Choice(val key: String, val title: String, val options: List<String>, val def: Int, val sub: String? = null, val prefix: String = "Mevcut: ") : Item()
class Act(val title: String, val sub: String?, val icon: Int?, val run: (SettingsActivity) -> Unit) : Item()
class HomeRow(val key: String, val title: String) : Item()

private const val NA = "Bu sürümde etkisiz"
private val SECS = listOf("5 sn", "10 sn", "15 sn", "30 sn", "60 sn")

class SettingsActivity : AppCompatActivity() {
    private val blue get() = Theme.set()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private lateinit var miniTitle: TextView
    private lateinit var miniSub: TextView
    private lateinit var miniBtn: ImageButton
    private val pl = object : Player.Listener {
        override fun onIsPlayingChanged(p: Boolean) = refreshMini()
        override fun onMediaItemTransition(m: androidx.media3.common.MediaItem?, r: Int) = refreshMini()
    }

    private val homeNames = mapOf("tv" to "TV", "yt" to "Youtube", "cast" to "Ekran Yansıtma", "radio" to "Radyo",
        "media" to "Medya", "phone" to "Telefonu Kullan", "web" to "Web")

    private fun page(id: String): Pair<String, List<Item>> = when (id) {
        "ui" -> "Arayüz" to listOf(
            Nav("Android Auto", null, 0, "aa"),
            Check("ui_left", "Sol kısayol menüsünü göster", na("Eski kısayol düğmelerini yan tarafta göster"), false),
            Choice("theme", "Uygulama teması", Theme.names, 0, null, "Mevcut tema: "),
            Choice("nav_pos", "Gezinme çubuğu konumu", listOf("Altta", "Üstte"), 0, null, "Mevcut konum: "),
            Slide("nav_size", "Gezinme çubuğu boyutu", 0.5f, 2f, App.D_NAV),
            Slide("bar_size", "Araç çubuğu boyutu", 0.5f, 2f, App.D_BAR),
            Slide("ui_card_h", "Kontrol paneli boyutu", 0.5f, 2f, App.D_PANEL),
            Slide("ui_text", "Metin ve simge boyutu", 0.5f, 1.5f, App.D_TEXT),
            Check("track_icons", "Parça simgeleri göster", null, true),
            Choice("lang", "Diller", listOf("Türkçe", "English"), 0, null, ""))
        "aa" -> "Android Auto" to listOf(
            Check("aa_left", "Sol kısayol menüsünü göster", na("Eski kısayol düğmelerini yan tarafta göster"), false),
            Choice("aa_theme", "Uygulama teması", listOf("Aydınlık", "Koyu"), 0, NA, "Mevcut tema: "),
            Check("aa_dpad", "D-pad navigasyonu için imleci kullanın", NA, true),
            Choice("aa_nav_pos", "Gezinme çubuğu konumu", listOf("Solda", "Sağda", "Altta"), 0, NA, "Mevcut konum: "),
            Slide("aa_nav_size", "Gezinme çubuğu boyutu", 0.5f, 2f, 1f, NA),
            Slide("aa_bar_size", "Araç çubuğu boyutu", 0.5f, 2f, 1f, NA),
            Slide("aa_panel_size", "Kontrol paneli boyutu", 0.5f, 2f, 1f, NA),
            Slide("aa_text_size", "Metin ve simge boyutu", 0.5f, 2f, 1f, NA))
        "voice" -> "Ses ve asistan" to listOf(
            Check("welcome", "Karşılama mesajı", "Uygulama açılınca kısa bir mesaj göster", false),
            Act("Sesli komut", "Telefonun ses asistanını başlat", null) { App.voice(it) })
        "play" -> "Oynatma ayarları" to listOf(
            Act("Ses ve ekolayzır", "Sistem ekolayzırını aç", null) { App.openEq(it) },
            Nav("Oynatma kontrolü", null, 0, "pctl"),
            Nav("Medya motoru", null, 0, "engine"),
            Nav("Video ayarları", null, 0, "video"))
        "pctl" -> "Oynatma kontrolü" to listOf(
            Nav("RW/FF - Tek dokunma", null, 0, "rw_tap"),
            Nav("RW/FF - Uzun dokunma", null, 0, "rw_long"),
            Nav("Önceki/Sonraki - Uzun dokunma", null, 0, "pn_long_p"),
            Check("pp_stop", "Oynat/Duraklat uzun dokunma durdur", null, true),
            Nav("Video kontrolü", null, 0, "vctl"))
        "rw_tap" -> "RW/FF - Tek dokunma" to listOf(
            Choice("ff_tap", "Sarma süresi", SECS, 1, "Üst çubuktaki ◀ ▶ düğmelerine dokununca"))
        "rw_long" -> "RW/FF - Uzun dokunma" to listOf(
            Choice("ff_long", "Sarma süresi", SECS, 4, "Üst çubuktaki ◀ ▶ düğmelerine uzun basınca"))
        "pn_long_p" -> "Önceki/Sonraki - Uzun dokunma" to listOf(
            Choice("pn_long", "Uzun dokunuş eylemi", listOf("RW/FF (sar)", "Önceki/Sonraki parça"), 0))
        "vctl" -> "Video kontrolü" to listOf(
            Check("v_tap", "Dokunarak oynat/duraklat", "Video alanına dokununca", false),
            Check("v_autohide", "Kontrolleri otomatik gizle", null, true))
        "engine" -> "Medya motoru" to listOf(
            Check("exo_on", "ExoPlayer etkinleştir", "CarTube'ın varsayılan oynatma motoru", true),
            Check("vlc_on", "VLC etkinleştir", "VLC (libVLC) ile TV, medya ve radyo oynatılabilir", true),
            Choice("eng_audio", "Tercih edilen ses motoru", listOf("ExoPlayer", "VLC"), 0, "Radyo ve müzik için", ""),
            Choice("eng_video", "Tercih edilen video motoru", listOf("ExoPlayer", "VLC"), 0, "TV ve videolar için", ""),
            Choice("scanner", "Tercih edilen medya tarayıcı", listOf("Varsayılan", "Yalnızca müzik", "Yalnızca video"), 0, null, ""))
        "video" -> "Video ayarları" to listOf(
            Choice("video_resize", "Video ölçekleme", listOf("En uygun", "Doldur", "Yakınlaştır"), 0, null, ""),
            Choice("hw", "Donanım ivmesi", listOf("Oto", "Açık"), 0, "Uygulama yeniden başlatılınca geçerli olur", ""),
            Choice("clock_pos", "Saat konumu", listOf("Sağ", "Sol", "Kapalı"), 2, null, ""),
            Check("v_bars", "Video dokunuşunda sistem çubuklarını göster", null, false),
            Check("v_land", "Videoyu yatay modda oynat", null, false),
            Check("v_bright", "Video oynatılırken parlaklığı değiştirin", "Videoda dikey kaydırarak", false),
            Nav("Ses", null, 0, "vaudio"),
            Slide("watch_pct", "İzlenme", 50f, 100f, 95f, "Bu yüzde sayısından daha fazla izlendiyse video izlendi olarak işaretlenir", 0))
        "vaudio" -> "Ses" to listOf(
            Act("Ses ve ekolayzır", "Sistem ekolayzırını aç", null) { App.openEq(it) },
            Check("p_noisy", "Kulaklık çıkınca duraklat", null, true) { App.applyAudio() },
            Check("p_focus", "Ses odağını yönet", "Arama/navigasyon sesinde otomatik duraklat", true) { App.applyAudio() })
        "home" -> "Ana ekran" to listOf(
            Nav("Gösterge tablosunu düzenle", null, R.drawable.ic_edit, "home_edit"),
            Act("Ana ekran sırasını sıfırla", null, R.drawable.ic_refresh) { App.setStr("home_order", ""); it.toast("Sıra sıfırlandı") })
        "home_edit" -> "Gösterge tablosunu düzenle" to (App.homeOrder().map<String, Item> { HomeRow(it, homeNames[it] ?: it) } + listOf<Item>(
            Check("home_favs", "Favori Kanallar", null, true),
            Check("home_recent", "Son İçerikler", null, true)))
        "car" -> "Araç Uygulamaları" to listOf(
            Check("car_tv", "TV", "Araç ekranında göster", true),
            Check("car_yt", "Youtube", null, true),
            Check("car_cast", "Ekran Yansıtma", null, true),
            Check("car_radio", "Radyo", null, true),
            Check("car_phone", "Telefon Uygulamaları", "Seçtiğin uygulamaları araç ekranında göster", true),
            Act("Telefon uygulamaları", PhoneApps.selected().size.toString() + " uygulama seçili. Dokunup ekle veya çıkar", R.drawable.ic_phone) { a ->
                a.startActivity(Intent(a, PhoneAppsActivity::class.java).putExtra("pick", true)) },
            Act("Diğer uygulamaların üzerinde göster", "Araçtan telefon uygulaması açılmazsa bu izni ver", null) { a ->
                a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))) })
        "keys" -> "Tuş atamaları" to (KeyMap.keys.map { (name, _) ->
            Choice("key_" + name, name, KeyMap.actions, KeyMap.def(name)) as Item } + listOf<Item>(
            Act("Varsayılanlara dön", "Tüm tuş atamalarını sıfırla", null) { a ->
                KeyMap.keys.forEach { (n, _) -> App.setInt("key_" + n, KeyMap.def(n)) }
                a.toast("Tuş atamaları sıfırlandı"); a.recreate() }))
        "plug" -> "Eklentiler" to listOf(
            Nav("TV", null, R.drawable.ic_tv, "pl_tv"),
            Nav("Youtube", null, R.drawable.ic_play, "pl_yt"),
            Nav("Web tarayıcı", null, R.drawable.ic_globe, "pl_web"),
            Nav("Radyo", null, R.drawable.ic_radio, "pl_radio"),
            Nav("Podcastlar", null, R.drawable.ic_more, "pl_pod"))
        "pl_tv" -> "TV" to listOf(
            Check("home_tv", "Etkinleştir", null, true),
            Act("Kaynaklar", "M3U / IPTV liste adresi", null) { it.sources() })
        "pl_yt" -> "Youtube" to listOf(
            Check("home_yt", "Etkinleştir", null, true),
            Choice("yt_dark", "Desteklenirse karanlık modu zorla", listOf("Otomatik", "Açık", "Kapalı"), 0, "Cihaz temasını takip etmek için \"Otomatik\" seçeneğini seçin.", ""),
            Check("yt_q", "En yüksek video kalitesini otomatik seç", null, true),
            Check("yt_fs", "Otomatik tam ekran", null, true),
            Check("yt_native", "YouTube'un kendi oynatıcısını kullan", "CarTube'da tam ekranda her zaman YouTube'un kendi tuşları kalır", true),
            Check("yt_block", "Reklam engelleme", "Reklam isteklerini ve reklam verisini engeller", true),
            Check("yt_skip", "Reklamları atlamayı deneyin", "Çıkan reklamı atlamaya / sona sarmaya çalışır", true),
            Nav("SponsorBlock", "YouTube izlerken kitle kaynaklı bölümleri atlayın", 0, "sb"))
        "sb" -> "SponsorBlock" to listOf(
            Check("sb_on", "Etkinleştir", "Bölüm verisi sponsor.ajay.app'tan alınır", false),
            Check("sb_sponsor", "Sponsorluk", null, true),
            Check("sb_selfpromo", "Kendi reklamı / ücretsiz tanıtım", null, true),
            Check("sb_interaction", "Abone ol / beğen hatırlatması", null, true),
            Check("sb_intro", "Giriş animasyonu", null, false),
            Check("sb_outro", "Bitiş / kapanış", null, false),
            Check("sb_music_offtopic", "Müzik dışı bölüm", null, false))
        "pl_web" -> "Web tarayıcı" to listOf(
            Check("home_web", "Etkinleştir", null, true),
            Act("Başlangıç adresi", "Web kartının açacağı sayfa", null) { it.webHome() })
        "pl_radio" -> "Radyo" to listOf(
            Check("home_radio", "Etkinleştir", null, true),
            Act("Kaynaklar", "Radyo listesi (Ad|URL)", null) { it.sources() })
        "pl_pod" -> "Podcastlar" to listOf(
            Act("Bu sürümde henüz yok", "Sonraki sürümde eklenecek", null) { })
        "other" -> "Diğer" to listOf(
            Act("Kaynaklar", "M3U / IPTV adresi ve radyo listesi", null) { it.sources() },
            Nav("Tuş atamaları", "Medya ve donanım tuşlarına eylem ata", 0, "keys"),
            Act("İlk kurulumu aç", "Tüm ayarları varsayılana döndür", null) { it.confirmReset() },
            Nav("Tanılama", "Çökmeler için yerel rapor", 0, "diag"),
            Nav("Yedekleme ve geri yükleme", "Ayarları cihazlar arasında aktarın", 0, "backup"))
        "diag" -> "Tanılama" to listOf(
            Check("diag", "Çökme raporlarını kaydet", "Uygulamayı yeniden başlatınca etkinleşir", false),
            Act("Son hatayı göster", null, null) { a ->
                val t = App.str("last_crash").ifBlank { "Kayıtlı hata yok" }
                AlertDialog.Builder(a).setMessage(t.take(3000)).setPositiveButton(L.t("Tamam"), null).show() },
            Act("Hata kaydını temizle", null, null) { App.setStr("last_crash", ""); it.toast("Temizlendi") })
        "backup" -> "Yedekleme ve geri yükleme" to listOf(
            Act("Ayarları panoya kopyala", "JSON olarak", null) { a ->
                (a.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("cartube", App.exportJson()))
                a.toast("Panoya kopyalandı") },
            Act("Panodan geri yükle", "Kopyaladığın yedeği uygular", null) { a ->
                try {
                    val t = (a.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.text.toString()
                    App.importJson(t); App.applyAudio(); a.toast("Geri yüklendi"); a.recreate()
                } catch (e: Exception) { a.toast("Panoda geçerli yedek yok") } })
        "conn" -> "Bağlantı ve izin denetimi" to listOf(
            Act("Android Auto'yu aç", "Bağlantı ve geliştirici ayarları için", null) { a ->
                val i = a.packageManager.getLaunchIntentForPackage("com.google.android.projection.gearhead")
                if (i != null) a.startActivity(i) else a.toast("Android Auto yüklü değil") },
            Act("CarTube uygulama izinleri", "Sistem ayarlarında aç", null) { a ->
                a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.packageName))) },
            Act("Pil kısıtlamaları", "Arka planda çalma için kısıtlamayı kaldır", null) { a ->
                a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        else -> "Ayarlar" to listOf(
            Nav("Arayüz", null, R.drawable.ic_tune, "ui"),
            Nav("Ses ve asistan", "Sesli komutlar, karşılama mesajı", R.drawable.ic_mic, "voice"),
            Nav("Oynatma ayarları", null, R.drawable.ic_play, "play"),
            Nav("Ana ekran", "Kartları düzenle, sırayı sıfırla", R.drawable.ic_home, "home"),
            Nav("Araç Uygulamaları", "Araç ekranında görünecek uygulamaları seçin", R.drawable.ic_grid, "car"),
            Nav("Eklentiler", null, R.drawable.ic_globe, "plug"),
            Nav("Diğer", null, R.drawable.ic_more, "other"),
            Nav("Bağlantı ve izin denetimi", "Android Auto bağlantısını ve isteğe bağlı sistem ayarlarını görüntüleyin.", R.drawable.ic_cast, "conn"))
    }

    private fun na(base: String) = L.t(base) + " (" + L.t(NA) + ")"
    fun toast(s: String) = Toast.makeText(this, L.t(s), Toast.LENGTH_SHORT).show()

    fun sources() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val m3u = EditText(this).apply { hint = L.t("M3U / IPTV liste adresi (URL)"); setText(App.m3uUrl); setSingleLine() }
        val rad = EditText(this).apply { hint = L.t("Radyolar: her satıra  Ad|Yayın URL"); setText(App.radios); minLines = 4; gravity = Gravity.TOP }
        l.addView(m3u); l.addView(rad)
        AlertDialog.Builder(this).setTitle(L.t("Kaynaklar")).setView(l)
            .setPositiveButton(L.t("Kaydet")) { _, _ -> App.m3uUrl = m3u.text.toString().trim(); App.radios = rad.text.toString() }
            .setNegativeButton(L.t("İptal"), null).show()
    }

    fun webHome() {
        val e = EditText(this).apply { hint = "https://www.google.com"; setText(App.str("web_home")); setSingleLine() }
        AlertDialog.Builder(this).setTitle(L.t("Başlangıç adresi")).setView(e)
            .setPositiveButton(L.t("Kaydet")) { _, _ -> var u = e.text.toString().trim(); if (u.isNotBlank() && !u.startsWith("http")) u = "https://$u"; App.setStr("web_home", u) }
            .setNegativeButton(L.t("İptal"), null).show()
    }

    fun confirmReset() = AlertDialog.Builder(this).setMessage(L.t("Tüm ayarlar sıfırlansın mı?"))
        .setPositiveButton(L.t("Sıfırla")) { _, _ -> App.resetAll(); App.applyAudio(); toast("Sıfırlandı"); recreate() }
        .setNegativeButton(L.t("İptal"), null).show()

    private fun move(key: String, d: Int) {
        val l = App.homeOrder().toMutableList()
        val i = l.indexOf(key); val j = i + d
        if (i < 0 || j !in l.indices) return
        l[i] = l[j].also { l[j] = l[i] }
        App.setStr("home_order", l.joinToString(","))
        recreate()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val id = intent.getStringExtra("page") ?: "root"
        val (title, items) = page(id)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        root.addView(mini())
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(12)) }
        items.forEach { col.addView(row(it)) }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottom(title))
        setContentView(root)
    }

    private fun scale() = App.float("ui_text", App.D_TEXT)

    private fun card(): LinearLayout = LinearLayout(this).apply {
        background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(Theme.setCard()) }; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(6) }
    }
    private fun texts(t: String, sub: String?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(this@SettingsActivity).apply { text = L.t(t); setTextColor(Color.WHITE); textSize = 19f * scale(); setTypeface(null, Typeface.BOLD) })
        if (sub != null) addView(TextView(this@SettingsActivity).apply { text = L.t(sub); setTextColor(Color.parseColor("#B8C4D0")); textSize = 14f * scale() })
    }
    private fun icon(res: Int?): View? = res?.takeIf { it != 0 }?.let {
        ImageView(this).apply { setImageResource(it); setColorFilter(blue); layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(16) } } }
    private fun chev() = ImageView(this).apply { setImageResource(R.drawable.ic_chevron); setColorFilter(blue) }
    private fun arrow(rot: Float, onClick: () -> Unit) = ImageButton(this).apply {
        setBackgroundColor(Color.TRANSPARENT); setImageResource(R.drawable.ic_chevron); setColorFilter(blue); rotation = rot
        setOnClickListener { onClick() }; layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
    }
    private fun fmt(x: Float, dec: Int): String {
        if (dec == 0) return x.toInt().toString()
        var s = "%.2f".format(x).trimEnd('0'); if (s.endsWith(".")) s += "0"; return s
    }

    private fun row(it: Item): View {
        val c = card()
        when (it) {
            is Nav -> { icon(it.icon)?.let(c::addView); c.addView(texts(it.title, it.sub), LinearLayout.LayoutParams(0, -2, 1f)); c.addView(chev())
                c.setOnClickListener { _ -> startActivity(Intent(this, SettingsActivity::class.java).putExtra("page", it.page)) } }
            is Act -> { icon(it.icon)?.let(c::addView); c.addView(texts(it.title, it.sub), LinearLayout.LayoutParams(0, -2, 1f)); c.addView(chev())
                c.setOnClickListener { _ -> it.run(this) } }
            is Check -> {
                val cb = CheckBox(this).apply { isChecked = App.bool(it.key, it.def); buttonTintList = android.content.res.ColorStateList.valueOf(blue)
                    setOnCheckedChangeListener { _, v -> App.setBool(it.key, v); it.onChange?.invoke() } }
                c.addView(texts(it.title, it.sub), LinearLayout.LayoutParams(0, -2, 1f)); c.addView(cb)
                c.setOnClickListener { _ -> cb.toggle() } }
            is HomeRow -> {
                val cb = CheckBox(this).apply { isChecked = App.bool("home_" + it.key, true); buttonTintList = android.content.res.ColorStateList.valueOf(blue)
                    setOnCheckedChangeListener { _, v -> App.setBool("home_" + it.key, v) } }
                c.addView(texts(it.title, null), LinearLayout.LayoutParams(0, -2, 1f))
                c.addView(arrow(-90f) { move(it.key, -1) }); c.addView(arrow(90f) { move(it.key, 1) }); c.addView(cb) }
            is Choice -> {
                val cur = it.options[App.int(it.key, it.def).coerceIn(0, it.options.size - 1)]
                c.addView(texts(it.title, L.t(it.prefix) + L.t(cur) + (if (it.sub != null) ". " + L.t(it.sub) else "")), LinearLayout.LayoutParams(0, -2, 1f))
                c.setOnClickListener { _ -> AlertDialog.Builder(this).setTitle(L.t(it.title))
                    .setSingleChoiceItems(it.options.map { o -> L.t(o) }.toTypedArray(), App.int(it.key, it.def)) { d, w -> App.setInt(it.key, w); d.dismiss(); recreate() }.show() } }
            is Slide -> {
                c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.START
                val v = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f }
                val cur = App.float(it.key, it.def); v.text = fmt(cur, it.dec)
                val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                head.addView(texts(it.title, it.sub), LinearLayout.LayoutParams(0, -2, 1f)); head.addView(v)
                val sb = SeekBar(this).apply { max = 100; progress = ((cur - it.min) / (it.max - it.min) * 100).toInt()
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { val x = it.min + (it.max - it.min) * p / 100f; v.text = fmt(x, it.dec); if (u) App.setFloat(it.key, x) }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {}
                    }) }
                c.addView(head, LinearLayout.LayoutParams(-1, -2)); c.addView(sb, LinearLayout.LayoutParams(-1, -2)) }
        }
        return c
    }

    private fun mini(): View {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(36), dp(12), dp(10)) }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        miniTitle = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD); maxLines = 1 }
        miniSub = TextView(this).apply { setTextColor(Color.parseColor("#B0B5B8")); textSize = 13f; maxLines = 1 }
        tx.addView(miniTitle); tx.addView(miniSub)
        r.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        miniBtn = ImageButton(this).apply { background = Theme.circle(Theme.mix(Color.parseColor("#0E1214"), Theme.set(), 0.35f), Theme.set()); setImageResource(R.drawable.ic_play)
            setOnClickListener { App.togglePlay() }
            setOnLongClickListener { if (App.bool("pp_stop", true)) { App.stopAll(); true } else false } }
        r.addView(miniBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        return r
    }
    private fun refreshMini() {
        val t = App.nowTitle()
        miniTitle.text = t ?: L.t("Oynatılan içerik yok")
        miniSub.text = if (t == null) L.t("Kontrol etmek için bir içerik başlat") else if (App.nowPlaying()) L.t("Oynatılıyor") else L.t("Duraklatıldı")
        miniBtn.setImageResource(if (App.nowPlaying()) R.drawable.ic_pause else R.drawable.ic_play)
    }
    private fun bottom(t: String): View {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(16), dp(20)); setBackgroundColor(Color.parseColor("#0E141C")) }
        r.addView(TextView(this).apply { text = L.t(t); setTextColor(Color.WHITE); textSize = 20f; setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(ImageButton(this).apply { background = Theme.circle(Theme.mix(Color.parseColor("#0E1214"), Theme.set(), 0.35f), Theme.set()); setImageResource(R.drawable.ic_home); setColorFilter(Color.WHITE)
            setOnClickListener { startActivity(Intent(this@SettingsActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } },
            LinearLayout.LayoutParams(dp(56), dp(56)))
        return r
    }
    override fun onStart() { super.onStart(); App.player.addListener(pl); Vlc.onState = { runOnUiThread { refreshMini() } }; refreshMini() }
    override fun onStop() { super.onStop(); App.player.removeListener(pl); Vlc.onState = null }
    override fun onRestart() { super.onRestart(); if ((intent.getStringExtra("page") ?: "root") == "car") recreate() }
}
