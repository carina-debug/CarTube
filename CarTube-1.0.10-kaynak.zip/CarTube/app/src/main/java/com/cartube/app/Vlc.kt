package com.cartube.app

import android.net.Uri
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/** VLC motoru: Medya motoru ayarlarından "VLC" seçilince TV/Medya/Radyo bunun üstünden çalar. */
object Vlc {
    private var lib: LibVLC? = null
    private var mp: MediaPlayer? = null
    var title: String? = null
    var layout: VLCVideoLayout? = null     // açık olan video ekranı
    var onState: (() -> Unit)? = null      // mini oynatıcıyı güncellemek için

    private fun ensure(): MediaPlayer {
        mp?.let { return it }
        val l = LibVLC(App.ctx, arrayListOf("--network-caching=1500", "--audio-time-stretch"))
        lib = l
        return MediaPlayer(l).also { p -> p.setEventListener { onState?.invoke() }; mp = p }
    }

    val isPlaying: Boolean get() = mp?.isPlaying == true

    fun play(name: String, url: String, video: Boolean) {
        val p = ensure()
        p.stop()
        p.detachViews()
        val hw = App.int("hw", 0) == 0
        val lay = layout
        if (video && lay != null) {
            p.attachViews(lay, null, false, false)
            p.setVideoScale(when (App.int("video_resize", 0)) {
                1 -> MediaPlayer.ScaleType.SURFACE_FILL
                2 -> MediaPlayer.ScaleType.SURFACE_FIT_SCREEN
                else -> MediaPlayer.ScaleType.SURFACE_BEST_FIT })
        }
        val m = Media(lib!!, Uri.parse(url))
        m.setHWDecoderEnabled(hw, false)
        p.media = m
        m.release()
        title = name
        p.play()
        onState?.invoke()
    }

    fun pause() { mp?.pause(); onState?.invoke() }
    fun resume() { mp?.play(); onState?.invoke() }
    fun stop() { mp?.stop(); title = null; onState?.invoke() }
    fun seekBy(ms: Long) { mp?.let { p -> p.time = (p.time + ms).coerceAtLeast(0) } }
    fun detach() { try { mp?.detachViews() } catch (e: Exception) { }; layout = null }
}
