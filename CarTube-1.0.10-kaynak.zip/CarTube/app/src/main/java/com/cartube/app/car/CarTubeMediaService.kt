package com.cartube.app.car

import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import com.cartube.app.App
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/** Android Auto "Medya" listesinde görünen servis. Radyo/favori/son çalınanları App.player ile çalar. */
class CarTubeMediaService : MediaLibraryService() {
    private var session: MediaLibrarySession? = null

    override fun onCreate() {
        super.onCreate()
        session = MediaLibrarySession.Builder(this, App.player, Callback()).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onDestroy() {
        session?.release(); session = null
        super.onDestroy()
    }

    private fun folder(id: String, title: String) = MediaItem.Builder().setMediaId(id)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setIsBrowsable(true).setIsPlayable(false)
            .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED).build()).build()

    private fun track(name: String, url: String) = MediaItem.Builder().setMediaId(url).setUri(url)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(name).setIsBrowsable(false).setIsPlayable(true)
            .setMediaType(MediaMetadata.MEDIA_TYPE_RADIO_STATION).build()).build()

    private inner class Callback : MediaLibrarySession.Callback {
        override fun onGetLibraryRoot(session: MediaLibrarySession, browser: MediaSession.ControllerInfo,
                                      params: LibraryParams?): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(folder("root", "CarTube"), params))

        override fun onGetChildren(session: MediaLibrarySession, browser: MediaSession.ControllerInfo,
                                   parentId: String, page: Int, pageSize: Int,
                                   params: LibraryParams?): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            val items: List<MediaItem> = when (parentId) {
                "root" -> listOf(folder("radios", "Radyolar"), folder("favs", "Favoriler"), folder("recent", "Son çalınanlar"))
                "radios" -> App.radioList().map { track(it.first, it.second) }
                "favs" -> App.favs().map { track(it.first, it.second) }
                "recent" -> App.recents().map { track(it.first, it.second) }
                else -> emptyList()
            }
            return Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
        }

        override fun onMediaButtonEvent(session: MediaSession, controllerInfo: MediaSession.ControllerInfo,
                                        intent: android.content.Intent): Boolean {
            @Suppress("DEPRECATION")
            val e = intent.getParcelableExtra<android.view.KeyEvent>(android.content.Intent.EXTRA_KEY_EVENT) ?: return false
            return com.cartube.app.KeyMap.handle(applicationContext, null, e)
        }

        override fun onGetItem(session: MediaLibrarySession, browser: MediaSession.ControllerInfo,
                               mediaId: String): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(track(mediaId, mediaId), null))

        // Auto'dan gelen mediaId (= URL) öğesini çalınabilir hale getirir
        override fun onAddMediaItems(mediaSession: MediaSession, controller: MediaSession.ControllerInfo,
                                     mediaItems: MutableList<MediaItem>): ListenableFuture<MutableList<MediaItem>> {
            val out = mediaItems.map { it.buildUpon().setUri(it.requestMetadata.mediaUri ?: it.localConfiguration?.uri ?: android.net.Uri.parse(it.mediaId)).build() }
                .toMutableList()
            mediaItems.firstOrNull()?.let { App.addRecent(it.mediaMetadata.title?.toString() ?: it.mediaId, it.mediaId) }
            return Futures.immediateFuture(out)
        }
    }
}
