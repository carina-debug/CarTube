package com.cartube.app

import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.ui.PlayerView
import java.net.URL
import kotlin.concurrent.thread

class TvActivity : AppCompatActivity() {
    private val channels = mutableListOf<Pair<String, String>>()
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pv = PlayerView(this).apply { player = App.player
            resizeMode = when (App.int("video_resize", 0)) { 1 -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL; 2 -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM; else -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT } }
        val lv = ListView(this)
        root.addView(pv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val url = App.m3uUrl
        if (url.isBlank()) { Toast.makeText(this, "Önce Ayarlar'dan M3U adresi girin", Toast.LENGTH_LONG).show(); return }
        thread {
            try {
                var name = ""
                URL(url).readText().lines().forEach { l ->
                    if (l.startsWith("#EXTINF")) name = l.substringAfterLast(",").trim()
                    else if (l.isNotBlank() && !l.startsWith("#")) { channels += (name.ifBlank { l }) to l.trim(); name = "" }
                }
            } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Liste yüklenemedi", Toast.LENGTH_LONG).show() } }
            runOnUiThread {
                lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, channels.map { it.first })
                lv.setOnItemClickListener { _, _, i, _ -> App.play(channels[i].first, channels[i].second) }
                lv.setOnItemLongClickListener { _, _, i, _ -> App.addFav(channels[i].first, channels[i].second); Toast.makeText(this, "Favorilere eklendi", Toast.LENGTH_SHORT).show(); true }
            }
        }
    }
}
