package com.cartube.app

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

/** TV: birden fazla kanal listesi, gruplama, düzenleme. Alt çubuğun ortasındaki düğme liste menüsünü açar. */
class TvActivity : AppCompatActivity() {
    private val st get() = Stores.tv
    private lateinit var listBtn: TextView
    private lateinit var groupBtn: TextView
    private lateinit var lv: ListView
    private var group = ""
    private var shown = listOf<ListStore.Item>()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        root.addView(VideoUi.create(this), LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this).apply { setPadding(dp(14), dp(8), dp(14), dp(4)) }
        fun chip() = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD); maxLines = 1; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        listBtn = chip().apply { setOnClickListener { chooseList() } }
        groupBtn = chip().apply { setOnClickListener { chooseGroup() } }
        bar.addView(listBtn, LinearLayout.LayoutParams(0, -2, 1f)); bar.addView(groupBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bar)
        lv = ListView(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Ui.navBar(this, null, R.drawable.ic_edit) { editMenu() })
        setContentView(root)
        lv.setOnItemClickListener { _, _, i, _ -> shown.getOrNull(i)?.let { App.play(it.n, it.u, true) } }
        lv.setOnItemLongClickListener { _, _, i, _ -> shown.getOrNull(i)?.let { channelMenu(it) }; true }
        refresh()
        val c = st.cur()
        if (c != null && c.items.isEmpty() && c.src.isNotBlank()) reload(c)
    }

    private fun refresh() {
        val c = st.cur()
        if (group.isNotBlank() && c?.items?.none { it.g == group } != false) group = ""
        listBtn.text = (c?.name ?: L.t("Liste yok")) + " ▾"
        groupBtn.text = (if (group.isBlank()) L.t("Tüm gruplar") else group) + " ▾"
        shown = c?.items?.filter { group.isBlank() || it.g == group } ?: emptyList()
        val names = if (shown.isEmpty()) listOf(L.t("Önce Ayarlar'dan M3U adresi girin")) else shown.map { (if (it.g.isNotBlank() && group.isBlank()) "[${it.g}] " else "") + it.n }
        lv.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            override fun getView(p: Int, v: android.view.View?, g: android.view.ViewGroup): android.view.View =
                super.getView(p, v, g).also { (it as TextView).setTextColor(Color.WHITE) }
        }
    }

    private fun groups() = st.cur()?.items?.map { it.g }?.filter { it.isNotBlank() }?.distinct()?.sorted() ?: emptyList()

    private fun chooseList() {
        if (st.lists.isEmpty()) { editMenu(); return }
        Ui.menu(this, "Liste seç", st.lists.map { it.name + " (" + it.items.size + ")" }) { st.active = it; st.save(); group = ""; refresh() }
    }

    private fun chooseGroup() {
        val g = groups()
        if (g.isEmpty()) { Ui.toast(this, "Henüz grup yok. Kanala uzun basıp grup ata."); return }
        Ui.menu(this, "Grup seç", listOf(L.t("Tüm gruplar")) + g) { group = if (it == 0) "" else g[it - 1]; refresh() }
    }

    private fun channelMenu(ch: ListStore.Item) {
        Ui.menu(this, ch.n, listOf("Favorilere ekle", "Grup ata", "Kanalı sil")) { i ->
            when (i) {
                0 -> { App.addFav(ch.n, ch.u); Ui.toast(this, "Favorilere eklendi") }
                1 -> Ui.ask(this, "Grup ata", listOf("Grup adı"), listOf(ch.g)) { v -> ch.g = v[0]; st.save(); refresh() }
                2 -> { st.cur()?.items?.remove(ch); st.save(); refresh() }
            }
        }
    }

    private fun editMenu() {
        Ui.menu(this, "TV listeleri", listOf("Liste ekle (M3U adresi)", "Yeni boş liste", "Kanal ekle", "Grup yönetimi",
            "Listeyi yenile", "Listeyi yeniden adlandır", "Listeyi sil")) { i ->
            when (i) {
                0 -> Ui.ask(this, "Liste ekle (M3U adresi)", listOf("Liste adı", "M3U / IPTV liste adresi")) { v -> addFromUrl(v[0], v[1]) }
                1 -> Ui.ask(this, "Yeni boş liste", listOf("Liste adı")) { v -> if (v[0].isNotBlank()) { st.add(ListStore.Lst(v[0])); group = ""; refresh() } }
                2 -> Ui.ask(this, "Kanal ekle", listOf("Ad", "Yayın adresi (URL)", "Grup (isteğe bağlı)")) { v ->
                    if (v[1].isNotBlank()) {
                        if (st.cur() == null) st.add(ListStore.Lst("Listem"))
                        st.cur()!!.items.add(ListStore.Item(v[0].ifBlank { v[1] }, v[1], v[2])); st.save(); refresh()
                    }
                }
                3 -> groupMenu()
                4 -> st.cur()?.let { reload(it) }
                5 -> st.cur()?.let { c -> Ui.ask(this, "Listeyi yeniden adlandır", listOf("Liste adı"), listOf(c.name)) { v -> if (v[0].isNotBlank()) { c.name = v[0]; st.save(); refresh() } } }
                6 -> st.cur()?.let { c -> Ui.confirm(this, "\"${c.name}\" " + L.t("silinsin mi?")) { st.removeActive(); group = ""; refresh() } }
            }
        }
    }

    private fun groupMenu() {
        val g = groups()
        if (g.isEmpty()) { Ui.toast(this, "Henüz grup yok. Kanala uzun basıp grup ata."); return }
        Ui.menu(this, "Grup yönetimi", listOf("Grubu yeniden adlandır", "Grubu sil")) { act ->
            Ui.menu(this, "Grup seç", g) { gi ->
                val name = g[gi]
                if (act == 0) Ui.ask(this, "Grubu yeniden adlandır", listOf("Grup adı"), listOf(name)) { v ->
                    st.cur()?.items?.filter { it.g == name }?.forEach { it.g = v[0] }; st.save(); group = ""; refresh() }
                else Ui.confirm(this, "\"$name\" " + L.t("grubu silinsin mi? (kanallar kalır)")) {
                    st.cur()?.items?.filter { it.g == name }?.forEach { it.g = "" }; st.save(); group = ""; refresh() }
            }
        }
    }

    private fun addFromUrl(name: String, url: String) {
        if (url.isBlank()) return
        val l = ListStore.Lst(name.ifBlank { url.substringAfterLast('/') }, url)
        st.add(l); group = ""; refresh(); reload(l)
    }

    private fun reload(c: ListStore.Lst) {
        if (c.src.isBlank()) { Ui.toast(this, "Bu liste elle oluşturulmuş"); return }
        Ui.toast(this, "Yükleniyor…")
        thread {
            val items = try { ListStore.parse(ListStore.http(c.src)) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (items.isEmpty()) Ui.toast(this, "Liste yüklenemedi")
                else {
                    // elle atanan grupları koru
                    val old = c.items.associate { it.u to it.g }
                    items.forEach { if (it.g.isBlank()) it.g = old[it.u] ?: "" }
                    c.items = items.toMutableList(); st.save(); refresh()
                }
            }
        }
    }

    override fun onDestroy() { Vlc.detach(); Sys.onSize = null; super.onDestroy() }
}
