package com.cartube.app

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.widget.Toast
import androidx.car.app.model.CarIcon
import androidx.core.graphics.drawable.IconCompat
import androidx.core.graphics.drawable.toBitmap

/** Araç için seçilen telefon uygulamalarını tutar ve açar. */
object PhoneApps {
    class Info(val label: String, val pkg: String, val icon: Drawable)

    private const val KEY = "car_apps"

    fun selected(): List<String> = App.str(KEY).lines().map { it.trim() }.filter { it.isNotEmpty() }
    fun isSelected(pkg: String) = selected().contains(pkg)
    fun toggle(pkg: String, on: Boolean) {
        val l = selected().filter { it != pkg }
        App.setStr(KEY, (if (on) l + pkg else l).joinToString("\n"))
    }

    /** Telefondaki başlatılabilir tüm uygulamalar (CarTube hariç), ada göre sıralı. */
    fun installed(ctx: Context): List<Info> {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { Info(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }

    /** Seçilmiş uygulamalar (kaldırılmış olanlar atlanır). */
    fun selectedInfos(ctx: Context): List<Info> {
        val pm = ctx.packageManager
        return selected().mapNotNull { p ->
            try {
                val ai = pm.getApplicationInfo(p, 0)
                Info(ai.loadLabel(pm).toString(), p, ai.loadIcon(pm))
            } catch (e: Exception) { null }
        }
    }

    fun launch(ctx: Context, pkg: String) {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { Toast.makeText(ctx, L.t("Uygulama açılamadı"), Toast.LENGTH_SHORT).show(); return }
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(ctx, L.t("Uygulama açılamadı"), Toast.LENGTH_SHORT).show() }
    }

    fun carIcon(d: Drawable): CarIcon = CarIcon.Builder(IconCompat.createWithBitmap(d.toBitmap(128, 128))).build()
}
