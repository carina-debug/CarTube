package com.cartube.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** İstasyon logoları için küçük, bağımlılıksız resim yükleyici. */
object ImgLoader {
    private val cache = LruCache<String, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())

    fun load(url: String, iv: ImageView, fallback: Int) {
        iv.tag = url
        if (url.isBlank() || !url.startsWith("http")) { iv.setImageResource(fallback); return }
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        iv.setImageResource(fallback)
        pool.execute {
            val bmp = try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 6000; c.readTimeout = 8000; c.setRequestProperty("User-Agent", "CarTube/1.0")
                c.inputStream.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 }) }
            } catch (e: Exception) { null }
            if (bmp != null) { cache.put(url, bmp); ui.post { if (iv.tag == url) iv.setImageBitmap(bmp) } }
        }
    }
}
