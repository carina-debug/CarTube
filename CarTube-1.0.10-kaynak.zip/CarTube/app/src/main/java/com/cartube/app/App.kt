package com.cartube.app

import android.app.Application
import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
        if (bool("diag", false)) installCrash()
    }
    companion object {
        lateinit var ctx: Context
        val player: ExoPlayer by lazy {
            ExoPlayer.Builder(ctx).setHandleAudioBecomingNoisy(bool("p_noisy", true))
                .setWakeMode(C.WAKE_MODE_NETWORK).build().also { it.setAudioAttributes(
                    androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), bool("p_focus", true)) }
        }
        fun play(title: String, url: String) {
            player.setMediaItem(MediaItem.Builder().setUri(url)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build()).build())
            player.prepare(); player.play()
        }
        private val sp get() = ctx.getSharedPreferences("cartube", Context.MODE_PRIVATE)
        var m3uUrl: String
            get() = sp.getString("m3u", "") ?: ""
            set(v) = sp.edit().putString("m3u", v).apply()
        var radios: String  // her satır: Ad|URL
            get() = sp.getString("radios", "") ?: ""
            set(v) = sp.edit().putString("radios", v).apply()
        var carMode: Boolean
            get() = sp.getBoolean("car", true)
            set(v) = sp.edit().putBoolean("car", v).apply()
        fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
        fun setBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
        fun float(k: String, d: Float) = sp.getFloat(k, d)
        fun setFloat(k: String, v: Float) = sp.edit().putFloat(k, v).apply()
        fun int(k: String, d: Int) = sp.getInt(k, d)
        fun setInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()
        fun str(k: String) = sp.getString(k, "") ?: ""
        fun setStr(k: String, v: String) = sp.edit().putString(k, v).apply()
        fun resetAll() = sp.edit().clear().apply()
        fun exportJson(): String {
            val o = org.json.JSONObject()
            sp.all.forEach { (k, v) -> if (k != "last_crash") o.put(k, v) }
            return o.toString()
        }
        fun importJson(t: String) {
            val o = org.json.JSONObject(t); val e = sp.edit()
            o.keys().forEach { k -> when (val v = o.get(k)) {
                is Boolean -> e.putBoolean(k, v); is Int -> e.putInt(k, v)
                is Double -> e.putFloat(k, v.toFloat()); is String -> e.putString(k, v) } }
            e.apply()
        }
        fun applyAudio() {
            player.setHandleAudioBecomingNoisy(bool("p_noisy", true))
            player.setAudioAttributes(androidx.media3.common.AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), bool("p_focus", true))
        }
        fun installCrash() {
            val old = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                setStr("last_crash", android.util.Log.getStackTraceString(e)); old?.uncaughtException(t, e)
            }
        }
        fun radioList(): List<Pair<String, String>> = radios.lines().mapNotNull {
            val p = it.split("|", limit = 2)
            if (p.size == 2 && p[1].isNotBlank()) p[0].trim() to p[1].trim() else null
        }
    }
}
