package com.cartube.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
        if (bool("diag", false)) installCrash()
        registerActivityLifecycleCallbacks(object : android.app.Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(a: android.app.Activity, s: android.os.Bundle?) {
                val cb = a.window.callback
                if (cb != null && cb !is KeyMap.KeyCb) a.window.callback = KeyMap.KeyCb(cb, a)
            }
            override fun onActivityStarted(a: android.app.Activity) {}
            override fun onActivityResumed(a: android.app.Activity) {}
            override fun onActivityPaused(a: android.app.Activity) {}
            override fun onActivityStopped(a: android.app.Activity) {}
            override fun onActivitySaveInstanceState(a: android.app.Activity, s: android.os.Bundle) {}
            override fun onActivityDestroyed(a: android.app.Activity) {}
        })
    }
    companion object {
        lateinit var ctx: Context
        const val D_NAV = 0.61f
        const val D_BAR = 0.71f
        const val D_PANEL = 0.75f
        const val D_TEXT = 0.65f
        /** 0 = MediaPlayer, 1 = ExoPlayer, 2 = VLC */
        var cur = 1
        val usingVlc get() = cur == 2
        var onState: (() -> Unit)? = null
        var nowUrl: String? = null
        private var greetedApp = false
        private var greetedCar = false
        val player: ExoPlayer by lazy {
            ExoPlayer.Builder(ctx, androidx.media3.exoplayer.DefaultRenderersFactory(ctx).setEnableDecoderFallback(int("hw", 0) == 0)).setHandleAudioBecomingNoisy(bool("p_noisy", true))
                .setWakeMode(C.WAKE_MODE_NETWORK).build().also {
                    it.setAudioAttributes(
                        androidx.media3.common.AudioAttributes.Builder()
                            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), bool("p_focus", true))
                    it.addListener(object : androidx.media3.common.Player.Listener {
                        override fun onAudioSessionIdChanged(audioSessionId: Int) { Eq.attach(audioSessionId) }
                    })
                }
        }
        private fun engineFor(video: Boolean): Int {
            val e = int(if (video) "eng_v2" else "eng_a2", 1)
            return if (e == 2 && !bool("vlc_on", true)) 1 else e
        }
        private fun stopOthers(keep: Int) {
            if (keep != 1) player.stop()
            if (keep != 2) Vlc.stop()
            if (keep != 0) Sys.stop()
        }
        fun play(title: String, url: String, video: Boolean = false) {
            addRecent(title, url)
            nowUrl = url
            val e = engineFor(video)
            stopOthers(e); cur = e
            when (e) {
                2 -> Vlc.play(title, url, video)
                0 -> Sys.play(title, url, video)
                else -> {
                    player.setMediaItem(MediaItem.Builder().setUri(url)
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build()).build())
                    player.prepare(); player.play()
                }
            }
        }
        fun nowTitle(): String? = when (cur) { 2 -> Vlc.title; 0 -> Sys.title; else -> player.mediaMetadata.title?.toString() }
        fun nowPlaying(): Boolean = when (cur) { 2 -> Vlc.isPlaying; 0 -> Sys.isPlaying; else -> player.isPlaying }
        fun togglePlay() { if (nowPlaying()) pauseAll() else resume() }
        fun resume() { when (cur) { 2 -> Vlc.resume(); 0 -> Sys.resume(); else -> player.play() } }
        fun pauseAll() { when (cur) { 2 -> Vlc.pause(); 0 -> Sys.pause(); else -> player.pause() } }
        fun stopAll() { player.stop(); Vlc.stop(); Sys.stop() }
        fun seekBy(ms: Long) {
            when (cur) {
                2 -> Vlc.seekBy(ms)
                0 -> Sys.seekBy(ms)
                else -> { var t = (player.currentPosition + ms).coerceAtLeast(0); val d = player.duration; if (d != C.TIME_UNSET) t = t.coerceAtMost(d); player.seekTo(t) }
            }
        }
        fun greetText(): String {
            val custom = str("welcome_text")
            if (custom.isNotBlank()) return custom
            val n = str("welcome_name")
            val base = L.t("CarTube'a hoş geldin")
            return if (n.isBlank()) base else (if (L.isEn) "Hello $n, " else "Merhaba $n, ") + base.replaceFirstChar { it.lowercase() }
        }
        /** Uygulama açılışında / araca bağlanınca karşılama (yazı ve sesli). */
        fun greet(c: Context, car: Boolean) {
            if (car) { if (greetedCar) return; greetedCar = true } else { if (greetedApp) return; greetedApp = true }
            if (car && bool("welcome_once", false)) {
                val today = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
                if (str("welcome_last") == today) return
                setStr("welcome_last", today)
            }
            val text = greetText()
            if (bool("welcome", false) && !car) Toast.makeText(c, text, Toast.LENGTH_SHORT).show()
            if (car && bool("welcome_voice", false)) Tts.speak(text)
            if (!car && bool("welcome_voice_app", false)) Tts.speak(text)
        }
        private val sp get() = ctx.getSharedPreferences("cartube", Context.MODE_PRIVATE)
        var m3uUrl: String
            get() = sp.getString("m3u", "") ?: ""
            set(v) = sp.edit().putString("m3u", v).apply()
        var radios: String  // her satır: Ad|URL
            get() = sp.getString("radios", "") ?: ""
            set(v) = sp.edit().putString("radios", v).apply()
        var carMode: Boolean
            get() = sp.getBoolean("car", true)
            set(v) = sp.edit().putBoolean("car", v).apply()
        fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
        fun setBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
        fun float(k: String, d: Float) = sp.getFloat(k, d)
        fun setFloat(k: String, v: Float) = sp.edit().putFloat(k, v).apply()
        fun int(k: String, d: Int) = sp.getInt(k, d)
        fun setInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()
        fun str(k: String) = sp.getString(k, "") ?: ""
        fun setStr(k: String, v: String) = sp.edit().putString(k, v).apply()
        fun resetAll() = sp.edit().clear().apply()
        fun exportJson(): String {
            val o = org.json.JSONObject()
            sp.all.forEach { (k, v) -> if (k != "last_crash") o.put(k, v) }
            return o.toString()
        }
        fun importJson(t: String) {
            val o = org.json.JSONObject(t); val e = sp.edit()
            o.keys().forEach { k -> when (val v = o.get(k)) {
                is Boolean -> e.putBoolean(k, v); is Int -> e.putInt(k, v)
                is Double -> e.putFloat(k, v.toFloat()); is String -> e.putString(k, v) } }
            e.apply()
        }
        fun applyAudio() {
            player.setHandleAudioBecomingNoisy(bool("p_noisy", true))
            player.setAudioAttributes(androidx.media3.common.AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), bool("p_focus", true))
        }
        fun installCrash() {
            val old = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                setStr("last_crash", android.util.Log.getStackTraceString(e)); old?.uncaughtException(t, e)
            }
        }
        private fun pairs(k: String) = str(k).lines().mapNotNull {
            val p = it.split("|", limit = 2); if (p.size == 2 && p[1].isNotBlank()) p[0] to p[1] else null }
        private fun savePairs(k: String, l: List<Pair<String, String>>) = setStr(k, l.joinToString("\n") { it.first + "|" + it.second })
        private fun clean(n: String) = n.replace("|", "/").replace("\n", " ").trim()
        fun favs() = pairs("favs")
        fun addFav(n: String, u: String) { if (favs().none { it.second == u }) savePairs("favs", favs() + (clean(n) to u)) }
        fun removeFav(u: String) = savePairs("favs", favs().filter { it.second != u })
        fun recents() = pairs("recent")
        fun addRecent(n: String, u: String) = savePairs("recent", (listOf(clean(n) to u) + recents().filter { it.second != u }).take(10))
        fun shortcuts() = pairs("shortcuts")
        fun addShortcut(n: String, u: String) = savePairs("shortcuts", shortcuts() + (clean(n) to u))
        fun removeShortcut(u: String) = savePairs("shortcuts", shortcuts().filter { it.second != u })
        fun openEq(a: Context) { a.startActivity(Intent(a, EqualizerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        fun openSystemEq(a: android.app.Activity) {
            try {
                a.startActivityForResult(Intent("android.media.action.DISPLAY_AUDIO_EFFECT_CONTROL_PANEL")
                    .putExtra("android.media.extra.AUDIO_SESSION", player.audioSessionId)
                    .putExtra("android.media.extra.PACKAGE_NAME", a.packageName)
                    .putExtra("android.media.extra.CONTENT_TYPE", 0), 0)
            } catch (e: Exception) { Toast.makeText(a, L.t("Bu cihazda sistem ekolayzırı yok"), Toast.LENGTH_SHORT).show() }
        }
        fun voice(a: Context) {
            val tries = listOf(Intent(Intent.ACTION_VOICE_COMMAND), Intent("android.intent.action.VOICE_ASSIST"), Intent(Intent.ACTION_ASSIST))
            for (i in tries) {
                try { a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (e: Exception) { }
            }
            Toast.makeText(a, L.t("Ses asistanı bulunamadı"), Toast.LENGTH_SHORT).show()
        }
        fun watched() = str("watched").lines().filter { it.isNotBlank() }.toSet()
        fun addWatched(u: String) = setStr("watched", (watched() + u).toList().takeLast(500).joinToString("\n"))
        private val secs = listOf(5, 10, 15, 30, 60)
        fun skip(dir: Int, long: Boolean) {
            if (long && int("pn_long", 0) == 1 && cur == 1) {
                if (dir < 0) player.seekToPreviousMediaItem() else player.seekToNextMediaItem(); return
            }
            val sec = secs[int(if (long) "ff_long" else "ff_tap", if (long) 4 else 1).coerceIn(0, 4)] * 1000L
            seekBy(dir * sec)
        }
        val defaultOrder = listOf("tv", "yt", "cast", "radio", "media", "phone", "web")
        fun homeOrder(): List<String> {
            val st = str("home_order").split(",").filter { it in defaultOrder }.distinct()
            return st + defaultOrder.filter { it !in st }
        }
        fun radioList(): List<Pair<String, String>> = Stores.radio.cur()?.items?.map { it.n to it.u } ?: emptyList()
    }
}
