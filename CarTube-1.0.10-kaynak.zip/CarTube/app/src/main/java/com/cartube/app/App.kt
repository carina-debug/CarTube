package com.cartube.app

import android.app.Application
import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
    }
    companion object {
        lateinit var ctx: Context
        val player: ExoPlayer by lazy {
            ExoPlayer.Builder(ctx).setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_NETWORK).build().also { it.setAudioAttributes(
                    androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true) }
        }
        fun play(title: String, url: String) {
            player.setMediaItem(MediaItem.Builder().setUri(url)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build()).build())
            player.prepare(); player.play()
        }
        private val sp get() = ctx.getSharedPreferences("cartube", Context.MODE_PRIVATE)
        var m3uUrl: String
            get() = sp.getString("m3u", "") ?: ""
            set(v) = sp.edit().putString("m3u", v).apply()
        var radios: String  // her satır: Ad|URL
            get() = sp.getString("radios", "") ?: ""
            set(v) = sp.edit().putString("radios", v).apply()
        var carMode: Boolean
            get() = sp.getBoolean("car", true)
            set(v) = sp.edit().putBoolean("car", v).apply()
        fun radioList(): List<Pair<String, String>> = radios.lines().mapNotNull {
            val p = it.split("|", limit = 2)
            if (p.size == 2 && p[1].isNotBlank()) p[0].trim() to p[1].trim() else null
        }
    }
}
