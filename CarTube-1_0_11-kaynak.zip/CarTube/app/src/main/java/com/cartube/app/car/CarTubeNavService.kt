package com.cartube.app.car

import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import com.cartube.app.*

/** Android Auto başlatıcısında "CarTube Tam Ekran" girişi (Navigation kategorisi). */
class CarTubeNavService : CarAppService() {
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = object : Session() {
        override fun onCreateScreen(intent: Intent): Screen = NavHomeScreen(carContext)
    }
}

class NavHomeScreen(c: CarContext) : Screen(c) {
    private fun act(res: Int, cls: Class<*>) = Action.Builder()
        .setIcon(CarIcon.Builder(IconCompat.createWithResource(carContext, res)).build())
        .setOnClickListener {
            carContext.startActivity(Intent(carContext, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            CarToast.makeText(carContext, "Telefonda açıldı", CarToast.LENGTH_SHORT).show()
        }.build()

    override fun onGetTemplate(): Template {
        val strip = ActionStrip.Builder()
            .addAction(act(R.drawable.ic_tv, TvActivity::class.java))
            .addAction(act(R.drawable.ic_play, YouTubeActivity::class.java))
            .addAction(act(R.drawable.ic_cast, MirrorActivity::class.java))
            .addAction(act(R.drawable.ic_radio, RadioActivity::class.java))
            .build()
        return NavigationTemplate.Builder()
            .setActionStrip(strip)
            .setBackgroundColor(CarColor.createCustom(0xFF101418.toInt(), 0xFF101418.toInt()))
            .build()
    }
}
