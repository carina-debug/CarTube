package com.cartube.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
        if (bool("diag", false)) installCrash()
        registerActivityLifecycleCallbacks(object : android.app.Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(a: android.app.Activity, s: android.os.Bundle?) {
                val cb = a.window.callback
                if (cb != null && cb !is KeyMap.KeyCb) a.window.callback = KeyMap.KeyCb(cb, a)
            }
            override fun onActivityStarted(a: android.app.Activity) {}
            override fun onActivityResumed(a: android.app.Activity) {}
            override fun onActivityPaused(a: android.app.Activity) {}
            override fun onActivityStopped(a: android.app.Activity) {}
            override fun onActivitySaveInstanceState(a: android.app.Activity, s: android.os.Bundle) {}
            override fun onActivityDestroyed(a: android.app.Activity) {}
        })
    }
    companion object {
        lateinit var ctx: Context
        val player: ExoPlayer by lazy {
            ExoPlayer.Builder(ctx).setHandleAudioBecomingNoisy(bool("p_noisy", true))
                .setWakeMode(C.WAKE_MODE_NETWORK).build().also { it.setAudioAttributes(
                    androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), bool("p_focus", true)) }
        }
        fun play(title: String, url: String) {
            addRecent(title, url)
            player.setMediaItem(MediaItem.Builder().setUri(url)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build()).build())
            player.prepare(); player.play()
        }
        private val sp get() = ctx.getSharedPreferences("cartube", Context.MODE_PRIVATE)
        var m3uUrl: String
            get() = sp.getString("m3u", "") ?: ""
            set(v) = sp.edit().putString("m3u", v).apply()
        var radios: String  // her satır: Ad|URL
            get() = sp.getString("radios", "") ?: ""
            set(v) = sp.edit().putString("radios", v).apply()
        var carMode: Boolean
            get() = sp.getBoolean("car", true)
            set(v) = sp.edit().putBoolean("car", v).apply()
        fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
        fun setBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
        fun float(k: String, d: Float) = sp.getFloat(k, d)
        fun setFloat(k: String, v: Float) = sp.edit().putFloat(k, v).apply()
        fun int(k: String, d: Int) = sp.getInt(k, d)
        fun setInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()
        fun str(k: String) = sp.getString(k, "") ?: ""
        fun setStr(k: String, v: String) = sp.edit().putString(k, v).apply()
        fun resetAll() = sp.edit().clear().apply()
        fun exportJson(): String {
            val o = org.json.JSONObject()
            sp.all.forEach { (k, v) -> if (k != "last_crash") o.put(k, v) }
            return o.toString()
        }
        fun importJson(t: String) {
            val o = org.json.JSONObject(t); val e = sp.edit()
            o.keys().forEach { k -> when (val v = o.get(k)) {
                is Boolean -> e.putBoolean(k, v); is Int -> e.putInt(k, v)
                is Double -> e.putFloat(k, v.toFloat()); is String -> e.putString(k, v) } }
            e.apply()
        }
        fun applyAudio() {
            player.setHandleAudioBecomingNoisy(bool("p_noisy", true))
            player.setAudioAttributes(androidx.media3.common.AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), bool("p_focus", true))
        }
        fun installCrash() {
            val old = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                setStr("last_crash", android.util.Log.getStackTraceString(e)); old?.uncaughtException(t, e)
            }
        }
        private fun pairs(k: String) = str(k).lines().mapNotNull {
            val p = it.split("|", limit = 2); if (p.size == 2 && p[1].isNotBlank()) p[0] to p[1] else null }
        private fun savePairs(k: String, l: List<Pair<String, String>>) = setStr(k, l.joinToString("\n") { it.first + "|" + it.second })
        private fun clean(n: String) = n.replace("|", "/").replace("\n", " ").trim()
        fun favs() = pairs("favs")
        fun addFav(n: String, u: String) { if (favs().none { it.second == u }) savePairs("favs", favs() + (clean(n) to u)) }
        fun removeFav(u: String) = savePairs("favs", favs().filter { it.second != u })
        fun recents() = pairs("recent")
        fun addRecent(n: String, u: String) = savePairs("recent", (listOf(clean(n) to u) + recents().filter { it.second != u }).take(10))
        fun shortcuts() = pairs("shortcuts")
        fun addShortcut(n: String, u: String) = savePairs("shortcuts", shortcuts() + (clean(n) to u))
        fun removeShortcut(u: String) = savePairs("shortcuts", shortcuts().filter { it.second != u })
        fun openEq(a: android.app.Activity) {
            try {
                a.startActivityForResult(Intent("android.media.action.DISPLAY_AUDIO_EFFECT_CONTROL_PANEL")
                    .putExtra("android.media.extra.AUDIO_SESSION", player.audioSessionId)
                    .putExtra("android.media.extra.PACKAGE_NAME", a.packageName)
                    .putExtra("android.media.extra.CONTENT_TYPE", 0), 0)
            } catch (e: Exception) { Toast.makeText(a, "Bu cihazda sistem ekolayzırı yok", Toast.LENGTH_SHORT).show() }
        }
        fun voice(a: Context) {
            try { a.startActivity(Intent(Intent.ACTION_VOICE_COMMAND).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (e: Exception) { Toast.makeText(a, "Ses asistanı bulunamadı", Toast.LENGTH_SHORT).show() }
        }
        fun radioList(): List<Pair<String, String>> = radios.lines().mapNotNull {
            val p = it.split("|", limit = 2)
            if (p.size == 2 && p[1].isNotBlank()) p[0].trim() to p[1].trim() else null
        }
    }
}
