plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.cartube.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.cartube.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 10031
        versionName = "1.0.31"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    signingConfigs {
        create("cartube") {
            storeFile = file("cartube.p12")
            storePassword = "cartube123"
            keyAlias = "cartube"
            keyPassword = "cartube123"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("cartube") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("cartube") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.car.app:app:1.4.0")
    // Eski Android Auto projeksiyon SDK'sı (Mola/Fermata'daki "Tam Ekran" yolu; Play dışı kurulumda da listelenir)
    implementation(files("libs/aauto.aar"))
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1")
    implementation("com.google.guava:guava:32.1.3-android")
    implementation("androidx.webkit:webkit:1.11.0")
}
