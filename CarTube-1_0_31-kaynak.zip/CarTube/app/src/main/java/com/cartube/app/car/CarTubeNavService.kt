package com.cartube.app.car

import android.content.Intent
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template
import androidx.car.app.navigation.NavigationManager
import androidx.car.app.navigation.NavigationManagerCallback
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.cartube.app.*

/**
 * Android Auto başlatıcısında "CarTube Tam Ekran" girişi (Navigation kategorisi).
 * Açılışta CarTube'un tamamı araç ekranında dokunmatik gösterilir (CarUiScreen). Eski kutucuk ızgarası (HomeScreen) yedek olarak durur.
 */
class CarTubeNavService : CarAppService() {
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = object : Session() {
        override fun onCreateScreen(intent: Intent): Screen {
            if (!License.active()) return LicenseCarScreen(carContext)
            App.greet(carContext, true)
            val nm = try { carContext.getCarService(NavigationManager::class.java) } catch (e: Exception) { null }
            try {
                nm?.setNavigationManagerCallback(object : NavigationManagerCallback {
                    override fun onStopNavigation() {}
                    override fun onAutoDriveEnabled() {}
                })
                nm?.navigationStarted()
            } catch (e: Exception) { }
            // Oturum kapanınca navigasyon durumunu bitir ve yansıtmayı bırak
            lifecycle.addObserver(LifecycleEventObserver { _, ev ->
                if (ev == Lifecycle.Event.ON_DESTROY) {
                    try { nm?.navigationEnded() } catch (e: Exception) { }
                    Mirror.detachDisplay()
                    CarDisplay.release()
                }
            })
            // Varsayılan: uygulamanın tamamı araç ekranında (dokunmatik). Ayarlardan "Kutucuklar" seçilebilir.
            return if (App.int("car_ui", 0) == 0) CarUiScreen(carContext) else HomeScreen(carContext, true)
        }
    }
}

private fun icon(c: CarContext, res: Int) = CarIcon.Builder(IconCompat.createWithResource(c, res)).build()

/** Araç ekranındaki yüzeye telefonun ekranını çizer. */
class MirrorScreen(c: CarContext) : Screen(c) {
    init {
        try {
            carContext.getCarService(AppManager::class.java).setSurfaceCallback(object : SurfaceCallback {
                override fun onSurfaceAvailable(sc: SurfaceContainer) {
                    val s = sc.surface ?: return
                    Mirror.attach(s, sc.width, sc.height, sc.dpi)
                }
                override fun onSurfaceDestroyed(sc: SurfaceContainer) { Mirror.detachDisplay() }
            })
        } catch (e: Exception) { }
    }

    override fun onGetTemplate(): Template {
        val stop = Action.Builder().setIcon(icon(carContext, R.drawable.ic_pause)).setOnClickListener {
            Mirror.stop(); screenManager.pop()
        }.build()
        return NavigationTemplate.Builder()
            .setActionStrip(ActionStrip.Builder().addAction(Action.BACK).addAction(stop).build())
            .build()
    }
}

/** Lisans yokken araç ekranında gösterilen bilgi ekranı. */
class LicenseCarScreen(c: CarContext) : Screen(c) {
    override fun onGetTemplate(): Template = MessageTemplate.Builder(L.t("Telefonda CarTube uygulamasını açıp lisansınızı etkinleştirin."))
        .setTitle(L.t("Lisans gerekli")).setHeaderAction(Action.APP_ICON).build()
}
