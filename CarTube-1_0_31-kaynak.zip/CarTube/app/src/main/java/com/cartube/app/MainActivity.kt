package com.cartube.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player

/**
 * Ana ekran (v1.0.11): üstte oynatıcı kartı, ortada 2 sütunlu büyük kutucuklar,
 * altta kısayollar / favoriler / son içerikler, en altta sesli komut - düzenle - ayarlar çubuğu.
 */
class MainActivity : AppCompatActivity() {
    private class Tile(val title: String, val sub: String, val icon: Int, val action: () -> Unit)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val ts get() = App.float("ui_text", App.D_TEXT)
    private val screenDp get() = resources.displayMetrics.widthPixels / resources.displayMetrics.density
    private fun clamp(v: Float, lo: Float, hi: Float) = maxOf(lo, minOf(hi, v))

    private lateinit var tvTitle: TextView
    private lateinit var tvSub: TextView
    private lateinit var playBtn: ImageButton
    private val grey = Color.parseColor("#B8C4D0")
    private val hk get() = Theme.home()
    private var stamp = 0
    private var navField: EditText? = null
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) navField?.setText(t)
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = refresh()
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = refresh()
    }

    private fun go(c: Class<*>) = startActivity(Intent(this, c).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    private fun webOpen(url: String) = startActivity(Intent(this, YouTubeActivity::class.java).putExtra("url", url).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    /** YouTube Kids: yüklüyse resmi uygulamayı açar; değilse mağazayı (olmazsa web sürümünü) açar. */
    private fun openKids() {
        val pkg = "com.google.android.apps.youtube.kids"
        if (App.bool("kids_app", false)) {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) { try { startActivity(i); return } catch (e: Exception) { } }
            Toast.makeText(this, L.t("YouTube Kids yüklü değil, mağaza açılıyor"), Toast.LENGTH_LONG).show()
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))); return } catch (e: Exception) { }
        }
        webOpen("https://www.youtubekids.com/")
    }

    /** Navigasyon: Google Haritalar'ı açar ya da girilen adrese yol tarifini hemen başlatır. */
    private fun openNav() {
        Ui.menu(this, "Navigasyon", listOf("Google Haritalar'ı aç", "Adrese git (navigasyonu başlat)")) { i ->
            if (i == 0) launchMaps(null)
            else askDestination()
        }
    }

    /** Adres kutusu + mikrofon düğmesi: adres sesle söylenebilir. */
    private fun askDestination() {
        val l = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(12), 0) }
        val et = EditText(this).apply { hint = L.t("Adres veya yer adı"); setSingleLine() }
        navField = et
        val mic = ImageButton(this).apply {
            setImageResource(R.drawable.ic_mic); setBackgroundColor(Color.TRANSPARENT); setColorFilter(Theme.home())
            setOnClickListener { listenForAddress() }
        }
        l.addView(et, LinearLayout.LayoutParams(0, -2, 1f)); l.addView(mic, LinearLayout.LayoutParams(dp(48), dp(48)))
        AlertDialog.Builder(this).setTitle(L.t("Adrese git")).setView(l)
            .setPositiveButton(L.t("Git")) { _, _ -> val v = et.text.toString().trim(); if (v.isNotBlank()) launchMaps(v) }
            .setNegativeButton(L.t("İptal"), null).showCar()
    }

    private fun listenForAddress() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, L.t("Adresi söyleyin"))
        try { speech.launch(i) } catch (e: Exception) { Toast.makeText(this, L.t("Sesli giriş bulunamadı"), Toast.LENGTH_LONG).show() }
    }

    private fun launchMaps(dest: String?) {
        val pkg = "com.google.android.apps.maps"
        val i = if (dest == null) packageManager.getLaunchIntentForPackage(pkg)
            else Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest) + "&mode=d")).setPackage(pkg)
        try { if (i != null) { startActivity(i); return } } catch (e: Exception) { }
        Toast.makeText(this, L.t("Google Haritalar yüklü değil"), Toast.LENGTH_LONG).show()
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))) }
        catch (e: Exception) { webOpen("https://www.google.com/maps") }
    }

    private fun settingsPage(page: String?) {
        val i = Intent(this, SettingsActivity::class.java)
        if (page != null) i.putExtra("page", page)
        startActivity(i)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (!License.active()) { startActivity(Intent(this, LicenseActivity::class.java)); finish(); return }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.bg()) }
        root.addView(header())
        root.addView(miniPlayer())

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(16)) }

        // Ana kutucuklar (sıra ve görünürlük ayarlardan)
        val all = mapOf(
            "tv" to Tile("TV", "Canlı TV ve IPTV", R.drawable.ic_tv) { go(TvActivity::class.java) },
            "yt" to Tile("YouTube", "Video izle", R.drawable.ic_play) { go(YouTubeActivity::class.java) },
            "kids" to Tile("YouTube Kids", "Çocuklar için Eğlence", R.drawable.ic_kids) { openKids() },
            "nav" to Tile("Navigasyon", "Google Haritalar", R.drawable.ic_nav) { openNav() },
            "cast" to Tile("Ekran Yansıtma", "Telefon ekranını göster", R.drawable.ic_cast) {
                if (CarDisplay.isCar(this@MainActivity)) Toast.makeText(this@MainActivity, L.t("Ekran yansıtma telefondan başlatılır"), Toast.LENGTH_LONG).show() else go(MirrorActivity::class.java) },
            "radio" to Tile("Radyo", "İnternet Radyoları", R.drawable.ic_radio) { go(RadioActivity::class.java) },
            "media" to Tile("Medya", "Telefondaki video ve müzikler", R.drawable.ic_media) { go(MediaActivity::class.java) },
            "phone" to Tile("Telefon Uygulamaları", "Araç için seçtiğin uygulamalar", R.drawable.ic_phone) { go(PhoneAppsActivity::class.java) },
            "web" to Tile("Web", "Hızlı erişim ve tarayıcı", R.drawable.ic_globe) { go(WebHomeActivity::class.java) })
        val main = App.homeOrder().filter { App.bool("home_$it", true) }.mapNotNull { all[it] }
        addGrid(list, main, false)

        // Araçlar
        list.addView(sectionHeader("Araçlar") { })
        addGrid(list, listOf(
            Tile("Ekolayzır", "Ses ve bas", R.drawable.ic_eq) { App.openEq(this) },
            Tile("Ayarlar", "Uygulama ayarları", R.drawable.ic_settings) { settingsPage(null) }), true)

        scroll.addView(list)
        if (App.int("nav_pos", 0) == 1) root.addView(bottomBar())
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (App.int("nav_pos", 0) == 0) root.addView(bottomBar())
        setContentView(root)
        stamp = App.prefsStamp()
        // Geri tuşu: bir şey çalıyorsa uygulama arka plana alınır, çalmaya devam eder
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (CarDisplay.isCar(this@MainActivity)) return; if (App.nowPlaying() || App.webPlaying) moveTaskToBack(true) else finish() }
        })
        App.greet(this, false)

        // Android 13+: medya bildirimi ve yansıtma bildirimi için izin (bir kez sorulur)
        if (Build.VERSION.SDK_INT >= 33 && !App.bool("notif_asked", false) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            App.setBool("notif_asked", true)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 33)
        }
    }

    // ---------- Üst bölüm ----------

    private fun header(): View {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(32), dp(16), dp(4)) }
        row.addView(TextView(this).apply {
            text = "CarTube"; setTextColor(Color.WHITE); textSize = 26f; setTypeface(null, Typeface.BOLD); letterSpacing = 0.05f
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Switch(this).apply {
            text = L.t("Araçta aç"); setTextColor(grey); textSize = 12f; maxLines = 1; isChecked = App.carMode
            setOnCheckedChangeListener { _, c -> App.carMode = c }
        })
        return row
    }

    private fun skipBtn(icon: Int, dir: Int, size: Int) = ImageButton(this).apply {
        setBackgroundColor(Color.TRANSPARENT); setImageResource(icon); setColorFilter(grey)
        setOnClickListener { App.skip(dir, false) }
        setOnLongClickListener { App.skip(dir, true); true }
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }

    private fun miniPlayer(): View {
        val bs = App.float("bar_size", App.D_BAR)
        val fs = clamp(bs, 0.7f, 1.3f)
        val unit = minOf(52f * bs, (screenDp - 24f - 40f - 90f) / 3f).toInt().coerceAtLeast(36)
        val card = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = Theme.homeCard(); setPadding(dp(16), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(6), dp(12), dp(6)) }
        }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvTitle = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f * fs; setTypeface(null, Typeface.BOLD); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        tvSub = TextView(this).apply { setTextColor(grey); textSize = 13f * fs; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        tx.addView(tvTitle); tx.addView(tvSub)
        card.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(skipBtn(R.drawable.ic_prev, -1, unit))
        playBtn = ImageButton(this).apply {
            background = Theme.circle(Theme.mix(Theme.bg(), hk, 0.45f), Theme.dim(hk)); setImageResource(R.drawable.ic_play); setColorFilter(Color.WHITE)
            setOnClickListener { App.togglePlay() }
            setOnLongClickListener { if (App.bool("pp_stop", true)) { App.stopAll(); true } else false }
        }
        card.addView(playBtn, LinearLayout.LayoutParams(dp(unit), dp(unit)).apply { leftMargin = dp(4); rightMargin = dp(4) })
        card.addView(skipBtn(R.drawable.ic_next, 1, unit))
        return card
    }

    private fun circleBtn(icon: Int, onClick: () -> Unit) = ImageButton(this).apply {
        background = Theme.circle(Theme.mix(Theme.bg(), hk, 0.35f), hk); setImageResource(icon); setColorFilter(Color.WHITE)
        setOnClickListener { onClick() }
    }

    private fun bottomBar(): View {
        val ns = App.float("nav_size", App.D_NAV)
        val btn = minOf(52f * ns, (screenDp - 36f - 18f - 110f) / 3f)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(16), dp(20)); setBackgroundColor(Color.parseColor("#12171A")) }
        row.addView(TextView(this).apply { text = L.t("Ana ekran"); setTextColor(Color.WHITE); textSize = 20f * clamp(ns, 0.5f, 1.3f); setTypeface(null, Typeface.BOLD); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(0, -2, 1f))
        fun lp() = LinearLayout.LayoutParams(dp(btn.toInt()), dp(btn.toInt())).apply { leftMargin = dp(6) }
        row.addView(circleBtn(R.drawable.ic_mic) { go(VoiceActivity::class.java) }, lp())
        row.addView(circleBtn(R.drawable.ic_edit) { settingsPage("home") }, lp())
        row.addView(circleBtn(R.drawable.ic_settings) { settingsPage(null) }, lp())
        return row
    }

    // ---------- Kutucuk ızgarası ----------

    private fun addGrid(parent: LinearLayout, tiles: List<Tile>, compact: Boolean) {
        tiles.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, t ->
                row.addView(tileView(t, compact), LinearLayout.LayoutParams(0, -2, 1f).apply {
                    topMargin = dp(6); bottomMargin = dp(6); leftMargin = dp(if (i == 0) 0 else 6); rightMargin = dp(if (i == 0) 6 else 0) })
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            parent.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun tileView(t: Tile, compact: Boolean): View {
        val k = clamp(ts, 0.6f, 1.4f)
        val h = (if (compact) 110 else 170) * App.float("ui_card_h", App.D_PANEL)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            background = Theme.homeCard(); setPadding(dp(16), dp(12), dp(16), dp(12))
            minimumHeight = dp(h.toInt()); setOnClickListener { t.action() }
        }
        val ic = (46 * k).toInt()
        col.addView(ImageView(this).apply {
            setImageResource(t.icon); setColorFilter(hk); setPadding(dp(ic / 4), dp(ic / 4), dp(ic / 4), dp(ic / 4))
            background = Theme.circle(Color.parseColor("#12171A"), Theme.dim(hk))
        }, LinearLayout.LayoutParams(dp(ic), dp(ic)))
        col.addView(TextView(this).apply {
            text = L.t(t.title); setTextColor(Color.WHITE); textSize = maxOf(15f, 28f * ts); setTypeface(null, Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(8), 0, 0) })
        col.addView(TextView(this).apply {
            text = L.t(t.sub); setTextColor(grey); textSize = maxOf(11f, 15f * ts); maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        return col
    }

    private fun sectionHeader(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = L.t(t); setTextColor(hk); textSize = maxOf(14f, 20f * ts); setTypeface(null, Typeface.BOLD)
        setPadding(dp(8), dp(20), dp(8), dp(6)); setOnClickListener { onClick() }
    }

    private fun refresh() {
        val t = App.nowTitle()
        tvTitle.text = t ?: L.t("Oynatılan içerik yok")
        tvSub.text = if (t == null) L.t("Kontrol etmek için bir içerik başlat") else if (App.nowPlaying()) L.t("Oynatılıyor") else L.t("Duraklatıldı")
        playBtn.setImageResource(if (App.nowPlaying()) R.drawable.ic_pause else R.drawable.ic_play)
    }

    override fun onStart() { super.onStart(); if (!::tvTitle.isInitialized) return; App.player.addListener(listener); App.onState = { runOnUiThread { refresh() } }; refresh() }
    override fun onStop() { super.onStop(); App.player.removeListener(listener); App.onState = null }

    /** Ayarlar ya da listeler değiştiyse ekranı yeniler; aksi halde titremeyi önlemek için dokunmaz. */
    override fun onRestart() { super.onRestart(); if (App.prefsStamp() != stamp) recreate() }
}
