package com.cartube.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/** Çalan ses/video uygulama arka plana alınınca kesilmesin diye ön plan servisi. Hiçbir şey çalmazsa kendiliğinden kapanır. */
class KeepAliveService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var idle = 0
    private var wl: PowerManager.WakeLock? = null
    private val watch = object : Runnable {
        override fun run() {
            val playing = App.nowPlaying() || App.webPlaying
            idle = if (playing) 0 else idle + 1
            if (idle >= 12) { stopSelf(); return }           // 60 sn boyunca hiçbir şey çalmazsa kapanır
            if (playing) { getSystemService(NotificationManager::class.java).notify(NID, notif()); grabWake() }
            h.postDelayed(this, 5000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { App.stopAll(); App.webStop?.invoke(); stopSelf(); return START_NOT_STICKY }
        val n = notif()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(NID, n)
        grabWake()
        idle = 0; h.removeCallbacks(watch); h.postDelayed(watch, 5000)
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, L.t("Arka planda oynatma"), NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1, Intent(this, KeepAliveService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val title = App.nowTitle()?.takeIf { App.nowPlaying() } ?: if (App.webPlaying) L.t("Web videosu") else "CarTube-Pro"
        return NotificationCompat.Builder(this, CH).setSmallIcon(R.drawable.ic_play).setContentTitle(title)
            .setContentText(L.t("Arka planda çalıyor")).setContentIntent(open).addAction(0, L.t("Durdur"), stop)
            .setOngoing(true).setSilent(true).build()
    }

    /** Ekran kapalıyken işlemci uyumasın diye (arka planda oynatma) kısmi uyanık tutma kilidi. */
    private fun grabWake() {
        try {
            if (wl == null) wl = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cartube:keepalive").apply { setReferenceCounted(false) }
            wl?.acquire(60 * 60 * 1000L)
        } catch (e: Exception) { }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null); App.keepAlive = false
        try { wl?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        wl = null
        super.onDestroy()
    }

    companion object { private const val CH = "keepalive"; private const val NID = 77 }
}
