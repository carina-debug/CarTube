package com.cartube.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

/** Medya listesi. Tarayıcı: 0 Varsayılan (müzik+video), 1 Sistem (dosya seçici). */
class MediaActivity : AppCompatActivity() {
    private class M(val title: String, val uri: String, val video: Boolean)
    private val items = mutableListOf<M>()
    private val shown = mutableListOf<M>()
    private var tab = 0   // 0 Ses, 1 Video
    private lateinit var videoBox: View
    private lateinit var tabAudio: TextView
    private lateinit var tabVideo: TextView
    private lateinit var lv: ListView
    private var cur: String? = null
    private val mode get() = if (App.int("scanner", 0) == 1) 1 else 0
    private val perms get() = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val saved = App.str("sys_media").lines().filter { it.isNotBlank() }.toMutableList()
        uris.forEach { u ->
            try { contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
            val name = u.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: u.toString()
            saved.add(name.replace("|", "/") + "|" + u)
        }
        App.setStr("sys_media", saved.distinct().joinToString("\n"))
        load()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (s == null && !App.nowPlaying()) App.resetPlayer()   // çalan yoksa son içerik ekranda kalmasın
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        tab = App.int("media_tab", 0)
        videoBox = VideoUi.create(this)
        root.addView(videoBox, LinearLayout.LayoutParams(-1, 0, 1f))
        tabAudio = tabButton(0); tabVideo = tabButton(1)
        val tabs = LinearLayout(this).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
        tabs.addView(tabAudio, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(6) })
        tabs.addView(tabVideo, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        root.addView(tabs, LinearLayout.LayoutParams(-1, -2))
        styleTabs()
        lv = ListView(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        if (mode == 1) root.addView(Ui.navBar(this, null, R.drawable.ic_add) { picker.launch(arrayOf("audio/*", "video/*")) })
        else root.addView(Ui.navBar(this, L.t("Medya")))
        setContentView(root)
        if (mode == 1 || perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) load() else requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) load()
        else Toast.makeText(this, L.t("Medya izni verilmedi"), Toast.LENGTH_LONG).show()
    }

    private fun load() = thread {
        val out = mutableListOf<M>()
        fun scan(base: Uri, video: Boolean, extra: String? = null) {
            contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.TITLE), extra, null,
                MediaStore.MediaColumns.TITLE + " COLLATE NOCASE ASC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n++ < 800)
                    out += M(c.getString(1) ?: "?", ContentUris.withAppendedId(base, c.getLong(0)).toString(), video)
            }
        }
        try {
            when (mode) {
                1 -> App.str("sys_media").lines().filter { it.contains("|") }.forEach {
                    val p = it.split("|", limit = 2)
                    out += M(p[0], p[1], !(p[1].contains("audio") || p[0].lowercase().matches(Regex(".*\\.(mp3|flac|ogg|opus|m4a|wav|aac)"))))
                }
                else -> {
                    scan(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, false)
                    scan(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
                }
            }
        } catch (e: Exception) { }
        runOnUiThread { items.clear(); items.addAll(out); styleTabs(); render() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tabButton(idx: Int) = TextView(this).apply {
        gravity = Gravity.CENTER; textSize = 15f; setTypeface(null, Typeface.BOLD)
        setOnClickListener { selectTab(idx) }
    }

    private fun styleTabs() {
        val a = Theme.set()
        val light = 0.299 * Color.red(a) + 0.587 * Color.green(a) + 0.114 * Color.blue(a) > 150
        val onC = if (light) Color.parseColor("#0E1214") else Color.WHITE
        val na = items.count { !it.video }; val nv = items.count { it.video }
        listOf(tabAudio to ("Ses" to na), tabVideo to ("Video" to nv)).forEachIndexed { i, (t, p) ->
            val on = tab == i
            t.text = L.t(p.first) + " (" + p.second + ")"
            t.setTextColor(if (on) onC else Color.WHITE)
            t.background = Theme.roundRect(if (on) a else Theme.setCard(), 22)
        }
    }

    private fun selectTab(i: Int) {
        tab = i; App.setInt("media_tab", i)
        styleTabs(); render()
    }

    /** Seçili sekmeye (Ses / Video) göre listeyi çizer. */
    private fun render() {
        val watched = App.watched()
        val icons = App.bool("track_icons", true)
        shown.clear(); shown.addAll(items.filter { it.video == (tab == 1) })
        val names = if (shown.isEmpty()) listOf(L.t(when { mode == 1 -> "Dosya eklemek için alttaki + düğmesine dokun"; tab == 1 -> "Video bulunamadı"; else -> "Ses dosyası bulunamadı" }))
        else shown.map { (if (it.uri in watched) "✓ " else "") + (if (icons) (if (it.video) "▶ " else "♪ ") else "") + it.title }
        lv.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            override fun getView(p: Int, v: View?, g: android.view.ViewGroup): View =
                super.getView(p, v, g).also { (it as TextView).setTextColor(Color.WHITE) }
        }
        lv.setOnItemClickListener { _, _, i, _ -> shown.getOrNull(i)?.let { cur = it.uri; App.play(it.title, it.uri, it.video) } }
    }

    override fun onStop() {
        super.onStop()
        val u = cur ?: return
        val p = App.player
        if (App.cur == 1 && p.duration > 0 && p.currentPosition * 100.0 / p.duration >= App.float("watch_pct", 95f)) App.addWatched(u)
    }

    override fun onDestroy() { Sys.onSize = null; VideoUi.release(); if (isFinishing && !App.nowPlaying()) App.resetPlayer(); super.onDestroy() }
}
