package com.cartube.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.cos
import kotlin.math.sin

/** Radyo simgesi: çalarken çevresinde hareketli ses çubukları görünür. Dokunmayla oynat/duraklat. */
class RadioOrb(c: Context) : View(c) {
    private var playing = false
    private var busy = false
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val icon = ContextCompat.getDrawable(c, R.drawable.ic_radio)!!.mutate()

    fun set(playing: Boolean, busy: Boolean) { this.playing = playing; this.busy = busy; invalidate() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val cx = w / 2f; val cy = height / 2f; val r = w * 0.30f
        val acc = Theme.home()
        fill.color = Color.parseColor("#12171A"); cv.drawCircle(cx, cy, r, fill)
        ring.color = if (playing) acc else Theme.dim(acc); ring.strokeWidth = w * 0.014f; cv.drawCircle(cx, cy, r, ring)
        val t = SystemClock.uptimeMillis().toDouble()
        bar.strokeWidth = w * 0.014f
        bar.color = if (playing) Theme.mix(acc, Color.WHITE, 0.35f) else Theme.dim(acc)
        val n = 64
        val r1 = r + w * 0.04f
        for (i in 0 until n) {
            val a = Math.PI * 2 * i / n
            val amp = when {
                playing -> 0.30 + 0.70 * ((sin(t * 0.006 + i * 0.7) + sin(t * 0.0093 + i * 1.9) + 2.0) / 4.0)
                busy -> 0.12 + 0.10 * (sin(t * 0.004 + i * 0.4) + 1.0)
                else -> 0.10
            }
            val r2 = r1 + w * 0.12f * amp.toFloat()
            cv.drawLine(cx + (cos(a) * r1).toFloat(), cy + (sin(a) * r1).toFloat(), cx + (cos(a) * r2).toFloat(), cy + (sin(a) * r2).toFloat(), bar)
        }
        val s = (w * 0.15f).toInt()
        icon.setBounds((cx - s).toInt(), (cy - s).toInt(), (cx + s).toInt(), (cy + s).toInt())
        icon.setTint(if (playing) acc else Color.parseColor("#8A9399"))
        icon.draw(cv)
        if (playing || busy) postInvalidateOnAnimation()
    }
}
