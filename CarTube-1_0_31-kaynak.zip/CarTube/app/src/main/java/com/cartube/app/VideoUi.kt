package com.cartube.app

import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.widget.FrameLayout
import android.widget.TextClock
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import android.view.View
import android.view.SurfaceHolder
import android.view.SurfaceView

object VideoUi {
    private var exo: PlayerView? = null
    private var sysFit: (() -> Unit)? = null
    private var boxRef: FrameLayout? = null

    /** Ayardaki ekran boyutu: 0 = Sığdır, 1 = Doldur (uzat), 2 = Tam ekran (kırp). */
    private fun exoMode() = when (App.int("video_resize", 0)) {
        1, 3, 4 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        2 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT }

    /** 3 = 4:3, 4 = 16:9: görüntü seçilen orana zorlanır (esnetilir). Diğer ayarlarda 0. */
    private fun forcedRatio(): Float = when (App.int("video_resize", 0)) { 3 -> 4f / 3f; 4 -> 16f / 9f; else -> 0f }

    private fun forcedLp(cw: Int, ch: Int): FrameLayout.LayoutParams {
        val r = forcedRatio()
        if (r <= 0f) return FrameLayout.LayoutParams(-1, -1)
        var w = cw; var h = (cw / r).toInt()
        if (h > ch) { h = ch; w = (ch * r).toInt() }
        return FrameLayout.LayoutParams(w, h, Gravity.CENTER)
    }

    /** ExoPlayer görünümünü (gerekirse) seçilen orandaki alana yerleştirir. */
    private fun fitExo() {
        val v = exo ?: return; val b = boxRef ?: return
        if (b.width <= 0 || b.height <= 0) return
        val lp = forcedLp(b.width, b.height)
        val cur = v.layoutParams
        if (cur != null && cur.width == lp.width && cur.height == lp.height) return
        v.layoutParams = lp
    }

    /** Ekran boyutu ayarı değişince çalan videoya anında uygular (ExoPlayer, MediaPlayer). */
    fun applyResize() {
        exo?.resizeMode = exoMode()
        fitExo()
        sysFit?.invoke()
    }

    /** ExoPlayer kullanılıyorsa oynatıcı görünümü; dışarıdan denetim çubuğunu senkronlamak için. */
    fun exoView(): PlayerView? = exo

    /** Ekran kapanırken eski görünüm referanslarını bırakır. */
    fun release() { try { exo?.player = null } catch (e: Exception) { }; exo = null; sysFit = null; boxRef = null }

    fun create(a: AppCompatActivity): FrameLayout {
        exo = null; sysFit = null; boxRef = null
        val dp = a.resources.displayMetrics.density
        val useSys = App.int("eng_v2", 1) == 0
        val pv: View = when {
            useSys -> SurfaceView(a)
            else -> PlayerView(a).apply {
                player = App.player
                resizeMode = exoMode()
                controllerShowTimeoutMs = if (App.bool("v_autohide", true)) 3000 else 0
            }.also { exo = it }
        }
        val ctl = WindowCompat.getInsetsController(a.window, a.window.decorView)
        ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl.hide(WindowInsetsCompat.Type.systemBars())
        var barsShown = false
        lateinit var box: FrameLayout
        val gd = GestureDetector(a, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (App.bool("v_tap", false)) App.togglePlay()
                if (App.bool("v_bars", false)) {
                    barsShown = !barsShown
                    if (barsShown) ctl.show(WindowInsetsCompat.Type.systemBars()) else ctl.hide(WindowInsetsCompat.Type.systemBars())
                }
                return false
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (!App.bool("v_bright", false)) return false
                val lp = a.window.attributes
                val cur = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
                lp.screenBrightness = (cur + dy / box.height.coerceAtLeast(1)).coerceIn(0.02f, 1f)
                a.window.attributes = lp
                return true
            }
        })
        box = object : FrameLayout(a) {
            override fun onInterceptTouchEvent(ev: MotionEvent): Boolean { gd.onTouchEvent(ev); return false }
        }
        boxRef = box
        if (useSys) {
            val sv = pv as SurfaceView
            box.addView(sv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            fun fit() {
                val vw = Sys.vw; val vh = Sys.vh; val cw = box.width; val ch = box.height
                if (vw <= 0 || vh <= 0 || cw <= 0 || ch <= 0) return
                val lp = when (App.int("video_resize", 0)) {
                    1 -> FrameLayout.LayoutParams(-1, -1)
                    3, 4 -> forcedLp(cw, ch)
                    2 -> { val k = maxOf(cw / vw.toFloat(), ch / vh.toFloat()); FrameLayout.LayoutParams((vw * k).toInt(), (vh * k).toInt(), Gravity.CENTER) }
                    else -> { val k = minOf(cw / vw.toFloat(), ch / vh.toFloat()); FrameLayout.LayoutParams((vw * k).toInt(), (vh * k).toInt(), Gravity.CENTER) }
                }
                sv.layoutParams = lp
            }
            sv.holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(h: SurfaceHolder) { Sys.setDisplay(h) }
                override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
                override fun surfaceDestroyed(h: SurfaceHolder) { Sys.setDisplay(null) }
            })
            Sys.onSize = { a.runOnUiThread { fit() } }
            sysFit = { fit() }
            box.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fit() }
        } else {
            box.addView(pv, FrameLayout.LayoutParams(-1, -1))
            box.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitExo() }
        }
        val cp = App.int("clock_pos", 2)
        if (cp != 2) box.addView(TextClock(a).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"; setTextColor(Color.WHITE); textSize = 16f
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
        }, FrameLayout.LayoutParams(-2, -2, (if (cp == 0) Gravity.END else Gravity.START) or Gravity.TOP)
            .apply { setMargins((16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt(), 0) })
        if (App.bool("v_land", false)) a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        return box
    }
}
