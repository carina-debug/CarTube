package com.cartube.app.car

import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.AppManager
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.cartube.app.*

/**
 * Araç ekranında CarTube'un tamamı: ana ekran kutucukları, TV, radyo, YouTube… telefondaki gibi, dokunarak.
 * Görüntü, araç yüzeyine bağlı sanal ekrandan gelir (bkz. CarDisplay). Üst şeritte Ana sayfa / Geri / Kutucuklar,
 * harita şeridinde ▲ ▼ kaydırma düğmeleri bulunur.
 */
class CarUiScreen(c: CarContext) : Screen(c) {
    private var fellBack = false

    private fun icon(res: Int) = CarIcon.Builder(IconCompat.createWithResource(carContext, res)).build()

    private val cb = object : SurfaceCallback {
        override fun onSurfaceAvailable(sc: SurfaceContainer) {
            val s = sc.surface ?: return
            CarDisplay.attach(carContext, s, sc.width, sc.height, sc.dpi)
            if (!CarDisplay.hasActivity()) CarDisplay.launch(carContext, MainActivity::class.java)
            checkLaunched()
        }
        override fun onSurfaceDestroyed(sc: SurfaceContainer) { CarDisplay.detachSurface() }
        override fun onStableAreaChanged(stableArea: Rect) { CarDisplay.setStable(stableArea) }
        override fun onClick(x: Float, y: Float) { CarDisplay.tap(x, y) }
        override fun onScroll(distanceX: Float, distanceY: Float) { CarDisplay.scroll(distanceY) }
        override fun onFling(velocityX: Float, velocityY: Float) { CarDisplay.fling(velocityY) }
    }

    private fun register() {
        try { carContext.getCarService(AppManager::class.java).setSurfaceCallback(cb) } catch (e: Exception) { }
    }

    init {
        register()
        // Başka bir ekran (ör. Ekran Yansıtma) üstten kapanıp bu ekrana dönülünce yüzey geri çağrısını yeniden bağla
        lifecycle.addObserver(LifecycleEventObserver { _, ev -> if (ev == Lifecycle.Event.ON_START) register() })
    }

    /** Birkaç saniye içinde araç ekranında etkinlik açılmazsa eski kutucuk ekranına geç. */
    private fun checkLaunched() {
        Handler(Looper.getMainLooper()).postDelayed({
            if (fellBack || CarDisplay.hasActivity()) return@postDelayed
            fellBack = true
            try {
                CarToast.makeText(carContext, L.t("Araç ekranında açılamadı, kutucuk ekranı gösteriliyor"), CarToast.LENGTH_LONG).show()
                if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) screenManager.push(HomeScreen(carContext, true))
            } catch (e: Exception) { }
        }, 4500)
    }

    override fun onGetTemplate(): Template {
        val home = Action.Builder().setIcon(icon(R.drawable.ic_home)).setOnClickListener { CarDisplay.home(carContext) }.build()
        val back = Action.Builder().setIcon(icon(R.drawable.ic_back)).setOnClickListener { CarDisplay.back() }.build()
        val grid = Action.Builder().setIcon(icon(R.drawable.ic_grid)).setOnClickListener { screenManager.push(HomeScreen(carContext, true)) }.build()
        val up = Action.Builder().setIcon(icon(R.drawable.ic_up)).setOnClickListener { CarDisplay.page(-1) }.build()
        val down = Action.Builder().setIcon(icon(R.drawable.ic_down)).setOnClickListener { CarDisplay.page(1) }.build()
        return NavigationTemplate.Builder()
            .setActionStrip(ActionStrip.Builder().addAction(home).addAction(back).addAction(grid).build())
            .setMapActionStrip(ActionStrip.Builder().addAction(up).addAction(down).build())
            .build()
    }
}
