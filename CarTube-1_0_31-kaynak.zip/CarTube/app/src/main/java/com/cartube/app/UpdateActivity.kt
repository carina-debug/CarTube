package com.cartube.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Güncelleme ekranı: yeni sürümü GitHub Releases üzerinden denetler, indirir ve mevcut uygulamanın üzerine kurar. */
class UpdateActivity : AppCompatActivity() {
    private val gold get() = Theme.set()
    private val grey = Color.parseColor("#B8C4D0")
    private val card get() = Theme.setCard()
    private lateinit var tvLatest: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvNotes: TextView
    private lateinit var notesBox: LinearLayout
    private lateinit var tvPct: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnCheck: Button
    private lateinit var btnInstall: Button
    private var pendingUrl: String? = null
    private var pendingFile: File? = null
    private var installedName = "0"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun onAccent(): Int { val a = Theme.set(); return if (0.299 * Color.red(a) + 0.587 * Color.green(a) + 0.114 * Color.blue(a) > 150) Color.parseColor("#0E1214") else Color.WHITE }

    private fun button(text: String, fill: Boolean, onClick: () -> Unit) = Button(this).apply {
        this.text = L.t(text); isAllCaps = false; textSize = 16f; setTypeface(null, Typeface.BOLD)
        setTextColor(if (fill) onAccent() else gold)
        background = Theme.roundRect(if (fill) gold else card, 18)
        setOnClickListener { onClick() }
    }
    private fun lp(top: Int = 10) = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(top) }

    private fun row(label: String, value: String): Pair<LinearLayout, TextView> {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(9), 0, dp(9)) }
        r.addView(TextView(this).apply { text = L.t(label); setTextColor(grey); textSize = 14f }, LinearLayout.LayoutParams(0, -2, 1f))
        val v = TextView(this).apply { text = value; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.END; setTypeface(Typeface.DEFAULT, Typeface.BOLD) }
        r.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        return Pair(r, v)
    }

    private fun say(t: String, ok: Boolean?) {
        tvStatus.text = L.t(t)
        tvStatus.setTextColor(when (ok) { true -> Color.parseColor("#7BD88F"); false -> Color.parseColor("#FF7A7A"); null -> grey })
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pi = packageManager.getPackageInfo(packageName, 0)
        installedName = pi.versionName ?: "0"
        val code = PackageInfoCompat.getLongVersionCode(pi)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(48), dp(24), dp(32)) }
        col.addView(TextView(this).apply { text = L.t("Güncelleme"); setTextColor(Color.WHITE); textSize = 28f; setTypeface(null, Typeface.BOLD) })

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = Theme.roundRect(card, 20); setPadding(dp(18), dp(8), dp(18), dp(8)) }
        box.addView(row("Yüklü sürüm", "$installedName ($code)").first)
        val (r2, v2) = row("Son sürüm", "—"); tvLatest = v2; box.addView(r2)
        col.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        tvStatus = TextView(this).apply { textSize = 15f; setPadding(0, dp(14), 0, 0) }
        col.addView(tvStatus)
        // Yeni sürüm varsa "Yenilikler" kutusu: sürüm açıklamasındaki satırlar kısa maddeler olarak listelenir
        notesBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = Theme.roundRect(card, 20); setPadding(dp(18), dp(14), dp(18), dp(14)); visibility = View.GONE }
        notesBox.addView(TextView(this).apply { text = L.t("Yenilikler"); setTextColor(gold); textSize = 16f; setTypeface(null, Typeface.BOLD) })
        tvNotes = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; setLineSpacing(0f, 1.15f); setPadding(0, dp(8), 0, 0) }
        notesBox.addView(tvNotes)
        col.addView(notesBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        btnCheck = button("Güncellemeleri denetle", true) { check() }
        col.addView(btnCheck, lp(18))
        btnInstall = button("İndir ve yükle", false) { pendingUrl?.let { download(it) } }
        btnInstall.visibility = View.GONE
        col.addView(btnInstall, lp(8))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        col.addView(progress, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        tvPct = TextView(this).apply { setTextColor(grey); textSize = 13f; gravity = Gravity.CENTER }
        col.addView(tvPct)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        root.addView(ScrollView(this).apply { setBackgroundColor(Theme.setBg()); addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Ui.navBar(this, L.t("Güncelleme")))
        setContentView(root)
        check()
    }

    private fun newer(a: String, b: String): Boolean {
        val x = Regex("\\d+").findAll(a).map { it.value.toInt() }.toList()
        val y = Regex("\\d+").findAll(b).map { it.value.toInt() }.toList()
        for (i in 0 until maxOf(x.size, y.size)) {
            val p = x.getOrElse(i) { 0 }; val q = y.getOrElse(i) { 0 }
            if (p != q) return p > q
        }
        return false
    }

    /** Sürüm açıklamasını (markdown olabilir) kısa maddelere çevirir. */
    private fun bullets(md: String): String {
        val skip = setOf("yenilikler", "neler yeni", "what's new", "whats new", "changelog", "değişiklikler")
        return md.lines().map { l ->
            l.trim().replace(Regex("^#+\\s*"), "").replace(Regex("^[-*+•]\\s+"), "").replace(Regex("^\\d+[.)]\\s+"), "")
                .replace("**", "").replace("__", "").replace("`", "").trim().trimEnd(':')
        }.filter { it.isNotBlank() && !it.startsWith("---") && !it.lowercase().startsWith("full changelog") && it.lowercase() !in skip }
            .take(12).joinToString("\n") { "• " + (if (it.length > 90) it.take(88) + "…" else it) }
    }

    private fun check() {
        val repo = getString(R.string.update_repo).trim()
        if (!repo.contains("/") || repo.startsWith("SAHIP")) { say("Güncelleme deposu ayarlanmamış", false); return }
        btnCheck.isEnabled = false; say("Denetleniyor…", null)
        thread {
            var err: String? = null; var tag = ""; var notes = ""; var apk = ""; var size = 0L
            try {
                val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                c.setRequestProperty("Accept", "application/vnd.github+json"); c.setRequestProperty("User-Agent", "CarTube-Pro")
                if (c.responseCode == 404) err = "Henüz yayınlanmış bir sürüm yok" else {
                    val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                    tag = j.optString("tag_name"); notes = j.optString("body")
                    val a = j.optJSONArray("assets")
                    if (a != null) for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        if (o.optString("name").endsWith(".apk", true)) { apk = o.optString("browser_download_url"); size = o.optLong("size"); break }
                    }
                    if (apk.isEmpty()) err = "Sürümde APK dosyası bulunamadı"
                }
            } catch (e: Exception) { err = "Denetlenemedi, internet bağlantınızı kontrol edin" }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                btnCheck.isEnabled = true
                val e = err
                if (e != null) { say(e, false); return@runOnUiThread }
                tvLatest.text = tag.removePrefix("v")
                notesBox.visibility = View.GONE
                if (newer(tag, installedName)) {
                    val b = bullets(notes)
                    if (b.isNotBlank()) { tvNotes.text = b; notesBox.visibility = View.VISIBLE }
                    say("Yeni sürüm var", true); pendingUrl = apk
                    btnInstall.text = L.t("İndir ve yükle") + if (size > 0) " (" + (size / 1_048_576) + " MB)" else ""
                    btnInstall.visibility = View.VISIBLE
                } else { say("Uygulamanız güncel", true); btnInstall.visibility = View.GONE }
            }
        }
    }

    private fun download(url: String) {
        btnInstall.isEnabled = false; progress.visibility = View.VISIBLE; progress.progress = 0; tvPct.text = ""
        say("İndiriliyor…", null)
        thread {
            var out: File? = null; var err: String? = null
            try {
                val dir = File(getExternalFilesDir(null) ?: filesDir, "update").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val f = File(dir, "CarTube-Pro.apk")
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000; c.setRequestProperty("User-Agent", "CarTube-Pro")
                val total = c.contentLengthLong
                c.inputStream.use { ins ->
                    f.outputStream().use { os ->
                        val buf = ByteArray(64 * 1024); var done = 0L; var last = 0L
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            os.write(buf, 0, n); done += n
                            val now = System.currentTimeMillis()
                            if (now - last > 250) {
                                last = now
                                val p = if (total > 0) (done * 100 / total).toInt() else 0
                                runOnUiThread { progress.progress = p; tvPct.text = "%$p" }
                            }
                        }
                    }
                }
                out = f
            } catch (e: Exception) { err = "İndirme başarısız" }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                btnInstall.isEnabled = true
                val f = out
                if (f != null) { progress.progress = 100; tvPct.text = "%100"; say("İndirildi, yükleme ekranı açılıyor…", true); install(f) }
                else say(err ?: "İndirme başarısız", false)
            }
        }
    }

    private fun install(f: File) {
        if (!packageManager.canRequestPackageInstalls()) {
            pendingFile = f
            Toast.makeText(this, L.t("Açılan ekranda CarTube-Pro için izin verin, sonra geri dönün"), Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onResume() {
        super.onResume()
        val f = pendingFile
        if (f != null && packageManager.canRequestPackageInstalls()) { pendingFile = null; install(f) }
    }
}
