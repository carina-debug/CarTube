package com.cartube.app

import android.app.Activity
import android.app.ActivityOptions
import android.app.Dialog
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.ScrollView

/**
 * Araç ekranında (Android Auto) uygulamanın kendisini gösterir.
 * Araç yüzeyine (Surface) bağlı özel bir sanal ekran oluşturulur; CarTube etkinlikleri bu ekranda açılır.
 * Araç ekranına dokunuşlar (onClick) aynı süreçte etkinliğe/diyaloga doğrudan iletilir; özel izin gerekmez.
 */
object CarDisplay {
    private var vd: VirtualDisplay? = null
    private val acts = ArrayList<Activity>()
    private val dialogs = ArrayList<Dialog>()
    private val ui = Handler(Looper.getMainLooper())
    private var resumed: Activity? = null
    private var inset = Rect()
    private var width = 0
    private var height = 0
    private var lastX = 0f
    private var lastY = 0f
    private var downTarget: Any? = null

    val active get() = vd != null
    fun hasActivity() = acts.any { !it.isFinishing }

    private fun scale() = when (App.int("car_ui_scale", 1)) { 0 -> 0.8f; 2 -> 1.25f; 3 -> 1.5f; else -> 1f }

    fun displayId(): Int = try { vd?.display?.displayId ?: -1 } catch (e: Exception) { -1 }

    @Suppress("DEPRECATION")
    private fun actDisplay(a: Activity): Int = try { a.windowManager.defaultDisplay.displayId } catch (e: Exception) { 0 }

    fun isCar(a: Activity): Boolean { val id = displayId(); return id > 0 && actDisplay(a) == id }

    // ---------- Yüzey / sanal ekran ----------

    fun attach(c: Context, surface: Surface, w: Int, h: Int, dpi: Int) {
        width = w; height = h
        val d = (dpi * scale()).toInt().coerceIn(80, 640)
        try {
            val cur = vd
            if (cur == null) {
                val dm = c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                vd = dm.createVirtualDisplay("CarTubeUI", w, h, d, surface,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION)
            } else {
                cur.resize(w, h, d)
                cur.surface = surface
            }
        } catch (e: Exception) { }
    }

    /** Yüzey kaybolunca sanal ekran ve açık etkinlikler yaşamaya devam eder (ses/video kesilmez). */
    fun detachSurface() { try { vd?.surface = null } catch (e: Exception) { } }

    /** Araç oturumu bitince: araç ekranındaki etkinlikleri kapat, sanal ekranı bırak. */
    fun release() {
        dialogs.toList().forEach { try { it.dismiss() } catch (e: Exception) { } }
        dialogs.clear()
        acts.toList().forEach { try { it.finish() } catch (e: Exception) { } }
        acts.clear(); resumed = null
        try { vd?.release() } catch (e: Exception) { }
        vd = null
    }

    fun setStable(r: Rect) {
        if (r.isEmpty || width <= 0) return
        inset = Rect(r.left.coerceAtLeast(0), r.top.coerceAtLeast(0),
            (width - r.right).coerceAtLeast(0), (height - r.bottom).coerceAtLeast(0))
        top()?.let { applyInsets(it) }
    }

    private fun applyInsets(a: Activity) {
        try { a.findViewById<View>(android.R.id.content)?.setPadding(inset.left, inset.top, inset.right, inset.bottom) } catch (e: Exception) { }
    }

    // ---------- Etkinlik izleme (App içindeki yaşam döngüsü kancalarından) ----------

    fun onCreated(a: Activity) { if (isCar(a) && !acts.contains(a)) acts.add(a) }
    fun onResumed(a: Activity) { if (acts.contains(a)) { resumed = a; applyInsets(a) } }
    fun onDestroyed(a: Activity) { acts.remove(a); if (resumed === a) resumed = null }

    private fun top(): Activity? = resumed?.takeIf { !it.isFinishing } ?: acts.lastOrNull { !it.isFinishing }

    /** Araç ekranında açılan diyaloglar (menü, onay…) dokunuşları alabilsin diye izlenir. */
    fun track(d: Dialog) {
        var c: Context? = d.context
        while (c is ContextWrapper && c !is Activity) c = c.baseContext
        if (c is Activity && acts.contains(c)) {
            dialogs.add(d)
            d.setOnDismissListener { dialogs.remove(d) }
        }
    }
    private fun topDialog() = dialogs.lastOrNull { it.isShowing }

    // ---------- Açma / gezinme ----------

    fun launch(c: Context, cls: Class<*>) {
        val id = displayId(); if (id <= 0) return
        try {
            val o = ActivityOptions.makeBasic().setLaunchDisplayId(id)
            c.startActivity(Intent(c, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK), o.toBundle())
        } catch (e: Exception) { }
    }

    fun home(c: Context) {
        val keep = acts.firstOrNull { it is MainActivity && !it.isFinishing }
        dialogs.toList().forEach { try { it.dismiss() } catch (e: Exception) { } }
        acts.toList().filter { it !== keep }.forEach { try { it.finish() } catch (e: Exception) { } }
        if (keep == null) launch(c, MainActivity::class.java)
    }

    fun back() {
        topDialog()?.let { it.dismiss(); return }
        val t = top() ?: return
        if (t is MainActivity && acts.count { !it.isFinishing } <= 1) return
        try {
            if (t is androidx.activity.ComponentActivity) t.onBackPressedDispatcher.onBackPressed() else t.finish()
        } catch (e: Exception) { }
    }

    // ---------- Dokunma ----------

    private fun ev(t0: Long, t: Long, action: Int, x: Float, y: Float): MotionEvent =
        MotionEvent.obtain(t0, t, action, x, y, 0).also { it.source = InputDevice.SOURCE_TOUCHSCREEN }

    fun tap(x: Float, y: Float) {
        lastX = x; lastY = y
        val t = SystemClock.uptimeMillis()
        send(ev(t, t, MotionEvent.ACTION_DOWN, x, y), true)
        ui.postDelayed({ send(ev(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x, y), false) }, 70)
    }

    private fun send(e: MotionEvent, down: Boolean) {
        try {
            if (down) downTarget = topDialog() ?: top()
            val tg = downTarget
            if (tg is Dialog) {
                val loc = IntArray(2)
                tg.window?.decorView?.getLocationOnScreen(loc)
                e.offsetLocation(-loc[0].toFloat(), -loc[1].toFloat())
                tg.dispatchTouchEvent(e)
            } else if (tg is Activity) tg.dispatchTouchEvent(e)
        } catch (ex: Exception) {
        } finally { e.recycle() }
    }

    // ---------- Kaydırma (▲ ▼ düğmeleri ve ana bilgisayar kaydırma/fırlatma olayları) ----------

    private fun collect(v: View, out: MutableList<View>) {
        if (v.visibility != View.VISIBLE) return
        if ((v is ViewGroup || v is android.webkit.WebView) && (v.canScrollVertically(1) || v.canScrollVertically(-1))) out.add(v)
        if (v is ViewGroup) for (i in 0 until v.childCount) collect(v.getChildAt(i), out)
    }

    private fun scrollTarget(): View? {
        val root = topDialog()?.window?.decorView ?: top()?.window?.decorView ?: return null
        val all = ArrayList<View>(); collect(root, all)
        if (all.isEmpty()) return null
        val loc = IntArray(2)
        val hit = all.filter {
            it.getLocationOnScreen(loc)
            lastX >= loc[0] && lastX <= loc[0] + it.width && lastY >= loc[1] && lastY <= loc[1] + it.height
        }
        return if (hit.isNotEmpty()) hit.minByOrNull { it.width * it.height } else all.maxByOrNull { it.width * it.height }
    }

    private fun by(v: View, dy: Int, smooth: Boolean) {
        try {
            when (v) {
                is AbsListView -> if (smooth) v.smoothScrollBy(dy, 250) else v.scrollListBy(dy)
                is ScrollView -> if (smooth) v.smoothScrollBy(0, dy) else v.scrollBy(0, dy)
                else -> v.scrollBy(0, dy)
            }
        } catch (e: Exception) { }
    }

    /** dir: +1 aşağı, -1 yukarı (yaklaşık bir sayfa). */
    fun page(dir: Int) { scrollTarget()?.let { by(it, dir * (it.height * 0.75f).toInt().coerceAtLeast(120), true) } }
    fun scroll(dy: Float) { scrollTarget()?.let { by(it, dy.toInt(), false) } }
    fun fling(vy: Float) { scrollTarget()?.let { by(it, (-vy * 0.3f).toInt(), true) } }
}
