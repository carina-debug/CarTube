package com.cartube.app

import android.graphics.Color
import android.graphics.Typeface
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.graphics.Rect
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import androidx.activity.OnBackPressedCallback
import android.text.TextUtils
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.ui.PlayerView
import kotlin.concurrent.thread

/** TV: birden fazla kanal listesi, gruplama, düzenleme. Alt çubuğun ortasındaki düğme liste menüsünü açar. */
class TvActivity : AppCompatActivity() {
    private val st get() = Stores.tv
    private lateinit var listBtn: TextView
    private lateinit var groupBtn: TextView
    private lateinit var sizeBtn: TextView
    private lateinit var lv: ListView
    // Ayardaki "video_resize" değerleriyle aynı sırada: 0 Sığdır, 1 Doldur (uzat), 2 Tam ekran (kırp)
    private val sizeShort = listOf("Sığdır", "Doldur", "Tam ekran", "4:3", "16:9")
    private val sizeLong = listOf("Sığdır (orijinal oran)", "Doldur (ekrana uzat)", "Tam ekran (kırparak doldur)", "4:3 (oranı zorla)", "16:9 (oranı zorla)")
    private lateinit var rootView: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var listPane: LinearLayout
    private lateinit var navBar: View
    private var lastLand: Boolean? = null
    private var seenRev = -1
    private lateinit var fsBtn: ImageButton
    private lateinit var ctlRow: LinearLayout
    private lateinit var videoBox: FrameLayout
    private val hideCtl = Runnable { ctlRow.animate().alpha(0f).setDuration(250).withEndAction { ctlRow.visibility = View.GONE }.start() }
    private lateinit var backCb: OnBackPressedCallback
    private var full = false
    private var group = ""
    private var shown = listOf<ListStore.Item>()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        rootView = root
        body = LinearLayout(this)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        addVideoControls(VideoUi.create(this))
        listPane = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        backCb = object : OnBackPressedCallback(false) { override fun handleOnBackPressed() { toggleFullscreen() } }
        onBackPressedDispatcher.addCallback(this, backCb)
        val bar = LinearLayout(this).apply { setPadding(dp(14), dp(8), dp(14), dp(4)) }
        fun chip() = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; maxWidth = dp(200); setPadding(dp(8), dp(6), dp(14), dp(6)) }
        listBtn = chip().apply { setOnClickListener { chooseList() } }
        groupBtn = chip().apply { setOnClickListener { chooseGroup() } }
        sizeBtn = chip().apply { setOnClickListener { chooseSize() } }
        bar.addView(listBtn); bar.addView(groupBtn); bar.addView(sizeBtn)
        // Üç düğme ekrana sığmazsa yana kaydırılır
        listPane.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(bar) })
        lv = ListView(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        listPane.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        navBar = Ui.navBar(this, null, R.drawable.ic_edit) { editMenu() }
        root.addView(navBar)
        applyLayout()
        setContentView(root)
        lv.setOnItemClickListener { _, _, i, _ -> shown.getOrNull(i)?.let { App.play(it.n, it.u, true) } }
        lv.setOnItemLongClickListener { _, _, i, _ -> shown.getOrNull(i)?.let { channelMenu(it) }; true }
        refreshSize()
        refresh()
        val c = st.cur()
        if (c != null && c.items.isEmpty() && c.src.isNotBlank()) reload(c)
    }

    /** Yatayda solda kanal listesi, sağda oynatıcı; dikeyde üstte oynatıcı, altta liste. */
    private fun applyLayout() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (lastLand == land) return
        lastLand = land
        body.removeAllViews()
        if (land) {
            body.orientation = LinearLayout.HORIZONTAL
            body.addView(listPane, LinearLayout.LayoutParams(0, -1, 0.36f))
            body.addView(videoBox, LinearLayout.LayoutParams(0, -1, 0.64f))
        } else {
            body.orientation = LinearLayout.VERTICAL
            body.addView(videoBox, LinearLayout.LayoutParams(-1, 0, 1f))
            body.addView(listPane, LinearLayout.LayoutParams(-1, 0, 1f))
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::body.isInitialized) applyLayout()
    }

    override fun onResume() {
        super.onResume()
        // Liste ekranından dönünce (sıralama, ekleme, silme) liste güncellenir
        if (::lv.isInitialized && st.rev != seenRev) refresh()
    }

    private fun showControls() {
        ctlRow.animate().cancel(); ctlRow.alpha = 1f; ctlRow.visibility = View.VISIBLE
        ctlRow.removeCallbacks(hideCtl); ctlRow.postDelayed(hideCtl, 3000)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // Yalnızca Sistem (MediaPlayer) motorunda kullanılır: ExoPlayer'da görünürlük oynatıcının
        // kendi denetim çubuğundan (setControllerVisibilityListener) alınır, burada tekrar yönetilmez.
        if (VideoUi.exoView() == null && ev.action == MotionEvent.ACTION_DOWN && ::ctlRow.isInitialized) {
            val r = Rect(); videoBox.getGlobalVisibleRect(r)
            if (r.contains(ev.rawX.toInt(), ev.rawY.toInt())) showControls()
        }
        return super.dispatchTouchEvent(ev)
    }

    /** Tam ekran düğmesi ve ayar çarkını (tam ekran, çözünürlük, ekran boyutu) oynatıcının sağ alt köşesine,
     *  oynatıcının kendi simgeleriyle birlikte ekler. ExoPlayer kullanılırken bu satır oynatıcının kendi
     *  denetim çubuğuyla birlikte görünüp kaybolur; Sistem (MediaPlayer) motorunda dokunmayla 3 sn gösterilir. */
    private fun addVideoControls(box: FrameLayout) {
        val id = resources.getIdentifier("exo_settings", "id", packageName)
        if (id != 0) box.findViewById<View>(id)?.visibility = View.GONE   // ExoPlayer'ın kendi çarkı yerine bu çark kullanılır
        fun btn(icon: Int, click: () -> Unit) = ImageButton(this).apply {
            setImageResource(icon); setColorFilter(Color.WHITE); alpha = 0.85f
            background = Theme.circle(Color.parseColor("#B30E1214"), Theme.dim(Theme.set()))
            setPadding(dp(9), dp(9), dp(9), dp(9)); setOnClickListener { click() }
        }
        fsBtn = btn(R.drawable.ic_fullscreen) { toggleFullscreen() }
        val gear = btn(R.drawable.ic_settings) { playerMenu() }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(fsBtn, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(8) })
        row.addView(gear, LinearLayout.LayoutParams(dp(40), dp(40)))
        // Sağ alt köşe; ExoPlayer'ın alttaki ilerleme çubuğu ve düğme sırasının üstünde kalacak kadar boşluk bırakılır
        box.addView(row, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.BOTTOM).apply { setMargins(0, 0, dp(12), dp(64)) })
        ctlRow = row; videoBox = box
        val exo = VideoUi.exoView()
        if (exo != null) {
            // ExoPlayer: görünürlük tamamen oynatıcının kendi denetim çubuğuna bağlanır
            exo.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis -> ctlRow.visibility = vis })
        } else {
            row.visibility = View.GONE   // Sistem motoru: videoya dokununca görünür, 3 sn sonra kaybolur
        }
    }

    /** Tam ekran: video dışındaki her şeyi gizler ve yatay çevirir; geri tuşu/düğme ile çıkılır. */
    private fun toggleFullscreen() {
        full = !full
        listPane.visibility = if (full) View.GONE else View.VISIBLE
        navBar.visibility = if (full) View.GONE else View.VISIBLE
        requestedOrientation = if (full || App.bool("v_land", false)) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        fsBtn.setImageResource(if (full) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen)
        backCb.isEnabled = full
    }

    private fun playerMenu() {
        val res = L.t(App.resNames[App.int("tv_res", 0).coerceIn(0, App.resNames.lastIndex)])
        Ui.menu(this, "Oynatıcı ayarları", listOf(
            if (full) "Tam ekrandan çık" else "Tam ekran",
            L.t("Video çözünürlüğü") + ": " + res,
            "Ekran boyutu")) { i ->
            when (i) { 0 -> toggleFullscreen(); 1 -> chooseResolution(); 2 -> chooseSize() }
        }
    }

    private fun chooseResolution() {
        val cur = App.int("tv_res", 0).coerceIn(0, App.resNames.lastIndex)
        val items = App.resNames.mapIndexed { i, n -> (if (i == cur) "✓ " else "    ") + L.t(n) }
        Ui.menu(this, "Video çözünürlüğü", items) {
            App.setInt("tv_res", it); App.applyResolution()
            if (App.cur == 0 && it != 0) Ui.toast(this, "MediaPlayer motorunda çözünürlük seçilemez (ExoPlayer kullanın)")
        }
    }

    private fun refreshSize() {
        val cur = App.int("video_resize", 0).coerceIn(0, sizeShort.size - 1)
        sizeBtn.text = L.t("Ekran") + ": " + L.t(sizeShort[cur]) + " ▾"
    }

    /** Ekran boyutu: Sığdır / Doldur / Tam ekran. Seçim çalan videoya hemen uygulanır. */
    private fun chooseSize() {
        val cur = App.int("video_resize", 0).coerceIn(0, sizeShort.size - 1)
        val items = sizeLong.mapIndexed { i, n -> (if (i == cur) "✓ " else "    ") + L.t(n) }
        Ui.menu(this, "Ekran boyutu", items) { App.setInt("video_resize", it); VideoUi.applyResize(); refreshSize() }
    }

    private fun refresh() {
        seenRev = st.rev
        val c = st.cur()
        if (group.isNotBlank() && c?.items?.none { it.g == group } != false) group = ""
        listBtn.text = (c?.name ?: L.t("Liste yok")) + " ▾"
        groupBtn.text = (if (group.isBlank()) L.t("Tüm gruplar") else group) + " ▾"
        shown = c?.items?.filter { group.isBlank() || it.g == group } ?: emptyList()
        val names = if (shown.isEmpty()) listOf(L.t("Önce Ayarlar'dan M3U adresi girin")) else shown.map { (if (it.g.isNotBlank() && group.isBlank()) "[${it.g}] " else "") + it.n }
        lv.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            override fun getView(p: Int, v: android.view.View?, g: android.view.ViewGroup): android.view.View =
                super.getView(p, v, g).also { (it as TextView).setTextColor(Color.WHITE) }
        }
    }

    private fun groups() = st.cur()?.items?.map { it.g }?.filter { it.isNotBlank() }?.distinct()?.sorted() ?: emptyList()

    private fun chooseList() {
        if (st.lists.isEmpty()) { editMenu(); return }
        Ui.menu(this, "Liste seç", st.lists.map { it.name + " (" + it.items.size + ")" }) { st.active = it; st.save(); group = ""; refresh(); st.cur()?.let { c -> if (c.items.isEmpty() && c.src.isNotBlank()) reload(c) } }
    }

    private fun chooseGroup() {
        val g = groups()
        if (g.isEmpty()) { Ui.toast(this, "Henüz grup yok. Kanala uzun basıp grup ata."); return }
        Ui.menu(this, "Grup seç", listOf(L.t("Tüm gruplar")) + g) { group = if (it == 0) "" else g[it - 1]; refresh() }
    }

    private fun channelMenu(ch: ListStore.Item) {
        Ui.menu(this, ch.n, listOf("Favorilere ekle", "Grup ata", "Kanalı sil")) { i ->
            when (i) {
                0 -> { App.addFav(ch.n, ch.u); Ui.toast(this, "Favorilere eklendi") }
                1 -> Ui.ask(this, "Grup ata", listOf("Grup adı"), listOf(ch.g)) { v -> ch.g = v[0]; st.save(); refresh() }
                2 -> { st.cur()?.items?.remove(ch); st.save(); refresh() }
            }
        }
    }

    private fun editMenu() {
        Ui.menu(this, "TV listeleri", listOf("Liste ekle (M3U adresi)", "Yeni boş liste", "Kanal ekle", "Grup yönetimi",
            "Listeyi yenile", "Listeyi yeniden adlandır", "Listeyi sil")) { i ->
            when (i) {
                0 -> Ui.ask(this, "Liste ekle (M3U adresi)", listOf("Liste adı", "M3U / IPTV liste adresi")) { v -> addFromUrl(v[0], v[1]) }
                1 -> Ui.ask(this, "Yeni boş liste", listOf("Liste adı")) { v -> if (v[0].isNotBlank()) { st.add(ListStore.Lst(v[0])); group = ""; refresh() } }
                2 -> Ui.ask(this, "Kanal ekle", listOf("Ad", "Yayın adresi (URL)", "Grup (isteğe bağlı)")) { v ->
                    if (v[1].isNotBlank()) {
                        if (st.cur() == null) st.add(ListStore.Lst("Listem"))
                        st.cur()!!.items.add(ListStore.Item(v[0].ifBlank { v[1] }, v[1], v[2])); st.save(); refresh()
                    }
                }
                3 -> groupMenu()
                4 -> st.cur()?.let { reload(it) }
                5 -> st.cur()?.let { c -> Ui.ask(this, "Listeyi yeniden adlandır", listOf("Liste adı"), listOf(c.name)) { v -> if (v[0].isNotBlank()) { c.name = v[0]; st.save(); refresh() } } }
                6 -> st.cur()?.let { c -> Ui.confirm(this, "\"${c.name}\" " + L.t("silinsin mi?")) { st.removeActive(); group = ""; refresh() } }
            }
        }
    }

    private fun groupMenu() {
        val g = groups()
        if (g.isEmpty()) { Ui.toast(this, "Henüz grup yok. Kanala uzun basıp grup ata."); return }
        Ui.menu(this, "Grup yönetimi", listOf("Grubu yeniden adlandır", "Grubu sil")) { act ->
            Ui.menu(this, "Grup seç", g) { gi ->
                val name = g[gi]
                if (act == 0) Ui.ask(this, "Grubu yeniden adlandır", listOf("Grup adı"), listOf(name)) { v ->
                    st.cur()?.items?.filter { it.g == name }?.forEach { it.g = v[0] }; st.save(); group = ""; refresh() }
                else Ui.confirm(this, "\"$name\" " + L.t("grubu silinsin mi? (kanallar kalır)")) {
                    st.cur()?.items?.filter { it.g == name }?.forEach { it.g = "" }; st.save(); group = ""; refresh() }
            }
        }
    }

    private fun addFromUrl(name: String, url: String) {
        if (url.isBlank()) return
        val l = ListStore.Lst(name.ifBlank { url.substringAfterLast('/') }, url)
        st.add(l); group = ""; refresh(); reload(l)
    }

    private fun reload(c: ListStore.Lst) {
        if (c.src.isBlank()) { Ui.toast(this, "Bu liste elle oluşturulmuş"); return }
        Ui.toast(this, "Yükleniyor…")
        thread {
            val items = try { ListStore.parse(ListStore.http(c.src)) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (items.isEmpty()) Ui.toast(this, "Liste yüklenemedi")
                else {
                    // elle atanan grupları koru
                    val old = c.items.associate { it.u to it.g }
                    items.forEach { if (it.g.isBlank()) it.g = old[it.u] ?: "" }
                    c.items = items.toMutableList(); st.save(); refresh()
                }
            }
        }
    }

    override fun onDestroy() { Sys.onSize = null; VideoUi.release(); super.onDestroy() }
}
