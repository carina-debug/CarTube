package com.cartube.app.car

import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.TextView
import com.cartube.app.*
import com.google.android.apps.auto.sdk.CarActivity
import com.google.android.apps.auto.sdk.CarActivityService

/**
 * Eski Android Auto projeksiyon girişi ("CarTube Pro Tam"). Fermata/Mola'daki CarService'in karşılığı.
 * Yan yüklenen (Play dışı) kurulumda da başlatıcıda görünür. İçerik, CarDisplay sanal ekranı üzerinden
 * araç yüzeyine çizilir; dokunuşlar CarDisplay'e iletilir.
 */
class CarTubeProjectionService : CarActivityService() {
    override fun getCarActivity(): Class<out CarActivity> = CarTubeCarActivity::class.java

    override fun onDestroy() {
        try { Mirror.detachDisplay() } catch (e: Exception) { }
        try { CarDisplay.release() } catch (e: Exception) { }
        super.onDestroy()
    }
}

class CarTubeCarActivity : CarActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { setIgnoreConfigChanges(-1) } catch (e: Exception) { }
        try {
            val ctrl = getCarUiController()
            ctrl.getStatusBarController().hideAppHeader()
            ctrl.getMenuController().hideMenuButton()
        } catch (e: Exception) { }

        if (!License.active()) {
            val t = TextView(this)
            t.text = L.t("CarTube lisansı gerekli. Telefondan CarTube'u açıp lisansı etkinleştirin.")
            t.textSize = 24f
            t.setTextColor(0xFFFFFFFF.toInt())
            t.gravity = android.view.Gravity.CENTER
            setContentView(t)
            return
        }
        try { App.greet(App.ctx, true) } catch (e: Exception) { }

        val sv = SurfaceView(this)
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { CarDisplay.tap(e.x, e.y); return true }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean { CarDisplay.scroll(dy); return true }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean { CarDisplay.fling(vy); return true }
        })
        sv.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); true }
        sv.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) {}
            override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hgt: Int) {
                if (w <= 0 || hgt <= 0) return
                CarDisplay.attach(App.ctx, h.surface, w, hgt, resources.displayMetrics.densityDpi)
                if (!CarDisplay.hasActivity()) CarDisplay.launch(App.ctx, MainActivity::class.java)
            }
            override fun surfaceDestroyed(h: SurfaceHolder) { CarDisplay.detachSurface() }
        })
        setContentView(sv)
    }

    override fun onDestroy() {
        try { Mirror.detachDisplay() } catch (e: Exception) { }
        try { CarDisplay.release() } catch (e: Exception) { }
        super.onDestroy()
    }
}
