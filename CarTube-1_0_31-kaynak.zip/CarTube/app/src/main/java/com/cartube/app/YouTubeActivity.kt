package com.cartube.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.graphics.Color
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class YouTubeActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var frame: FrameLayout
    private lateinit var navBar: View
    private lateinit var rootView: LinearLayout
    private var defaultUa = ""
    private val webCheck = object : Runnable { override fun run() { checkWebPlaying(); h.postDelayed(this, 1500) } }
    private var custom: View? = null
    private var popup: WebView? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val h = Handler(Looper.getMainLooper())
    private var docStart = false
    private var sbVideo = ""
    private var segs: List<Triple<Double, Double, String>> = emptyList()
    private val tick = object : Runnable { override fun run() { tickOnce(); h.postDelayed(this, 600) } }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        frame = FrameLayout(this)
        web = BgWebView(this).apply {
            defaultUa = settings.userAgentString
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            // Google / YouTube Kids hesap girişi üçüncü taraf çerezlere dayanır; kapalıysa giriş sonrası ekran boş (siyah) kalır
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            val mode = App.int("yt_dark", 0)
            val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            if (Build.VERSION.SDK_INT >= 33) settings.isAlgorithmicDarkeningAllowed = mode == 1 || (mode == 0 && night)
            else if (Build.VERSION.SDK_INT >= 29) settings.forceDark = when (mode) {
                1 -> WebSettings.FORCE_DARK_ON; 2 -> WebSettings.FORCE_DARK_OFF; else -> WebSettings.FORCE_DARK_AUTO }
            val block = App.bool("yt_block", true)
            // Arka plan betiği önce ve ayrı çalışır: reklam betiğinde hata olsa bile arka planda oynatma bozulmaz
            val scriptJs = BG_JS + ";" + (if (block) "try{" + AD_JS + "}catch(e){}" else "")
            addJavascriptInterface(CtBridge(), "CTBridge")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                    val sc = r.url.scheme ?: return false
                    if (sc in setOf("http", "https", "about", "data", "blob", "javascript", "file")) return false
                    when (sc) {
                        // Siteler "uygulamada aç" için intent: adresi verir; uygulama içinde normal sayfaya çevrilir
                        "intent" -> try {
                            val ti = Intent.parseUri(r.url.toString(), Intent.URI_INTENT_SCHEME)
                            val fb = ti.getStringExtra("browser_fallback_url")
                            val d = ti.data
                            if (!fb.isNullOrBlank()) v.loadUrl(fb)
                            else if (d != null && (d.scheme == "http" || d.scheme == "https")) v.loadUrl(d.toString())
                        } catch (e: Exception) { }
                        "tel", "mailto", "geo", "sms" -> try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                    }
                    return true   // diğer uygulama şemaları (market:, vnd.youtube: ...) hata sayfası yerine sessizce engellenir
                }
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                    if (block && isAdUrl(r.url)) return WebResourceResponse("text/plain", "UTF-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                    return super.shouldInterceptRequest(v, r)
                }
                override fun onPageFinished(v: WebView, url: String?) {
                    super.onPageFinished(v, url)
                    if (url != null && url.contains("youtubekids")) { kidsFit(); injectKidsSeekGesture() }
                }
                override fun onPageStarted(v: WebView, url: String?, f: android.graphics.Bitmap?) {
                    super.onPageStarted(v, url, f)
                    if (!docStart && isYt(url)) v.evaluateJavascript(scriptJs, null)
                }
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(this, scriptJs, setOf("https://m.youtube.com", "https://www.youtube.com", "https://music.youtube.com", "https://www.youtubekids.com"))
                docStart = true
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                    custom = v; customCb = cb
                    frame.addView(v, ViewGroup.LayoutParams(-1, -1)); web.visibility = View.GONE; navBar.visibility = View.GONE
                    if (App.bool("yt_land", false)) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; bars(true)
                    kidsFullscreenFit()
                }
                override fun onHideCustomView() {
                    custom?.let { frame.removeView(it) }; custom = null; customCb?.onCustomViewHidden()
                    web.visibility = View.VISIBLE; navBar.visibility = View.VISIBLE; requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; bars(false)
                    // Tam ekrandan dönünce (dönmüş olabilir) Kids ölçeği baştan hesaplanır
                    web.requestLayout()
                    web.postDelayed({ kidsFit() }, 150); web.postDelayed({ kidsFit() }, 600); web.postDelayed({ kidsFit() }, 1500)
                }
                // Kids hesap girişi (Google) açılır pencere ile yapılır; pencere üstte gösterilir, kapanınca Kids yenilenir
                override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                    closePopup()
                    val w = WebView(this@YouTubeActivity)
                    w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true
                    w.settings.userAgentString = web.settings.userAgentString
                    w.settings.setSupportMultipleWindows(true); w.settings.javaScriptCanOpenWindowsAutomatically = true
                    CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
                    w.webViewClient = WebViewClient()
                    w.webChromeClient = object : WebChromeClient() {
                        override fun onCloseWindow(window: WebView) { closePopup() }
                    }
                    w.setBackgroundColor(Color.WHITE)
                    frame.addView(w, ViewGroup.LayoutParams(-1, -1)); popup = w
                    val t = resultMsg.obj as WebView.WebViewTransport
                    t.webView = w; resultMsg.sendToTarget()
                    return true
                }
                override fun onCloseWindow(window: WebView) { closePopup() }
            }
        }
        val start = intent.getStringExtra("url") ?: "https://m.youtube.com"
        applyUa(start)
        web.loadUrl(start)
        frame.addView(web, ViewGroup.LayoutParams(-1, -1))
        val u0 = intent.getStringExtra("url") ?: ""
        navBar = Ui.navBar(this, titleFor(u0))
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0E1214")) }
        rootView = root
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(navBar)
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (popup != null) closePopup()
                else if (custom != null) web.webChromeClient?.onHideCustomView()
                else if (web.canGoBack()) web.goBack() else finish()
            }
        })
        // Arka planda oynatma: oynatma durumu izlenir, çalıyorsa ön plan servisi uygulamayı canlı tutar
        App.webStop = { runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("(function(){var v=document.querySelector('video');if(v)v.pause();})()", null) } }
        h.postDelayed(webCheck, 1000)
    }

    private fun titleFor(u: String) = when { u.contains("youtubekids") -> "YouTube Kids"; u.isBlank() || u.contains("youtube") -> "YouTube"; else -> "Web" }

    /** Kids için tablet kimliği, diğer siteler için varsayılan kimlik. */
    private fun applyUa(u: String) {
        val st = web.settings
        if (u.contains("youtubekids")) {
            st.userAgentString = TABLET_UA
            st.useWideViewPort = true; st.loadWithOverviewMode = true
            st.setSupportZoom(true); st.builtInZoomControls = true; st.displayZoomControls = false
            st.setSupportMultipleWindows(true); st.javaScriptCanOpenWindowsAutomatically = true
        } else {
            st.setSupportMultipleWindows(false); st.javaScriptCanOpenWindowsAutomatically = false
            st.userAgentString = defaultUa
            // YouTube Kids'ten dönünce Kids için açılan geniş görünüm ve yakınlaştırma ayarları sıfırlanır
            st.useWideViewPort = false; st.loadWithOverviewMode = false
            st.setSupportZoom(true); st.builtInZoomControls = false
        }
    }

    /** YouTube Kids'te videonun sol/sağ üçte birine çift dokununca 10 sn geri/ileri sarar (ana YouTube'daki gibi). Kids web oynatıcısında bu jest yok, burada JS ile eklenir. */
    private fun injectKidsSeekGesture() {
        web.evaluateJavascript("""(function(){
if(window.__ckseek)return;window.__ckseek=1;
var lastT=0,lastX=0;
function flash(txt,x){try{
var d=document.createElement('div');d.textContent=txt;
d.style.cssText='position:fixed;top:40%;'+(x<innerWidth/2?'left:8%':'right:8%')+';transform:translateY(-50%);background:rgba(0,0,0,.65);color:#fff;font:700 15px sans-serif;padding:10px 14px;border-radius:24px;z-index:999999;pointer-events:none;';
document.body.appendChild(d);setTimeout(function(){d.remove();},500);
}catch(e){}}
document.addEventListener('touchend',function(e){
var v=document.querySelector('video');if(!v||!v.duration)return;
var t=e.changedTouches&&e.changedTouches[0];if(!t)return;
var el=document.elementFromPoint(t.clientX,t.clientY);
if(!el||!(el===v||el.closest('video,.html5-video-container,#player-container,#player')))return;
var third=innerWidth/3;
if(t.clientX>third&&t.clientX<third*2)return;
var now=Date.now();
if(now-lastT<380&&Math.abs(t.clientX-lastX)<60){
var d=t.clientX<third?-10:10;
v.currentTime=Math.max(0,Math.min(v.duration,v.currentTime+d));
flash((d>0?'+10 sn':'-10 sn'),t.clientX);
lastT=0;
}else{lastT=now;lastX=t.clientX;}
},true);
})();""", null)
    }

    private fun checkWebPlaying() {
        if (!::web.isInitialized) return
        web.evaluateJavascript("(function(){var v=document.querySelector('video');return !!(v&&!v.paused&&!v.ended&&v.readyState>2);})()") { r ->
            val on = r == "true"
            App.webPlaying = on
            if (on) App.ensureKeepAlive()
        }
    }

    /** Ana ekrandan aynı ekrana dönülürse çalan içerik kesilmeden devam eder; farklı bir site istenirse o açılır. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Adres verilmediyse (ana ekrandaki YouTube kutucuğu) YouTube istenmiş demektir; YouTube Kids açıksa ona geçilir
        val u = intent.getStringExtra("url") ?: "https://m.youtube.com"
        if (siteOf(u) == siteOf(web.url ?: "")) return
        if (custom != null) web.webChromeClient?.onHideCustomView()
        applyUa(u); web.loadUrl(u)
        rootView.removeView(navBar); navBar = Ui.navBar(this, titleFor(u)); rootView.addView(navBar)
    }

    /** Aynı site mi diye bakmak için: YouTube, YouTube Kids ve diğer siteler birbirinden ayrılır. */
    private fun siteOf(s: String): String {
        if (s.contains("youtubekids")) return "kids"
        val host = try { Uri.parse(s).host ?: s } catch (e: Exception) { s }
        return if (host == "m.youtube.com" || host == "www.youtube.com" || host == "youtube.com") "yt" else host
    }

    private fun bars(hide: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (hide) { c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE; c.hide(WindowInsetsCompat.Type.systemBars()) }
        else c.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun tickOnce() {
        val u = web.url ?: return
        if (!isYt(u)) return
        val ytq = when (App.int("yt_quality", 3)) { 0 -> "tiny"; 1 -> "small"; 2 -> "medium"; else -> "high" }
        val js = """(function(){var v=document.querySelector('video');if(!v)return -1;
var p=document.getElementById('movie_player');if(p&&p.getAvailableQualityLevels&&window.__ctq!==location.href){var l=p.getAvailableQualityLevels();if(l&&l.length){var want='$ytq';if(want==='high'){want=(l[0]==='auto'&&l.length>1)?l[1]:l[0];}try{p.setPlaybackQualityRange(want,want);}catch(e){}try{p.setPlaybackQuality(want);}catch(e){}window.__ctq=location.href;}}
var pl0=document.getElementById('movie_player');var adOn=!!(pl0&&pl0.classList.contains('ad-showing'));
if(window.__ctmuted&&!adOn){v.muted=false;window.__ctmuted=false;}
if(${App.bool("yt_skip", true)}&&adOn){v.muted=true;window.__ctmuted=true;if(isFinite(v.duration)&&v.duration>0&&v.currentTime<v.duration-0.3){v.currentTime=v.duration-0.1;}}
if(${App.bool("yt_skip", true)}){var b=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button');if(b)b.click();}
if(${App.bool("yt_fs", true)}&&location.pathname.indexOf('/watch')==0&&!document.fullscreenElement&&window.__ctf!==location.href){var f=document.querySelector('.fullscreen-icon,.ytp-fullscreen-button');if(f){f.click();window.__ctf=location.href;}}
return v.currentTime;})()"""
        web.evaluateJavascript(js) { r ->
            val t = r?.toDoubleOrNull() ?: return@evaluateJavascript
            if (t >= 0) sponsorBlock(u, t)
        }
    }

    private fun sponsorBlock(url: String, t: Double) {
        if (!App.bool("sb_on", false)) return
        val vid = Uri.parse(url).getQueryParameter("v") ?: return
        if (vid != sbVideo) {
            sbVideo = vid; segs = emptyList()
            val cats = JSONArray(listOf("sponsor", "selfpromo", "interaction", "intro", "outro", "music_offtopic")
                .filter { App.bool("sb_$it", it in listOf("sponsor", "selfpromo", "interaction")) }).toString()
            thread {
                try {
                    val c = URL("https://sponsor.ajay.app/api/skipSegments?videoID=$vid&categories=" + URLEncoder.encode(cats, "UTF-8"))
                        .openConnection() as HttpURLConnection
                    c.connectTimeout = 5000; c.readTimeout = 5000
                    if (c.responseCode == 200) {
                        val a = JSONArray(c.inputStream.bufferedReader().readText())
                        val l = (0 until a.length()).map { a.getJSONObject(it) }.map {
                            val sg = it.getJSONArray("segment"); Triple(sg.getDouble(0), sg.getDouble(1), it.optString("category")) }
                        h.post { if (sbVideo == vid) segs = l }
                    }
                } catch (e: Exception) { }
            }
            return
        }
        segs.firstOrNull { t >= it.first && t < it.second - 0.4 }?.let {
            web.evaluateJavascript("var v=document.querySelector('video');if(v)v.currentTime=${it.second};", null)
            Toast.makeText(this, "SponsorBlock: " + it.third, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() { super.onResume(); h.postDelayed(tick, 1500) }
    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
        if (!isFinishing) {
            // Arka plana geçerken içerik çalıyorsa ön plan servisi hâlâ uygulama görünürken başlatılır (Android arka plandan başlatmaya izin vermez)
            if (App.webPlaying) App.ensureKeepAlive()
            if (::web.isInitialized) web.resumeTimers()
        }
    }
    override fun onDestroy() { closePopup(); App.webPlaying = false; App.webStop = null; h.removeCallbacksAndMessages(null); frame.removeAllViews(); web.stopLoading(); web.destroy(); super.onDestroy() }

    /** YouTube Kids: sayfa en az 820 px genişliğinde kurulur ve ekran genişliğine tam sığacak ölçekte gösterilir.
     *  Dikey, yatay ve geniş (araç) ekranlarda yeniden hesaplanır. */
    private fun kidsFit() {
        if (!::web.isInitialized) return
        val u = web.url ?: return
        if (!u.contains("youtubekids")) return
        if (custom != null || web.visibility != View.VISIBLE) return   // tam ekranda/gizliyken ölçülen genişlik yanlış olur
        val cssW = resources.configuration.screenWidthDp.coerceAtLeast(200)
        val base = when (App.int("kids_w", 2)) { 1 -> 480; 2 -> 900; 3 -> 1100; else -> 640 }
        val w = maxOf(cssW, base)
        val scale = String.format(java.util.Locale.US, "%.3f", cssW.toFloat() / w)
        val c = "width=$w,initial-scale=$scale,minimum-scale=0.1,maximum-scale=5,user-scalable=yes"
        // Her çağrıda yeni bir "nesil" numarası alınır: dönüş sırasında önceki hesaplamadan kalan
        // gecikmeli adımlar (eski genişliğe göre) artık uygulanmaz; zoom her seferinde sıfırlanıp
        // yeniden hesaplanır, böylece art arda büyütme/küçültme birikip kaymaya yol açmaz.
        web.evaluateJavascript(
            "(function(){window.__ckgen=(window.__ckgen||0)+1;var gen=window.__ckgen;window.__ckc='$c';" +
            "function ap(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';(document.head||document.documentElement).appendChild(m);}if(m.getAttribute('content')!==window.__ckc)m.setAttribute('content',window.__ckc);}ap();" +
            "function f(){if(gen!==window.__ckgen)return;try{document.body.style.zoom='';}catch(e){}" +
            "requestAnimationFrame(function(){if(gen!==window.__ckgen)return;var iw=window.innerWidth,sw=document.documentElement.scrollWidth;if(iw>0&&sw>iw+4&&document.body){document.body.style.zoom=String(iw/sw);}});}" +
            "setTimeout(f,350);setTimeout(f,900);setTimeout(f,2200);" +
            "if(!window.__ckt){window.__ckt=setInterval(ap,3000);}})();", null)
    }

    /** Tam ekran video: sayfa yakınlaştırma/geniş görünüm ayarları kapatılır; oynatıcı doğrudan ekranı doldurur. */
    private fun kidsFullscreenFit() {
        if (!::web.isInitialized) return
        val u = web.url ?: return
        if (!u.contains("youtubekids")) return
        web.evaluateJavascript(
            "(function(){window.__ckgen=(window.__ckgen||0)+1;window.__ckc='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1';" +
            "var m=document.querySelector('meta[name=viewport]');if(m)m.setAttribute('content',window.__ckc);" +
            "try{document.body.style.zoom='';}catch(e){}try{window.dispatchEvent(new Event('resize'));}catch(e){}})();", null)
    }

    private fun closePopup() {
        val p = popup ?: return
        popup = null
        try { frame.removeView(p); p.stopLoading(); p.destroy() } catch (e: Exception) { }
        // Giriş tamamlandıysa Kids'in oturumu görmesi için sayfa yenilenir
        if (::web.isInitialized && (web.url ?: "").contains("youtubekids")) web.reload()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::web.isInitialized) return
        if (custom != null) {
            // Tam ekranda döndürme: görünümü yeniden yerleştir, sayfaya yeni boyutu bildir
            frame.requestLayout(); custom?.requestLayout()
            web.postDelayed({ kidsFullscreenFit() }, 200); web.postDelayed({ kidsFullscreenFit() }, 700)
        } else { web.postDelayed({ kidsFit() }, 250); web.postDelayed({ kidsFit() }, 650) }
    }

    private fun isYt(u: String?) = u != null && (u.contains("youtube.com") || u.contains("youtubekids.com"))

    private fun isAdUrl(u: Uri): Boolean {
        val h = u.host ?: return false
        val p = u.path ?: ""
        if (AD_HOSTS.any { h == it || h.endsWith(".$it") } || h.startsWith("adservice.google.")) return true
        if ((h.endsWith("youtube.com") || h.endsWith("youtubekids.com")) && (p.startsWith("/pagead/") || p.startsWith("/api/stats/ads") || p.contains("/ptracking") || p.startsWith("/get_midroll_info"))) return true
        return false
    }

    companion object {
        private const val TABLET_UA = "Mozilla/5.0 (Linux; Android 13; SM-X700) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        /** Sayfa gizlendiğinde (arka plan) videonun duraklatılmasını engeller. */
        private const val BG_JS = """(function(){try{
Object.defineProperty(document,'hidden',{configurable:true,get:function(){return false;}});
Object.defineProperty(document,'visibilityState',{configurable:true,get:function(){return 'visible';}});
['visibilitychange','webkitvisibilitychange'].forEach(function(n){document.addEventListener(n,function(e){e.stopImmediatePropagation();},true);});
window.addEventListener('blur',function(e){e.stopImmediatePropagation();},true);
}catch(e){}
try{document.hasFocus=function(){return true;};}catch(e){}
try{var s=function(e){var v=e.target;if(v&&v.tagName==='VIDEO'&&window.CTBridge){try{CTBridge.state(!v.paused&&!v.ended);}catch(x){}}};['playing','pause','ended'].forEach(function(n){document.addEventListener(n,s,true);});}catch(e){}
})();"""
        private val AD_HOSTS = listOf("doubleclick.net", "googlesyndication.com", "googleadservices.com", "2mdn.net", "adnxs.com",
            "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com", "amazon-adsystem.com",
            "moatads.com", "adsafeprotected.com", "adform.net", "smartadserver.com", "openx.net", "casalemedia.com", "teads.tv", "yieldmo.com")
        /** Oynatıcı yanıtından reklam alanlarını ayıklar, reklam öğelerini gizler. Sayfa başlamadan önce çalışır. */
        private const val AD_JS = """(function(){
if(window.__ctab)return;window.__ctab=1;
var K=['adPlacements','playerAds','adSlots','adBreakHeartbeatParams'];
function strip(o){try{if(!o||typeof o!=='object')return o;
for(var i=0;i<K.length;i++){if(K[i] in o){try{o[K[i]]=(K[i]==='adBreakHeartbeatParams')?undefined:[];}catch(e){}}}
if(o.playerResponse)strip(o.playerResponse);
if(o.response&&o.response.playerResponse)strip(o.response.playerResponse);}catch(e){}return o;}
var oj=JSON.parse;JSON.parse=function(){return strip(oj.apply(this,arguments));};
var rj=Response.prototype.json;Response.prototype.json=function(){return rj.apply(this,arguments).then(strip);};
var _ipr;try{Object.defineProperty(window,'ytInitialPlayerResponse',{configurable:true,get:function(){return _ipr;},set:function(v){_ipr=strip(v);}});}catch(e){}
var css='ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-slot,ytm-ad-slot-renderer,ytm-statement-banner-renderer,ytm-brand-video-singleton-renderer,ytm-in-feed-ad-layout-renderer,.ytp-ad-overlay-container,.ytp-ad-text-overlay{display:none!important}';
function addCss(){var s=document.createElement('style');s.textContent=css;(document.head||document.documentElement).appendChild(s);}
if(document.documentElement)addCss();else document.addEventListener('DOMContentLoaded',addCss);
})();"""
    }
}

/** Uygulama arka plana alınınca pencere görünürlüğü "gizli" olsa bile sayfanın görünür kalmasını sağlar; böylece video/ses kesilmez. */
private class BgWebView(c: Context) : WebView(c) {
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(View.VISIBLE)
    }
}

/** Sayfadaki oynatma olaylarını (oynuyor / durdu) anında bildirir; ön plan servisi bu sayede zamanında başlar. */
class CtBridge {
    @JavascriptInterface
    fun state(on: Boolean) {
        App.webPlaying = on
        if (on) App.ensureKeepAlive()
    }
}
