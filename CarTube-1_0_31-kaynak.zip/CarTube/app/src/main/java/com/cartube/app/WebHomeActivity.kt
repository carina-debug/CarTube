package com.cartube.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray

/** Web: renkli "Hızlı erişim" kutucukları. Uzun basarak sıra ve renk değiştirilir, kendi sitelerinizi ekleyebilirsiniz. */
class WebHomeActivity : AppCompatActivity() {
    private class T(val id: String, val name: String, val defColor: String, val url: String, val pkg: String? = null, val custom: Boolean = false)

    private val builtin = listOf(
        T("yt", "YouTube", "#D50F1F", "https://m.youtube.com"),
        T("ytm", "YouTube Music", "#C2185B", "https://music.youtube.com"),
        T("google", "Google", "#2563EB", "https://www.google.com"),
        T("spotify", "Spotify", "#059669", "https://open.spotify.com", "com.spotify.music"),
        T("news", "Haberler", "#D97706", "https://news.google.com/?hl=tr&gl=TR&ceid=TR:tr"),
        T("map", "Harita", "#7C3AED", "https://www.google.com/maps", "com.google.android.apps.maps"))

    private val palette = listOf("Kırmızı" to "#D50F1F", "Pembe" to "#C2185B", "Mavi" to "#2563EB", "Yeşil" to "#059669",
        "Turuncu" to "#D97706", "Mor" to "#7C3AED", "Turkuaz" to "#0E9AA7", "Lacivert" to "#1E3A8A", "Gri" to "#475569", "Altın" to "#B8860B")

    private lateinit var grid: LinearLayout
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        root.addView(TextView(this).apply {
            text = L.t("Hızlı erişim"); setTextColor(Color.WHITE); textSize = 28f; setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(dp(16), dp(40), dp(16), dp(2)) })
        root.addView(TextView(this).apply {
            text = L.t("Düzenlemek için bir kutucuğa uzun basın"); setTextColor(Color.parseColor("#9FB0BD")); textSize = 13f
            gravity = Gravity.CENTER; setPadding(dp(16), 0, dp(16), dp(10)) })
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(4), dp(14), dp(16)) }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(grid) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Ui.navBar(this, L.t("Web")))
        setContentView(root)
        render()
    }

    private fun open(url: String, pkg: String? = null) {
        if (pkg != null) {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) { try { startActivity(i); return } catch (e: Exception) { } }
        }
        startActivity(Intent(this, YouTubeActivity::class.java).putExtra("url", url).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    /** Kullanıcının sırasına göre dizilmiş tüm kutucuklar. */
    private fun tiles(): List<T> {
        val all = mutableListOf<T>().apply { addAll(builtin) }
        val home = App.str("web_home")
        if (home.isNotBlank()) all.add(T("homepage", L.t("Ana sayfam"), "#0F766E", home))
        App.shortcuts().forEach { (n, u) -> all.add(T("u:$u", n, "#334155", u, null, true)) }
        val saved = try { JSONArray(App.str("web_order").ifBlank { "[]" }).let { a -> (0 until a.length()).map { a.getString(it) } } } catch (e: Exception) { emptyList() }
        return saved.mapNotNull { id -> all.find { it.id == id } } + all.filter { it.id !in saved }
    }

    private fun color(t: T): Int = try { Color.parseColor(App.str("web_col_" + t.id).ifBlank { t.defColor }) } catch (e: Exception) { Color.parseColor(t.defColor) }

    private fun saveOrder(ids: List<String>) = App.setStr("web_order", JSONArray(ids).toString())

    private fun move(t: T, dir: Int) {
        val ids = tiles().map { it.id }.toMutableList()
        val i = ids.indexOf(t.id); val j = i + dir
        if (i < 0 || j < 0 || j >= ids.size) return
        ids[i] = ids[j].also { ids[j] = ids[i] }
        saveOrder(ids); render()
    }

    private fun pickColor(t: T) {
        Ui.menu(this, "Rengi değiştir", listOf(L.t("Varsayılan renk")) + palette.map { L.t(it.first) }) { i ->
            App.setStr("web_col_" + t.id, if (i == 0) "" else palette[i - 1].second); render()
        }
    }

    private fun options(t: T) {
        val items = mutableListOf("Yukarı taşı", "Aşağı taşı", "Rengi değiştir")
        if (t.custom) items.add("Sil")
        items.add("Sırayı ve renkleri sıfırla")
        Ui.menu(this, t.name, items.map { L.t(it) }) { i ->
            when (items[i]) {
                "Yukarı taşı" -> move(t, -1)
                "Aşağı taşı" -> move(t, 1)
                "Rengi değiştir" -> pickColor(t)
                "Sil" -> AlertDialog.Builder(this).setMessage("\"${t.name}\" " + L.t("kısayolu silinsin mi?"))
                    .setPositiveButton(L.t("Sil")) { _, _ -> App.removeShortcut(t.url); saveOrder(tiles().map { it.id }.filter { it != t.id }); render() }
                    .setNegativeButton(L.t("İptal"), null).showCar()
                else -> { App.setStr("web_order", ""); tiles().forEach { App.setStr("web_col_" + it.id, "") }; render() }
            }
        }
    }

    private fun tileView(name: String, fill: Int, click: () -> Unit, long: (() -> Unit)? = null) = TextView(this).apply {
        text = name; setTextColor(Color.WHITE); textSize = 20f; setTypeface(null, Typeface.BOLD)
        gravity = Gravity.CENTER; maxLines = 2; setPadding(dp(10), dp(8), dp(10), dp(8))
        background = Theme.roundRect(fill, 28)
        setOnClickListener { click() }
        long?.let { l -> setOnLongClickListener { l(); true } }
    }

    private fun render() {
        grid.removeAllViews()
        val views = mutableListOf<TextView>()
        tiles().forEach { t -> views.add(tileView(t.name, color(t), { open(t.url, t.pkg) }, { options(t) })) }
        views.add(tileView("+ " + L.t("Ekle"), Color.parseColor("#1F2937"), { addSite() }))
        views.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, v ->
                row.addView(v, LinearLayout.LayoutParams(0, dp(96), 1f).apply {
                    topMargin = dp(6); bottomMargin = dp(6); leftMargin = dp(if (i == 0) 0 else 6); rightMargin = dp(if (i == 0) 6 else 0) })
            }
            if (pair.size == 1) row.addView(android.view.View(this), LinearLayout.LayoutParams(0, 1, 1f))
            grid.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun addSite() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = L.t("Ad"); setSingleLine() }
        val url = EditText(this).apply { hint = L.t("Adres (örn. example.com)"); setSingleLine() }
        l.addView(name); l.addView(url)
        AlertDialog.Builder(this).setTitle(L.t("Kısayol ekle")).setView(l)
            .setPositiveButton(L.t("Ekle")) { _, _ ->
                var u = url.text.toString().trim()
                if (u.isNotBlank()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    App.addShortcut(name.text.toString().ifBlank { u }, u); render()
                }
            }.setNegativeButton(L.t("İptal"), null).showCar()
    }
}
