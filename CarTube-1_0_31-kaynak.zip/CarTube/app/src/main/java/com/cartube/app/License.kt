package com.cartube.app

import android.provider.Settings
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.UUID

/**
 * Çevrimiçi lisans doğrulama.
 * CT-XXXX-XXXX-XXXX anahtarı sunucuda e-posta ve cihaz koduna bağlıdır; sunucu yanıtları imzalıdır.
 * Etkinleştirilen cihaz, uygulama silinip yeniden kurulsa da cihaz koduyla otomatik tanınır.
 * Uygulamada yalnızca genel anahtar bulunur; imzayı yalnızca sunucudaki özel anahtar atabilir.
 * (Eski CT1 çevrimdışı anahtarlar 1.0.22 ile kaldırıldı.)
 */
object License {
    private const val PUB = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEOXHzAe/jLgAmqpjY9JpBZhbmcIvFNvuQTQv4aj+zQwY2rVhgm/C/5r/0YeE8ornYj+HbC3avHRM7mr93aSszdA=="
    private const val GRACE_MS = 3L * 86_400_000L       // sunucuya ulaşılamazsa tanınan süre
    private const val REFRESH_MS = 6L * 3_600_000L      // arka plan denetim aralığı

    class Info(val name: String, val expiry: String)
    sealed class Result {
        class Ok(val info: Info) : Result()
        class Bad(val reason: String) : Result()
    }
    /** Lisans ekranında gösterilen ayrıntılar. */
    class Details(
        val active: Boolean, val status: String, val email: String, val universal: Boolean,
        val expiry: String, val daysLeft: Long?, val activatedAt: Long, val expiryAt: Long = 0L)
    private class Online(val status: String, val exp: String, val email: String, val act: Long, val expAt: Long)

    private val pubKey by lazy { KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(PUB, Base64.DEFAULT))) }
    private const val B64 = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP

    private fun rawCode(): String {
        val id = Settings.Secure.getString(App.ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val h = MessageDigest.getInstance("SHA-256").digest(("cartube|" + id).toByteArray())
        return h.take(8).joinToString("") { "%02X".format(it) }
    }

    /** Kullanıcıya gösterilen cihaz kodu: XXXX-XXXX-XXXX-XXXX */
    fun deviceCode(): String = rawCode().chunked(4).joinToString("-")

    private fun rawToDer(raw: ByteArray): ByteArray {
        fun enc(b: ByteArray): ByteArray {
            var i = 0
            while (i < b.size - 1 && b[i] == 0.toByte()) i++
            var v = b.copyOfRange(i, b.size)
            if (v[0] < 0) v = byteArrayOf(0) + v
            return byteArrayOf(0x02, v.size.toByte()) + v
        }
        val r = enc(raw.copyOfRange(0, 32)); val s = enc(raw.copyOfRange(32, 64))
        return byteArrayOf(0x30, (r.size + s.size).toByte()) + r + s
    }

    private fun sigOk(payload: ByteArray, sig: ByteArray): Boolean {
        if (sig.size != 64) return false
        return Signature.getInstance("SHA256withECDSA").run {
            initVerify(pubKey); update(payload); verify(rawToDer(sig))
        }
    }

    /** yyyyMMdd tarihinin bittiği an (gün sonu), geçersizse null. */
    private fun endMillis(expiry: String): Long? = try {
        val fmt = SimpleDateFormat("yyyyMMdd", Locale.US).apply { isLenient = false }
        fmt.parse(expiry)?.time?.plus(86_400_000L)
    } catch (e: Exception) { null }

    private fun daysLeft(expiry: String): Long? {
        if (expiry == "0" || expiry.isBlank()) return null
        val end = endMillis(expiry) ?: return null
        val left = end - System.currentTimeMillis()
        return if (left <= 0) 0L else (left + 86_399_999L) / 86_400_000L
    }

    fun serverUrl(): String = App.ctx.getString(R.string.license_server).trim().trimEnd('/')
    fun onlineConfigured() = serverUrl().startsWith("http")

    private var lastErr = ""

    /** Sunucuya sorar (bloklayıcı; arka plan iş parçacığında çağrılmalı). null = başarısız; nedeni lastErr'de. */
    private fun query(key: String?): Online? {
        lastErr = ""
        val base = serverUrl()
        if (!base.startsWith("http")) { lastErr = "sunucu adresi boş"; return null }
        val dev = rawCode()
        val nonce = UUID.randomUUID().toString().replace("-", "").take(16)
        var u = "$base/check?d=$dev&n=$nonce"
        if (!key.isNullOrBlank()) u += "&k=" + URLEncoder.encode(key.trim(), "UTF-8")
        return try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000; c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", "CarTube-Pro"); c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) { lastErr = "HTTP $code " + body.replace(Regex("\\s+"), " ").take(120); return null }
            val j = try { JSONObject(body) } catch (e: Exception) { lastErr = "yanıt okunamadı: " + body.take(60); return null }
            val payload = Base64.decode(j.getString("p"), B64)
            val sig = Base64.decode(j.getString("s"), B64)
            if (!sigOk(payload, sig)) { lastErr = "imza uyuşmuyor (sunucudaki PRIV_KEY bu uygulamayla eşleşmiyor)"; return null }
            val f = String(payload, Charsets.UTF_8).split("|", limit = 8)
            if (f.size < 6 || f[0] != "CT2" || f[1] != dev || f[2] != nonce) { lastErr = "yanıt beklenen biçimde değil"; return null }
            Online(f[3], f[4], f[5], f.getOrNull(6)?.toLongOrNull() ?: 0L, f.getOrNull(7)?.toLongOrNull() ?: 0L)
        } catch (e: Exception) { lastErr = "bağlantı hatası (" + e.javaClass.simpleName + ")"; null }
    }

    /** Sunucu yanıtını saklar. Anahtarla yapılan denemede yalnızca başarı saklanır (yanlış anahtar mevcut lisansı bozmaz). */
    private fun store(o: Online, withKey: Boolean) {
        val had = App.str("lo_status").isNotBlank()
        val st = when {
            o.status == "ok" -> "ok"
            withKey -> return
            o.status == "expired" || o.status == "revoked" -> o.status
            had -> "revoked"      // sunucuda artık kayıt yok: lisans kaldırılmış
            else -> return
        }
        App.setStr("lo_status", st); App.setStr("lo_exp", o.exp); App.setStr("lo_email", o.email)
        App.setStr("lo_act", o.act.toString()); App.setStr("lo_expat", o.expAt.toString()); App.setStr("lo_chk", System.currentTimeMillis().toString())
    }

    /** Anahtarla etkinleştirir (bloklayıcı). */
    fun activateOnline(key: String): Result {
        if (!onlineConfigured()) return Result.Bad("Lisans sunucusu ayarlanmamış")
        val o = query(key) ?: return Result.Bad("Sunucuya ulaşılamadı: " + lastErr)
        store(o, true)
        return when (o.status) {
            "ok" -> Result.Ok(Info(o.email, o.exp))
            "expired" -> Result.Bad("Lisans süresi dolmuş")
            "revoked" -> Result.Bad("Lisans iptal edilmiş")
            "otherdevice" -> Result.Bad("Bu anahtar başka bir cihaz için tanımlı")
            "nokey" -> Result.Bad("Lisans anahtarı bulunamadı")
            else -> Result.Bad("Bu cihaz için lisans bulunamadı")
        }
    }

    /** Anahtarsız, cihaz koduyla denetim: uygulama silinip yeniden kurulduğunda lisansı kendiliğinden tanır (bloklayıcı). */
    fun autoCheck(): Boolean {
        val o = query(null) ?: return false
        store(o, false)
        return o.status == "ok"
    }

    /** Arka planda, 6 saatte bir sunucuyla durumu eşitler (iptal / süre bitişi bu yolla anlaşılır). */
    fun refreshIfDue() {
        if (!onlineConfigured() || App.str("lo_status").isBlank()) return
        val chk = App.str("lo_chk").toLongOrNull() ?: 0L
        if (System.currentTimeMillis() - chk < REFRESH_MS) return
        Thread { query(null)?.let { store(it, false) } }.start()
    }

    private fun onlineActive(): Boolean {
        if (App.str("lo_status") != "ok") return false
        val chk = App.str("lo_chk").toLongOrNull() ?: return false
        val now = System.currentTimeMillis()
        if (now < chk - 86_400_000L) return false          // saat geriye alınmış
        if (now - chk > GRACE_MS) return false             // uzun süredir doğrulanamadı
        val exp = App.str("lo_exp")
        if (exp.isNotBlank() && exp != "0") { val end = endMillis(exp) ?: return false; if (now >= end) return false }
        val at = App.str("lo_expat").toLongOrNull() ?: 0L        // deneme sürümü: tam 24 saat
        if (at > 0 && now >= at) return false
        return true
    }

    /** Geçerli lisans var mı? */
    fun active(): Boolean = onlineActive()

    /** Lisans ekranı için durum, süre ve etkinleştirme bilgileri; kayıtlı lisans yoksa null. */
    fun details(): Details? {
        val st = App.str("lo_status")
        if (st.isBlank()) return null
        val exp = App.str("lo_exp").ifBlank { "0" }
        val act = onlineActive()
        val status = when {
            act -> "Aktif"
            st == "expired" -> "Süresi dolmuş"
            st == "revoked" -> "İptal edilmiş"
            st == "ok" -> "Doğrulama gerekli"
            else -> "Geçersiz"
        }
        val at = App.str("lo_expat").toLongOrNull() ?: 0L
        return Details(act, status, App.str("lo_email"), false, exp, if (at > 0) null else daysLeft(exp), App.str("lo_act").toLongOrNull() ?: 0L, at)
    }
}
