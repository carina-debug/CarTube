package com.cartube.app.car

import android.content.Intent
import android.net.Uri
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.constraints.ConstraintManager
import androidx.car.app.model.*
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import com.cartube.app.*

class CarTubeService : CarAppService() {
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = object : Session() {
        override fun onCreateScreen(intent: Intent): Screen { App.greet(carContext, true); return HomeScreen(carContext) }
    }
}

private fun icon(c: CarContext, res: Int) =
    CarIcon.Builder(IconCompat.createWithResource(c, res)).build()

/** fullScreen=true: "CarTube Tam Ekran" (navigasyon) girişinden açılır; Ekran Yansıtma doğrudan araç ekranında gösterilir. */
class HomeScreen(c: CarContext, private val fullScreen: Boolean = false) : Screen(c) {
    private fun open(cls: Class<*>) {
        carContext.startActivity(Intent(carContext, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        CarToast.makeText(carContext, L.t("Telefonda açıldı"), CarToast.LENGTH_SHORT).show()
    }
    private fun cast() {
        if (!fullScreen) { open(MirrorActivity::class.java); return }
        if (Mirror.active) screenManager.push(MirrorScreen(carContext))
        else {
            carContext.startActivity(Intent(carContext, MirrorActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            CarToast.makeText(carContext, L.t("Önce telefonda yansıtmayı başlat"), CarToast.LENGTH_LONG).show()
        }
    }
    private fun item(t: String, s: String, res: Int, onClick: () -> Unit) =
        GridItem.Builder().setTitle(L.t(t)).setText(L.t(s)).setImage(icon(carContext, res), GridItem.IMAGE_TYPE_ICON)
            .setOnClickListener(onClick).build()

    override fun onGetTemplate(): Template {
        val b = ItemList.Builder().setNoItemsMessage(L.t("Telefondan Ayarlar > Araç Uygulamaları'nı açın"))
        if (App.bool("car_tv", true)) b.addItem(item("TV", "Canlı TV ve IPTV", R.drawable.ic_tv) { open(TvActivity::class.java) })
        if (App.bool("car_yt", true)) b.addItem(item("YouTube", "Video izle", R.drawable.ic_play) { open(YouTubeActivity::class.java) })
        if (App.bool("car_cast", true)) b.addItem(item("Ekran Yansıtma", "Telefon ekranını göster", R.drawable.ic_cast) { cast() })
        if (App.bool("car_radio", true)) b.addItem(item("Radyo", "İnternet Radyoları", R.drawable.ic_radio) { screenManager.push(RadioCarScreen(carContext)) })
        if (App.bool("car_phone", true) && PhoneApps.selected().isNotEmpty())
            b.addItem(item("Telefon", "Seçili uygulamalar", R.drawable.ic_phone) { screenManager.push(PhoneAppsCarScreen(carContext)) })
        if (App.bool("car_nav", true)) b.addItem(item("Navigasyon", "Google Haritalar", R.drawable.ic_nav) { screenManager.push(NavSearchScreen(carContext)) })
        val list = b.build()
        return GridTemplate.Builder().setTitle("CarTube").setHeaderAction(Action.APP_ICON).setSingleList(list).build()
    }
}

class RadioCarScreen(c: CarContext) : Screen(c) {
    override fun onGetTemplate(): Template {
        val radios = App.radioList()
        val b = ItemList.Builder()
        if (radios.isEmpty()) b.setNoItemsMessage(L.t("Radyo yok. Telefondan Ayarlar'a ekleyin."))
        radios.take(6).forEach { (n, u) ->
            b.addItem(Row.Builder().setTitle(n).setOnClickListener {
                App.play(n, u); CarToast.makeText(carContext, L.t("Çalıyor: ") + n, CarToast.LENGTH_SHORT).show()
            }.build())
        }
        return ListTemplate.Builder().setTitle(L.t("Radyo")).setHeaderAction(Action.BACK).setSingleList(b.build()).build()
    }
}

class PhoneAppsCarScreen(c: CarContext) : Screen(c) {
    override fun onGetTemplate(): Template {
        val limit = try {
            carContext.getCarService(ConstraintManager::class.java).getContentLimit(ConstraintManager.CONTENT_LIMIT_TYPE_GRID)
        } catch (e: Exception) { 6 }
        val b = ItemList.Builder().setNoItemsMessage(L.t("Telefondan Ayarlar > Araç Uygulamaları'ndan uygulama ekleyin"))
        PhoneApps.selectedInfos(carContext).take(limit).forEach { a ->
            b.addItem(GridItem.Builder().setTitle(a.label)
                .setImage(PhoneApps.carIcon(a.icon), GridItem.IMAGE_TYPE_LARGE)
                .setOnClickListener {
                    PhoneApps.launch(carContext, a.pkg)
                    CarToast.makeText(carContext, L.t("Telefonda açıldı"), CarToast.LENGTH_SHORT).show()
                }.build())
        }
        return GridTemplate.Builder().setTitle(L.t("Telefon Uygulamaları")).setHeaderAction(Action.BACK).setSingleList(b.build()).build()
    }
}

/** Araç ekranında adres yazılır; yol tarifi aracın varsayılan navigasyon uygulamasında (Google Haritalar) başlar. */
class NavSearchScreen(c: CarContext) : Screen(c) {
    override fun onGetTemplate(): Template = SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
        override fun onSearchTextChanged(searchText: String) {}
        override fun onSearchSubmitted(searchText: String) {
            if (searchText.isBlank()) return
            try {
                carContext.startCarApp(Intent(CarContext.ACTION_NAVIGATE, Uri.parse("geo:0,0?q=" + Uri.encode(searchText))))
            } catch (e: Exception) {
                CarToast.makeText(carContext, L.t("Navigasyon uygulaması açılamadı"), CarToast.LENGTH_LONG).show()
            }
        }
    }).setSearchHint(L.t("Nereye gidelim?")).setHeaderAction(Action.BACK).setShowKeyboardByDefault(true).build()
}
