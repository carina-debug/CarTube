package com.cartube.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/** Lisans ekranı: durum, süre ve etkinleştirme bilgilerini gösterir; anahtar girilerek etkinleştirilir / yenilenir. */
class LicenseActivity : AppCompatActivity() {
    private val gold get() = Theme.set()
    private val grey = Color.parseColor("#B8C4D0")
    private val card get() = Theme.setCard()
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var btnAct: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun onAccent(): Int { val a = Theme.set(); return if (0.299 * Color.red(a) + 0.587 * Color.green(a) + 0.114 * Color.blue(a) > 150) Color.parseColor("#0E1214") else Color.WHITE }

    private fun button(text: String, fill: Boolean, onClick: () -> Unit) = Button(this).apply {
        this.text = L.t(text); isAllCaps = false; textSize = 16f; setTypeface(null, Typeface.BOLD)
        setTextColor(if (fill) onAccent() else gold)
        background = Theme.roundRect(if (fill) gold else card, 18)
        setOnClickListener { onClick() }
    }
    private fun lp(top: Int = 10) = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(top) }

    private fun row(label: String, value: String, color: Int = Color.WHITE): LinearLayout {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(9), 0, dp(9)) }
        r.addView(TextView(this).apply { text = L.t(label); setTextColor(grey); textSize = 14f }, LinearLayout.LayoutParams(0, -2, 0.9f))
        r.addView(TextView(this).apply {
            text = value; setTextColor(color); textSize = 16f; gravity = Gravity.END
            setTypeface(Typeface.DEFAULT, Typeface.BOLD); setTextIsSelectable(true)
        }, LinearLayout.LayoutParams(0, -2, 1.3f))
        return r
    }

    /** Uzun değerler (cihaz kodu) için etiket üstte, değer tek satırda altta. */
    private fun stacked(label: String, value: String): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(9), 0, dp(9)) }
        r.addView(TextView(this).apply { text = L.t(label); setTextColor(grey); textSize = 14f })
        r.addView(TextView(this).apply {
            text = value; setTextColor(gold); textSize = 18f; maxLines = 1; setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            setTextIsSelectable(true); setPadding(0, dp(4), 0, 0)
        })
        return r
    }

    private fun niceDate(yyyymmdd: String): String = try {
        val d = SimpleDateFormat("yyyyMMdd", Locale.US).parse(yyyymmdd)
        SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(d!!)
    } catch (e: Exception) { yyyymmdd }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val d = License.details()
        val active = d != null && d.active
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(48), dp(24), dp(32)) }
        col.addView(TextView(this).apply { text = L.t("Lisans"); setTextColor(Color.WHITE); textSize = 28f; setTypeface(null, Typeface.BOLD) })
        if (!active) {
            col.addView(TextView(this).apply {
                text = L.t("CarTube-Pro'yu kullanmak için lisans anahtarı gerekir. Aşağıdaki cihaz kodunu ve e-posta adresinizi geliştiriciye gönderin; e-postayla gelen anahtarı buraya girin. Daha önce etkinleştirdiyseniz uygulamayı silip yeniden kurmak lisansı kaldırmaz, cihaz kendiliğinden tanınır.")
                setTextColor(grey); textSize = 15f; setPadding(0, dp(10), 0, dp(4)) })
        }

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = Theme.roundRect(card, 20); setPadding(dp(18), dp(8), dp(18), dp(8)) }
        val ok = Color.parseColor("#7BD88F"); val bad = Color.parseColor("#FF7A7A")
        box.addView(row("Durum", L.t(d?.status ?: "Lisans yok"), if (active) ok else bad))
        if (d != null) {
            box.addView(row("E-posta", d.email.ifBlank { "—" }))
            val trial = d.expiryAt > 0
            val leftMs = d.expiryAt - System.currentTimeMillis()
            box.addView(row("Lisans türü", L.t(if (trial) "Deneme sürümü" else if (d.universal) "Tüm cihazlarda geçerli" else "Bu cihaza özel")))
            box.addView(row("Etkinleştirme tarihi", if (d.activatedAt > 0) SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(d.activatedAt)) else "—"))
            box.addView(row("Bitiş tarihi", when {
                trial -> SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(d.expiryAt))
                d.expiry == "0" -> L.t("Sınırsız")
                else -> niceDate(d.expiry) }))
            box.addView(row("Kalan süre", when {
                trial -> if (leftMs <= 0) L.t("Süresi doldu") else (leftMs / 3_600_000).toString() + " " + L.t("sa") + " " + ((leftMs / 60_000) % 60) + " " + L.t("dk")
                d.expiry == "0" -> L.t("Sınırsız")
                (d.daysLeft ?: 0L) <= 0L -> L.t("Süresi doldu")
                else -> d.daysLeft.toString() + " " + L.t("gün") },
                if ((trial && leftMs < 3 * 3_600_000L) || (!trial && d.daysLeft != null && d.daysLeft <= 7L && d.expiry != "0")) bad else Color.WHITE))
        }
        box.addView(stacked("Cihaz kodu", License.deviceCode()))
        col.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        col.addView(button("Cihaz kodunu kopyala", false) { copy(License.deviceCode()) }, lp())
        col.addView(button("Cihaz kodunu paylaş", false) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "CarTube-Pro cihaz kodum: " + License.deviceCode()), null))
        }, lp(8))

        col.addView(TextView(this).apply { text = L.t(if (d == null) "Lisans anahtarı" else "Yeni lisans anahtarı (yenileme)"); setTextColor(grey); textSize = 13f; setPadding(0, dp(24), 0, 0) })
        input = EditText(this).apply {
            hint = L.t("CT-XXXX-XXXX-XXXX"); setHintTextColor(Color.parseColor("#6B7782")); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            minLines = 2; maxLines = 6; gravity = Gravity.TOP; textSize = 16f; setTypeface(Typeface.MONOSPACE)
            setPadding(dp(14), dp(12), dp(14), dp(12)); background = Theme.roundRect(card, 18)
        }
        col.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        col.addView(button("Panodan yapıştır", false) {
            val cm = getSystemService(ClipboardManager::class.java)
            val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrBlank()) input.setText(t.trim()) else Toast.makeText(this, L.t("Panoda metin yok"), Toast.LENGTH_SHORT).show()
        }, lp())
        btnAct = button("Etkinleştir", true) { activate() }
        col.addView(btnAct, lp(8))
        status = TextView(this).apply { textSize = 15f; setPadding(0, dp(16), 0, 0) }
        col.addView(status)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.setBg()) }
        root.addView(ScrollView(this).apply { setBackgroundColor(Theme.setBg()); addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Ui.navBar(this, L.t("Lisans")))
        setContentView(root)

        // Lisans yoksa: bu cihaz daha önce etkinleştirilmiş mi diye sunucuya sor (silip yeniden kurulum)
        if (!active && License.onlineConfigured()) {
            status.setTextColor(grey); status.text = L.t("Cihaz denetleniyor…")
            thread {
                val found = License.autoCheck()
                runOnUiThread {
                    if (isFinishing) return@runOnUiThread
                    if (found) goMain() else status.text = ""
                }
            }
        }
    }

    private fun copy(t: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("CarTube-Pro", t))
        Toast.makeText(this, L.t("Kopyalandı"), Toast.LENGTH_SHORT).show()
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    private fun done(r: License.Result) {
        when (r) {
            is License.Result.Ok -> { Toast.makeText(this, L.t("Lisans etkinleştirildi"), Toast.LENGTH_LONG).show(); goMain() }
            is License.Result.Bad -> { status.setTextColor(Color.parseColor("#FF7A7A")); status.text = L.t(r.reason) }
        }
    }

    private fun activate() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) { status.setTextColor(Color.parseColor("#FF7A7A")); status.text = L.t("Lisans anahtarını girin"); return }
        btnAct.isEnabled = false
        status.setTextColor(grey); status.text = L.t("Doğrulanıyor…")
        thread {
            val r = License.activateOnline(t)
            runOnUiThread { if (!isFinishing) { btnAct.isEnabled = true; done(r) } }
        }
    }
}
