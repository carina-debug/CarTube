package com.cartube.app

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

/** Radyo: Mola'daki gibi logolu istasyon listesi. Birden fazla liste, internet radyoları otomatik eklenir. */
class RadioActivity : AppCompatActivity() {
    private val st get() = Stores.radio
    private lateinit var listBtn: TextView
    private lateinit var orb: RadioOrb
    private lateinit var chip: TextView
    private lateinit var nameTv: TextView
    private lateinit var subTv: TextView
    private val pl = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = updateHeader()
        override fun onPlaybackStateChanged(playbackState: Int) = updateHeader()
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = updateHeader()
    }
    private lateinit var lv: ListView
    private var shown = listOf<ListStore.Item>()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private var seenRev = -1

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Theme.bg()) }
        val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = if (land) Gravity.CENTER else Gravity.CENTER_HORIZONTAL; setPadding(dp(16), dp(if (land) 8 else 30), dp(16), dp(6)) }
        chip = TextView(this).apply { textSize = 12f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); setPadding(dp(14), dp(4), dp(14), dp(4)); visibility = View.INVISIBLE }
        head.addView(chip)
        orb = RadioOrb(this).apply { setOnClickListener { toggleRadio() } }
        fun navBtn(icon: Int, d: Int) = ImageButton(this).apply {
            background = Theme.circle(Theme.mix(Theme.bg(), Theme.home(), 0.35f), Theme.home()); setImageResource(icon); setColorFilter(Color.WHITE)
            setOnClickListener { step(d) }
        }
        val orbSize = if (land) 120 else 150
        val orbRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        orbRow.addView(navBtn(R.drawable.ic_prev, -1), LinearLayout.LayoutParams(dp(54), dp(54)))
        orbRow.addView(orb, LinearLayout.LayoutParams(dp(orbSize), dp(orbSize)).apply { leftMargin = dp(10); rightMargin = dp(10) })
        orbRow.addView(navBtn(R.drawable.ic_next, 1), LinearLayout.LayoutParams(dp(54), dp(54)))
        head.addView(orbRow)
        nameTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 22f; setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        head.addView(nameTv, LinearLayout.LayoutParams(-1, -2))
        subTv = TextView(this).apply { setTextColor(Color.parseColor("#B0B5B8")); textSize = 14f; gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        head.addView(subTv, LinearLayout.LayoutParams(-1, -2))
        listBtn = TextView(this).apply {
            setTextColor(Theme.home()); textSize = 15f; setTypeface(null, Typeface.BOLD); setPadding(dp(12), dp(8), dp(12), dp(4)); setOnClickListener { chooseList() } }
        head.addView(listBtn)
        lv = ListView(this).apply { setBackgroundColor(Color.TRANSPARENT); divider = null; setPadding(dp(10), 0, dp(10), 0); clipToPadding = false }
        if (land) {
            // Yatay: solda istasyon listesi, sağda oynatıcı
            val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            body.addView(lv, LinearLayout.LayoutParams(0, -1, 0.42f))
            body.addView(ScrollView(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = false; addView(head, ViewGroup.LayoutParams(-1, -2)) }, LinearLayout.LayoutParams(0, -1, 0.58f))
            root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            root.addView(head)
            root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        root.addView(Ui.navBar(this, null, R.drawable.ic_edit) { editMenu() })
        setContentView(root)
        lv.setOnItemClickListener { _, _, i, _ -> shown.getOrNull(i)?.let { App.play(it.n, it.u); updateHeader() } }
        lv.setOnItemLongClickListener { _, _, i, _ -> shown.getOrNull(i)?.let { stationMenu(it) }; true }
        if (st.lists.isEmpty()) fetchInternet("TR") else refresh()
        updateHeader()
    }

    /** Radyo simgesinin yanındaki ileri / geri düğmeleri: listedeki bir önceki / sonraki istasyonu çalar. */
    private fun step(d: Int) {
        if (shown.isEmpty()) return
        val i = shown.indexOfFirst { it.u == App.nowUrl }
        val k = if (i < 0) (if (d > 0) 0 else shown.size - 1) else ((i + d) % shown.size + shown.size) % shown.size
        val n = shown[k]
        App.play(n.n, n.u); updateHeader()
    }

    override fun onResume() {
        super.onResume()
        if (::lv.isInitialized && st.rev != seenRev) { refresh(); updateHeader() }
    }

    override fun onStart() { super.onStart(); App.player.addListener(pl); updateHeader() }
    override fun onStop() { super.onStop(); App.player.removeListener(pl) }

    /** Seçili istasyonu ve oynatma durumunu radyo simgesinin altında gösterir. */
    private fun updateHeader() {
        if (!::orb.isInitialized) return
        val title = App.nowTitle(); val has = App.nowUrl != null && title != null
        val playing = App.nowPlaying()
        val buffering = App.cur == 1 && App.player.playbackState == Player.STATE_BUFFERING && App.player.playWhenReady
        nameTv.text = if (has) title else L.t("Bir istasyon seçin")
        subTv.text = if (has) (st.cur()?.items?.firstOrNull { it.u == App.nowUrl }?.s ?: "") else L.t("Radyo")
        orb.set(playing && !buffering, buffering)
        val (txt, col) = when {
            buffering -> L.t("Bağlanıyor…") to Color.parseColor("#B8860B")
            playing -> "● " + L.t("CANLI") to Color.parseColor("#D32F2F")
            has -> L.t("Duraklatıldı") to Color.parseColor("#475569")
            else -> "" to Color.TRANSPARENT
        }
        chip.text = txt; chip.background = Theme.roundRect(col, 16); chip.visibility = if (txt.isEmpty()) View.INVISIBLE else View.VISIBLE
    }

    /** Simgeye dokununca radyo durur / yeniden çalar. */
    private fun toggleRadio() {
        if (App.nowUrl == null || App.nowTitle() == null) { Ui.toast(this, "Önce listeden bir istasyon seçin"); return }
        App.togglePlay(); updateHeader()
    }

    private inner class Rows(val data: List<ListStore.Item>) : BaseAdapter() {
        override fun getCount() = data.size
        override fun getItem(p: Int) = data[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, g: ViewGroup): View {
            val it = data[p]
            val row = LinearLayout(this@RadioActivity).apply {
                gravity = Gravity.CENTER_VERTICAL; background = Theme.homeCard(); setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = FrameLayout.LayoutParams(-1, -2)
            }
            val box = FrameLayout(this@RadioActivity).apply { background = Theme.roundRect(Color.parseColor("#12171A"), 14, Theme.dim(Theme.home())) }
            val img = ImageView(this@RadioActivity).apply { setPadding(dp(6), dp(6), dp(6), dp(6)); }
            box.addView(img, FrameLayout.LayoutParams(dp(52), dp(52)))
            ImgLoader.load(it.i, img, R.drawable.ic_radio)
            row.addView(box, LinearLayout.LayoutParams(dp(52), dp(52)))
            val tx = LinearLayout(this@RadioActivity).apply { orientation = LinearLayout.VERTICAL }
            tx.addView(TextView(this@RadioActivity).apply { text = it.n; setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD); maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            if (it.s.isNotBlank()) tx.addView(TextView(this@RadioActivity).apply { text = it.s; setTextColor(Color.parseColor("#B0B5B8")); textSize = 12f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
            val wrap = FrameLayout(this@RadioActivity).apply { setPadding(0, dp(3), 0, dp(3)); addView(row) }
            return wrap
        }
    }

    private fun refresh() {
        seenRev = st.rev
        val c = st.cur()
        listBtn.text = (c?.name ?: L.t("Liste yok")) + "  ▾"
        shown = c?.items ?: emptyList()
        lv.adapter = Rows(shown)
    }

    private fun chooseList() {
        if (st.lists.isEmpty()) { editMenu(); return }
        Ui.menu(this, "Liste seç", st.lists.map { it.name + " (" + it.items.size + ")" }) { st.active = it; st.save(); refresh() }
    }

    private fun stationMenu(it: ListStore.Item) {
        Ui.menu(this, it.n, listOf("Favorilere ekle", "Sil")) { i ->
            if (i == 0) { App.addFav(it.n, it.u); Ui.toast(this, "Favorilere eklendi") }
            else { st.cur()?.items?.remove(it); st.save(); refresh() }
        }
    }

    private fun editMenu() {
        Ui.menu(this, "Radyo listeleri", listOf("Liste ekle (adres / M3U)", "Yeni boş liste", "Radyo ekle", "İnternet radyolarını ekle",
            "Listeyi yenile", "Listeyi yeniden adlandır", "Listeyi sil")) { i ->
            when (i) {
                0 -> Ui.ask(this, "Liste ekle (adres / M3U)", listOf("Liste adı", "M3U / liste adresi (URL)")) { v -> addFromUrl(v[0], v[1]) }
                1 -> Ui.ask(this, "Yeni boş liste", listOf("Liste adı")) { v -> if (v[0].isNotBlank()) { st.add(ListStore.Lst(v[0])); refresh() } }
                2 -> Ui.ask(this, "Radyo ekle", listOf("Ad", "Yayın adresi (URL)")) { v ->
                    if (v[1].isNotBlank()) {
                        if (st.cur() == null) st.add(ListStore.Lst("Listem"))
                        st.cur()!!.items.add(ListStore.Item(v[0].ifBlank { v[1] }, v[1])); st.save(); refresh()
                    }
                }
                3 -> Ui.ask(this, "Ülke kodu (TR, DE, US…)", listOf("Ülke kodu"), listOf("TR")) { v -> fetchInternet(v[0].ifBlank { "TR" }.uppercase()) }
                4 -> refreshList()
                5 -> st.cur()?.let { c -> Ui.ask(this, "Listeyi yeniden adlandır", listOf("Liste adı"), listOf(c.name)) { v -> if (v[0].isNotBlank()) { c.name = v[0]; st.save(); refresh() } } }
                6 -> st.cur()?.let { c -> Ui.confirm(this, "\"${c.name}\" " + L.t("silinsin mi?")) { st.removeActive(); refresh() } }
            }
        }
    }

    private fun addFromUrl(name: String, url: String) {
        if (url.isBlank()) return
        Ui.toast(this, "Yükleniyor…")
        thread {
            val items = try { ListStore.parse(ListStore.http(url)) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (items.isEmpty()) Ui.toast(this, "Liste yüklenemedi")
                else { st.add(ListStore.Lst(name.ifBlank { url.substringAfterLast('/') }, url, items.toMutableList())); refresh() }
            }
        }
    }

    private fun fetchInternet(cc: String) {
        Ui.toast(this, "İnternet radyoları yükleniyor…")
        thread {
            val items = ListStore.radios(cc)
            runOnUiThread {
                if (items.isEmpty()) { Ui.toast(this, "Liste yüklenemedi"); refresh() }
                else { st.add(ListStore.Lst(L.t("İnternet radyoları") + " ($cc)", "radio-browser:$cc", items.toMutableList())); refresh() }
            }
        }
    }

    private fun refreshList() {
        val c = st.cur() ?: return
        if (c.src.isBlank()) { Ui.toast(this, "Bu liste elle oluşturulmuş"); return }
        Ui.toast(this, "Yükleniyor…")
        thread {
            val items = try {
                if (c.src.startsWith("radio-browser:")) ListStore.radios(c.src.substringAfter(":")) else ListStore.parse(ListStore.http(c.src))
            } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (items.isEmpty()) Ui.toast(this, "Liste yüklenemedi") else { c.items = items.toMutableList(); st.save(); refresh() }
            }
        }
    }
}
