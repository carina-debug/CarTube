# CarTube Pro — Android Auto kurulum rehberi

CarTube'u APK ile (Google Play dışı) kurduysanız Android Auto, "CarTube Pro Tam" girişini varsayılan olarak
listelemeyebilir. Radyo/medya girişi ("CarTube Pro") yine görünür. Aşağıdaki adımları sırayla deneyin.

## 1. Android Auto'da bilinmeyen kaynakları açın
1. Telefon ayarlarında **Android Auto** aratın.
2. Sayfanın altındaki **Sürüm** yazısına yaklaşık 10 kez dokunun, geliştirici ayarlarını etkinleştirin.
3. Sağ üst **⋮ → Geliştirici ayarları → Bilinmeyen kaynaklar** seçeneğini açın.
4. Telefonu yeniden başlatın, araç bağlantısını kesip yeniden bağlayın.

## 2. Başlatıcıyı özelleştirin
Android Auto → **Başlatıcıyı özelleştir** ekranında "CarTube Pro" ve "CarTube Pro Tam" işaretli olsun.
"Gizli Uygulamalar" bölümünde duruyorlarsa işaretleyip yukarı alın.

## 3. Hâlâ görünmüyorsa
Android Auto uygulamasının önbelleğini ve verisini temizleyin, telefonu yeniden başlatın.
Android Auto'nun ve Google Play Hizmetleri'nin güncel olduğundan emin olun.
Bazı cihazlarda Android Auto, uygulamayı yükleyen kaynağa (Google Play olup olmadığına) bakar.
Benzer uygulamaların (ör. Mola) rehberleri bu durumda üçüncü taraf bir yükleyiciyle (KingInstaller + Shizuku)
yeniden yüklemeyi öneriyor. Bu bizim yazılımımız değildir; kendi sorumluluğunuzda denemeniz gerekir ve
her cihazda sonuç garantisi yoktur.

Sorun bildirirken telefon modeli, Android sürümü, Android Auto sürümü, CarTube sürümü ve kurulum yöntemini yazın.
